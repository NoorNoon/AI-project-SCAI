// محرك المحاكاة الافتراضية للاستاد
import { EventEmitter } from "events"

export type PersonState = {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  panic: number // 0-100
  health: number // 0-100
  targetX?: number
  targetY?: number
  type: "spectator" | "security" | "medical" | "staff"
  status: "normal" | "panicked" | "injured" | "evacuating"
}

export type EmergencyType = "fire" | "riot" | "medical" | "congestion" | "none"

export type EmergencyState = {
  type: EmergencyType
  x: number
  y: number
  radius: number
  intensity: number // 0-100
  spreadRate: number
  timeRemaining: number // بالثواني
  isContained: boolean
}

export type ExitPoint = {
  id: number
  x: number
  y: number
  capacity: number
  currentLoad: number
  isBlocked: boolean
}

export type SimulationState = {
  people: PersonState[]
  emergencies: EmergencyState[]
  exits: ExitPoint[]
  securityTeams: { x: number; y: number; radius: number }[]
  medicalTeams: { x: number; y: number; radius: number }[]
  timestamp: number
  evacuationProgress: number // 0-100
  casualties: number
  safetyScore: number // 0-100
}

export class SimulationEngine extends EventEmitter {
  private state: SimulationState
  private running = false
  private interval: NodeJS.Timeout | null = null
  private stadiumWidth = 1000
  private stadiumHeight = 800
  private defaultExits: ExitPoint[] = [
    { id: 1, x: 50, y: 50, capacity: 50, currentLoad: 0, isBlocked: false },
    { id: 2, x: 950, y: 50, capacity: 50, currentLoad: 0, isBlocked: false },
    { id: 3, x: 50, y: 750, capacity: 50, currentLoad: 0, isBlocked: false },
    { id: 4, x: 950, y: 750, capacity: 50, currentLoad: 0, isBlocked: false },
    { id: 5, x: 500, y: 50, capacity: 100, currentLoad: 0, isBlocked: false },
    { id: 6, x: 500, y: 750, capacity: 100, currentLoad: 0, isBlocked: false },
  ]

  constructor() {
    super()
    this.state = this.getInitialState()
  }

  private getInitialState(): SimulationState {
    return {
      people: [],
      emergencies: [],
      exits: [...this.defaultExits],
      securityTeams: [
        { x: 250, y: 250, radius: 50 },
        { x: 750, y: 250, radius: 50 },
        { x: 250, y: 550, radius: 50 },
        { x: 750, y: 550, radius: 50 },
      ],
      medicalTeams: [
        { x: 500, y: 250, radius: 40 },
        { x: 500, y: 550, radius: 40 },
      ],
      timestamp: Date.now(),
      evacuationProgress: 0,
      casualties: 0,
      safetyScore: 100,
    }
  }

  public reset(): void {
    this.state = this.getInitialState()
    this.emit("stateChanged", this.state)
  }

  public getState(): SimulationState {
    return { ...this.state }
  }

  public addPeople(count: number, type: "spectator" | "security" | "medical" | "staff" = "spectator"): void {
    const newPeople: PersonState[] = []

    for (let i = 0; i < count; i++) {
      // تجنب وضع الأشخاص في المخارج
      let x, y
      let validPosition = false

      while (!validPosition) {
        x = Math.random() * this.stadiumWidth
        y = Math.random() * this.stadiumHeight

        validPosition = !this.state.exits.some(
          (exit) => Math.sqrt(Math.pow(exit.x - x, 2) + Math.pow(exit.y - y, 2)) < 30,
        )
      }

      newPeople.push({
        id: this.state.people.length + i + 1,
        x,
        y,
        vx: 0,
        vy: 0,
        panic: 0,
        health: 100,
        type,
        status: "normal",
      })
    }

    this.state.people = [...this.state.people, ...newPeople]
    this.emit("stateChanged", this.state)
  }

  public createEmergency(type: EmergencyType, x: number, y: number): void {
    if (type === "none") {
      this.state.emergencies = []
      this.emit("stateChanged", this.state)
      return
    }

    const emergency: EmergencyState = {
      type,
      x,
      y,
      radius: type === "fire" ? 30 : type === "riot" ? 50 : type === "medical" ? 10 : 40,
      intensity: type === "fire" ? 80 : type === "riot" ? 70 : type === "medical" ? 50 : 60,
      spreadRate: type === "fire" ? 0.5 : type === "riot" ? 0.3 : type === "medical" ? 0 : 0.1,
      timeRemaining: type === "fire" ? 300 : type === "riot" ? 600 : type === "medical" ? 180 : 450,
      isContained: false,
    }

    this.state.emergencies.push(emergency)

    // تحديث حالة الأشخاص القريبين من الطوارئ
    this.updatePeopleNearEmergency(emergency)

    this.emit("stateChanged", this.state)
    this.emit("emergencyCreated", emergency)
  }

  private updatePeopleNearEmergency(emergency: EmergencyState): void {
    const affectedRadius = emergency.radius * 2

    this.state.people.forEach((person) => {
      const distance = Math.sqrt(Math.pow(person.x - emergency.x, 2) + Math.pow(person.y - emergency.y, 2))

      if (distance < affectedRadius) {
        // زيادة الذعر بناءً على القرب من الطوارئ
        const panicIncrease = Math.min(100 - person.panic, (1 - distance / affectedRadius) * 70)
        person.panic += panicIncrease

        // تقليل الصحة في حالة الحريق أو الشغب إذا كان قريبًا جدًا
        if ((emergency.type === "fire" || emergency.type === "riot") && distance < emergency.radius) {
          const healthDecrease = Math.min(person.health, (1 - distance / emergency.radius) * 5)
          person.health -= healthDecrease
        }

        // تحديث حالة الشخص
        if (person.panic > 70) {
          person.status = "panicked"
        }

        if (person.health < 50) {
          person.status = "injured"
        }

        // توجيه الشخص نحو أقرب مخرج
        if (person.status === "panicked" || person.status === "injured") {
          this.assignNearestExit(person)
        }
      }
    })
  }

  private assignNearestExit(person: PersonState): void {
    // البحث عن أقرب مخرج غير مسدود
    const availableExits = this.state.exits.filter((exit) => !exit.isBlocked)

    if (availableExits.length === 0) return

    let nearestExit = availableExits[0]
    let minDistance = Number.MAX_VALUE

    availableExits.forEach((exit) => {
      const distance = Math.sqrt(Math.pow(person.x - exit.x, 2) + Math.pow(person.y - exit.y, 2))

      if (distance < minDistance) {
        minDistance = distance
        nearestExit = exit
      }
    })

    person.targetX = nearestExit.x
    person.targetY = nearestExit.y
    person.status = "evacuating"
  }

  public start(): void {
    if (this.running) return

    this.running = true
    this.interval = setInterval(() => this.update(), 50) // تحديث كل 50 مللي ثانية
    this.emit("simulationStarted")
  }

  public stop(): void {
    if (!this.running) return

    this.running = false
    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }
    this.emit("simulationStopped")
  }

  private update(): void {
    const now = Date.now()
    const deltaTime = (now - this.state.timestamp) / 1000 // بالثواني
    this.state.timestamp = now

    // تحديث حالة الطوارئ
    this.updateEmergencies(deltaTime)

    // تحديث حركة الأشخاص
    this.updatePeople(deltaTime)

    // تحديث حالة المخارج
    this.updateExits()

    // حساب تقدم الإخلاء والإحصائيات
    this.calculateStatistics()

    this.emit("stateChanged", this.state)
  }

  private updateEmergencies(deltaTime: number): void {
    const emergenciesToRemove: number[] = []

    this.state.emergencies.forEach((emergency, index) => {
      // تقليل الوقت المتبقي
      emergency.timeRemaining -= deltaTime

      if (emergency.timeRemaining <= 0) {
        emergenciesToRemove.push(index)
        return
      }

      // انتشار الطوارئ إذا لم يتم احتواؤها
      if (!emergency.isContained) {
        emergency.radius += emergency.spreadRate * deltaTime

        // التحقق من وجود فرق أمن أو طبية قريبة
        const securityNearby = this.state.securityTeams.some(
          (team) =>
            Math.sqrt(Math.pow(team.x - emergency.x, 2) + Math.pow(team.y - emergency.y, 2)) <
            team.radius + emergency.radius,
        )

        const medicalNearby = this.state.medicalTeams.some(
          (team) =>
            Math.sqrt(Math.pow(team.x - emergency.x, 2) + Math.pow(team.y - emergency.y, 2)) <
            team.radius + emergency.radius,
        )

        // تقليل شدة الطوارئ إذا كانت هناك فرق قريبة
        if (securityNearby && (emergency.type === "riot" || emergency.type === "congestion")) {
          emergency.intensity = Math.max(0, emergency.intensity - 5 * deltaTime)
        }

        if (medicalNearby && emergency.type === "medical") {
          emergency.intensity = Math.max(0, emergency.intensity - 10 * deltaTime)
        }

        // احتواء الطوارئ إذا انخفضت شدتها بما فيه الكفاية
        if (emergency.intensity < 10) {
          emergency.isContained = true
        }
      } else {
        // تقليل نصف قطر الطوارئ بعد احتوائها
        emergency.radius = Math.max(0, emergency.radius - deltaTime * 2)
        emergency.intensity = Math.max(0, emergency.intensity - deltaTime * 5)

        if (emergency.radius < 5 || emergency.intensity === 0) {
          emergenciesToRemove.push(index)
        }
      }

      // تحديث حالة الأشخاص القريبين من الطوارئ
      this.updatePeopleNearEmergency(emergency)
    })

    // إزالة الطوارئ المنتهية
    for (let i = emergenciesToRemove.length - 1; i >= 0; i--) {
      this.state.emergencies.splice(emergenciesToRemove[i], 1)
    }
  }

  private updatePeople(deltaTime: number): void {
    const peopleToRemove: number[] = []

    this.state.people.forEach((person, index) => {
      // تحديث موقع الشخص إذا كان لديه هدف
      if (person.targetX !== undefined && person.targetY !== undefined) {
        const dx = person.targetX - person.x
        const dy = person.targetY - person.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 5) {
          // وصل إلى الهدف (المخرج)
          if (this.isAtExit(person)) {
            peopleToRemove.push(index)
            return
          }
        } else {
          // تحديث السرعة والموقع
          const speed =
            person.status === "panicked"
              ? 100
              : person.status === "injured"
                ? 20
                : person.status === "evacuating"
                  ? 60
                  : 30

          person.vx = (dx / distance) * speed
          person.vy = (dy / distance) * speed
        }
      } else {
        // حركة عشوائية للأشخاص بدون هدف
        if (Math.random() < 0.02) {
          person.vx = (Math.random() - 0.5) * 20
          person.vy = (Math.random() - 0.5) * 20
        }
      }

      // تحديث الموقع
      person.x += person.vx * deltaTime
      person.y += person.vy * deltaTime

      // التأكد من بقاء الشخص داخل حدود الاستاد
      person.x = Math.max(0, Math.min(this.stadiumWidth, person.x))
      person.y = Math.max(0, Math.min(this.stadiumHeight, person.y))

      // تقليل الذعر تدريجياً إذا كان بعيداً عن الطوارئ
      if (person.panic > 0 && !this.isNearEmergency(person)) {
        person.panic = Math.max(0, person.panic - deltaTime * 2)

        if (person.panic < 30 && person.status === "panicked") {
          person.status = "normal"
          person.targetX = undefined
          person.targetY = undefined
        }
      }

      // تحسين الصحة تدريجياً إذا كان قريباً من فريق طبي
      if (person.health < 100 && this.isNearMedicalTeam(person)) {
        person.health = Math.min(100, person.health + deltaTime * 10)

        if (person.health > 70 && person.status === "injured") {
          person.status = person.panic > 70 ? "panicked" : "normal"
        }
      }
    })

    // إزالة الأشخاص الذين غادروا الاستاد
    for (let i = peopleToRemove.length - 1; i >= 0; i--) {
      this.state.people.splice(peopleToRemove[i], 1)
    }
  }

  private isAtExit(person: PersonState): boolean {
    return this.state.exits.some(
      (exit) => Math.sqrt(Math.pow(exit.x - person.x, 2) + Math.pow(exit.y - person.y, 2)) < 10 && !exit.isBlocked,
    )
  }

  private isNearEmergency(person: PersonState): boolean {
    return this.state.emergencies.some(
      (emergency) =>
        Math.sqrt(Math.pow(emergency.x - person.x, 2) + Math.pow(emergency.y - person.y, 2)) < emergency.radius * 2,
    )
  }

  private isNearMedicalTeam(person: PersonState): boolean {
    return this.state.medicalTeams.some(
      (team) => Math.sqrt(Math.pow(team.x - person.x, 2) + Math.pow(team.y - person.y, 2)) < team.radius,
    )
  }

  private updateExits(): void {
    // إعادة تعيين الحمل الحالي
    this.state.exits.forEach((exit) => {
      exit.currentLoad = 0
    })

    // حساب عدد الأشخاص بالقرب من كل مخرج
    this.state.people.forEach((person) => {
      if (person.status === "evacuating") {
        this.state.exits.forEach((exit) => {
          if (Math.sqrt(Math.pow(exit.x - person.x, 2) + Math.pow(exit.y - person.y, 2)) < 50) {
            exit.currentLoad++
          }
        })
      }
    })

    // التحقق من وجود طوارئ قريبة من المخارج
    this.state.exits.forEach((exit) => {
      exit.isBlocked = this.state.emergencies.some(
        (emergency) =>
          emergency.type === "fire" &&
          Math.sqrt(Math.pow(emergency.x - exit.x, 2) + Math.pow(emergency.y - exit.y, 2)) < emergency.radius,
      )
    })
  }

  private calculateStatistics(): void {
    // حساب تقدم الإخلاء
    const initialPeopleCount = this.state.people.length + this.state.casualties
    const evacuatedCount = initialPeopleCount - this.state.people.length

    if (initialPeopleCount > 0) {
      this.state.evacuationProgress = (evacuatedCount / initialPeopleCount) * 100
    } else {
      this.state.evacuationProgress = 100
    }

    // حساب درجة الأمان
    let totalPanic = 0
    let totalHealth = 0

    this.state.people.forEach((person) => {
      totalPanic += person.panic
      totalHealth += person.health
    })

    const avgPanic = this.state.people.length > 0 ? totalPanic / this.state.people.length : 0
    const avgHealth = this.state.people.length > 0 ? totalHealth / this.state.people.length : 100

    // درجة الأمان تعتمد على متوسط الذعر والصحة وعدد الضحايا
    this.state.safetyScore = Math.max(0, 100 - avgPanic * 0.3 - (100 - avgHealth) * 0.3 - this.state.casualties * 2)
  }

  // طرق إضافية للتحكم في المحاكاة
  public blockExit(exitId: number): void {
    const exit = this.state.exits.find((e) => e.id === exitId)
    if (exit) {
      exit.isBlocked = true
      this.emit("stateChanged", this.state)
    }
  }

  public unblockExit(exitId: number): void {
    const exit = this.state.exits.find((e) => e.id === exitId)
    if (exit) {
      exit.isBlocked = false
      this.emit("stateChanged", this.state)
    }
  }

  public moveSecurityTeam(index: number, x: number, y: number): void {
    if (index >= 0 && index < this.state.securityTeams.length) {
      this.state.securityTeams[index].x = x
      this.state.securityTeams[index].y = y
      this.emit("stateChanged", this.state)
    }
  }

  public moveMedicalTeam(index: number, x: number, y: number): void {
    if (index >= 0 && index < this.state.medicalTeams.length) {
      this.state.medicalTeams[index].x = x
      this.state.medicalTeams[index].y = y
      this.emit("stateChanged", this.state)
    }
  }
}
