import type React from "react"
import MobileLayout from "@/components/mobile-layout/mobile-layout"

export default function MobileAppLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <MobileLayout>{children}</MobileLayout>
}
