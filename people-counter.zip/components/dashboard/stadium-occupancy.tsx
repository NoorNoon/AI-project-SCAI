import type React from "react"

const StadiumOccupancy: React.FC = () => {
  // بيانات تمثيلية لإشغال المناطق المختلفة في الملعب
  const sections = [
    { id: "A", name: "المنطقة A", capacity: 10000, current: 6500, percentage: 65 },
    { id: "B", name: "المنطقة B", capacity: 12000, current: 8400, percentage: 70 },
    { id: "C", name: "المنطقة C", capacity: 8000, current: 4800, percentage: 60 },
    { id: "D", name: "المنطقة D", capacity: 15000, current: 5250, percentage: 35 },
  ]

  // تحديد لون الشريط بناءً على نسبة الإشغال
  const getBarColor = (percentage: number) => {
    if (percentage < 40) return "bg-green-500"
    if (percentage < 70) return "bg-amber-500"
    return "bg-red-500"
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sections.map((section) => (
          <div key={section.id} className="space-y-2">
            <div className="flex justify-between items-center">
              <div>
                <span className="font-medium">{section.name}</span>
                <span className="text-sm text-muted-foreground ml-2">
                  ({section.current.toLocaleString()} / {section.capacity.toLocaleString()})
                </span>
              </div>
              <span className="font-medium">{section.percentage}%</span>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className={`${getBarColor(section.percentage)} h-2.5 rounded-full`}
                style={{ width: `${section.percentage}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      <div className="border rounded-md p-4 mt-4">
        <div className="text-center mb-4">
          <h3 className="font-medium">خريطة الكثافة في الملعب</h3>
        </div>

        <div className="relative w-full aspect-video bg-gray-100 rounded-md overflow-hidden">
          {/* تمثيل بسيط لخريطة الملعب */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-3/4 h-2/3 border-2 border-gray-400 rounded-full flex items-center justify-center">
              <div className="w-1/2 h-2/3 border-2 border-gray-400 rounded-md flex">
                {/* المناطق المختلفة في الملعب */}
                <div className="w-1/4 h-full bg-red-200 opacity-70 flex items-center justify-center text-xs font-bold">
                  A
                </div>
                <div className="w-1/4 h-full bg-amber-200 opacity-70 flex items-center justify-center text-xs font-bold">
                  B
                </div>
                <div className="w-1/4 h-full bg-amber-200 opacity-70 flex items-center justify-center text-xs font-bold">
                  C
                </div>
                <div className="w-1/4 h-full bg-green-200 opacity-70 flex items-center justify-center text-xs font-bold">
                  D
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center mt-4 space-x-4 rtl:space-x-reverse">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
            <span className="text-xs">منخفضة (&lt;40%)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-amber-500 rounded-full mr-1"></div>
            <span className="text-xs">متوسطة (40-70%)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div>
            <span className="text-xs">مرتفعة (&gt;70%)</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default StadiumOccupancy
