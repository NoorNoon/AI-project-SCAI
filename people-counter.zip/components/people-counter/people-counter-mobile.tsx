"use client"

import type React from "react"

import { useRef, useState, useEffect } from "react"
import { Camera, Upload, Video, Play, Pause, RotateCcw, Database, AlertCircle, Sliders } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { yoloModel, type Detection } from "./yolo-model"
import { personTracker } from "./person-tracker"
import { useCrowdAnalysis } from "../context/crowd-analysis-context"
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible"

// حجم الملف الأقصى بالبايت (50 ميجابايت)
const MAX_FILE_SIZE = 50 * 1024 * 1024

// الأنواع المسموح بها للملفات
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"]
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime"]

const PeopleCounterMobile = () => {
  // استخدام سياق تحليل الحشود
  const {
    peopleCount,
    setPeopleCount,
    detections,
    setDetections,
    setProcessingTime: setGlobalProcessingTime,
    setIsProcessing: setGlobalIsProcessing,
    addHistoryEntry,
    saveCurrentResult,
    currentSession,
    sessions,
    createNewSession,
    confidenceThreshold: globalConfidenceThreshold,
    setConfidenceThreshold: setGlobalConfidenceThreshold,
  } = useCrowdAnalysis()

  // المراجع للعناصر
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // حالة التطبيق
  const [activeTab, setActiveTab] = useState<string>("camera")
  const [isModelLoaded, setIsModelLoaded] = useState<boolean>(false)
  const [isProcessing, setIsProcessing] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  const [confidenceThreshold, setConfidenceThreshold] = useState<number>(globalConfidenceThreshold)
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(false)
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [processingTime, setProcessingTime] = useState<number>(0)
  const [showSettings, setShowSettings] = useState<boolean>(false)
  const [isSaving, setIsSaving] = useState<boolean>(false)
  const [newSessionName, setNewSessionName] = useState<string>("")
  const [newSessionLocation, setNewSessionLocation] = useState<string>("")
  const [isSessionDialogOpen, setIsSessionDialogOpen] = useState<boolean>(false)

  // تحميل النموذج عند تحميل المكون
  useEffect(() => {
    const loadModel = async () => {
      try {
        setError(null)
        await yoloModel.load()
        setIsModelLoaded(true)
      } catch (err) {
        console.error("Failed to load YOLOv8 model:", err)
        setError("فشل في تحميل نموذج YOLOv8. يرجى التحقق من اتصالك بالإنترنت وتحديث الصفحة.")
      }
    }

    loadModel()

    // تنظيف الموارد عند إلغاء تحميل المكون
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
      yoloModel.dispose()
    }
  }, [])

  // تحديث الحالة العالمية عند تغيير الحالة المحلية
  useEffect(() => {
    setGlobalProcessingTime(processingTime)
    setGlobalIsProcessing(isProcessing)

    // إضافة إدخال جديد إلى سجل الحشود عند تغيير عدد الأشخاص بشكل كبير
    if (peopleCount > 0) {
      addHistoryEntry(peopleCount)
    }
  }, [
    peopleCount,
    detections,
    processingTime,
    isProcessing,
    setGlobalProcessingTime,
    setGlobalIsProcessing,
    addHistoryEntry,
  ])

  // مزامنة عتبة الثقة مع السياق العالمي
  useEffect(() => {
    setConfidenceThreshold(globalConfidenceThreshold)
  }, [globalConfidenceThreshold])

  // تبديل علامة التبويب النشطة
  const handleTabChange = (value: string) => {
    setActiveTab(value)

    // إيقاف الكاميرا عند تبديل علامة التبويب
    if (value !== "camera" && streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null

      if (videoRef.current) {
        videoRef.current.srcObject = null
      }
    }

    // إيقاف تشغيل الفيديو عند تبديل علامة التبويب
    if (value !== "video" && videoRef.current) {
      videoRef.current.pause()
      setIsVideoPlaying(false)
    }

    // بدء تشغيل الكاميرا إذا تم التبديل إلى علامة تبويب الكاميرا
    if (value === "camera") {
      startCamera()
    }

    // مسح الكشوفات والعدد
    setDetections([])
    setPeopleCount(0)

    // إعادة تعيين الخطأ
    setError(null)
  }

  // بدء تشغيل الكاميرا
  const startCamera = async () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      const constraints = {
        video: {
          facingMode: "environment",
        },
      }

      const stream = await navigator.mediaDevices.getUserMedia(constraints)
      streamRef.current = stream

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()

        // بدء معالجة الإطارات
        requestAnimationFrame(processVideoFrame)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("فشل في الوصول إلى الكاميرا. يرجى التأكد من السماح بالوصول إلى الكاميرا.")
    }
  }

  // معالجة إطار الفيديو
  const processVideoFrame = async () => {
    if (!videoRef.current || !canvasRef.current || !isModelLoaded || activeTab !== "camera") {
      return
    }

    try {
      setIsProcessing(true)
      const startTime = performance.now()

      // التأكد من أن الفيديو جاهز
      if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        // ضبط حجم الكانفاس ليتطابق مع الفيديو
        const videoWidth = videoRef.current.videoWidth
        const videoHeight = videoRef.current.videoHeight

        canvasRef.current.width = videoWidth
        canvasRef.current.height = videoHeight

        // اكتشاف الأشخاص في الإطار
        const detectedPeople = await yoloModel.detect(videoRef.current, confidenceThreshold, 0.45)

        // تتبع الأشخاص عبر الإطارات
        const trackedPeople = personTracker.update(detectedPeople)

        // تحديث عدد الأشخاص
        const count = trackedPeople.length
        setPeopleCount(count)
        setDetections(trackedPeople)

        // رسم الكشوفات على الكانفاس
        drawDetections(trackedPeople)

        // حساب وقت المعالجة
        const endTime = performance.now()
        setProcessingTime(endTime - startTime)
      }
    } catch (err) {
      console.error("Error processing video frame:", err)
    } finally {
      setIsProcessing(false)

      // استمرار معالجة الإطارات
      if (activeTab === "camera") {
        requestAnimationFrame(processVideoFrame)
      }
    }
  }

  // رسم الكشوفات على الكانفاس
  const drawDetections = (detections: Detection[]) => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // مسح الكانفاس
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    // رسم الفيديو أو الصورة على الكانفاس
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      ctx.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height)
    }

    // رسم الكشوفات
    detections.forEach((detection) => {
      const [x, y, width, height] = detection.bbox
      const color = detection.color || "#00FF00"

      // رسم صندوق الحدود
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      ctx.strokeRect(x, y, width, height)

      // رسم معرف الشخص ودرجة الثقة
      ctx.fillStyle = color
      ctx.font = "16px Arial"

      let label = `Person`
      if (detection.id) {
        label += ` #${detection.id}`
      }
      label += ` ${Math.round(detection.score * 100)}%`

      ctx.fillText(label, x, y > 20 ? y - 5 : y + 20)
    })
  }

  // معالجة تحميل الصورة
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // التحقق من نوع الملف
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      setError("نوع الملف غير مدعوم. يرجى تحميل صورة بتنسيق JPEG أو PNG أو WebP أو GIF.")
      return
    }

    // التحقق من حجم الملف
    if (file.size > MAX_FILE_SIZE) {
      setError("حجم الملف كبير جدًا. الحد الأقصى هو 50 ميجابايت.")
      return
    }

    try {
      setError(null)
      setIsProcessing(true)
      setImageFile(file)
      const startTime = performance.now()

      // إنشاء عنصر صورة
      const img = new Image()
      img.src = URL.createObjectURL(file)

      img.onload = async () => {
        if (!canvasRef.current) return

        // ضبط حجم الكانفاس ليتطابق مع الصورة
        canvasRef.current.width = img.width
        canvasRef.current.height = img.height

        // رسم الصورة على الكانفاس
        const ctx = canvasRef.current.getContext("2d")
        if (!ctx) return

        ctx.drawImage(img, 0, 0, img.width, img.height)

        // اكتشاف الأشخاص في الصورة
        const detectedPeople = await yoloModel.detect(canvasRef.current, confidenceThreshold, 0.45)

        // تحديث عدد الأشخاص
        const count = detectedPeople.length
        setPeopleCount(count)
        setDetections(detectedPeople)

        // رسم الكشوفات على الكانفاس
        drawDetections(detectedPeople)

        // حساب وقت المعالجة
        const endTime = performance.now()
        setProcessingTime(endTime - startTime)

        setIsProcessing(false)
      }

      img.onerror = () => {
        setError("فشل في تحميل الصورة. يرجى التحقق من الملف وإعادة المحاولة.")
        setIsProcessing(false)
      }
    } catch (err) {
      console.error("Error processing image:", err)
      setError("حدث خطأ أثناء معالجة الصورة. يرجى إعادة المحاولة.")
      setIsProcessing(false)
    }
  }

  // معالجة تحميل الفيديو
  const handleVideoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // التحقق من نوع الملف
    if (!ALLOWED_VIDEO_TYPES.includes(file.type)) {
      setError("نوع الملف غير مدعوم. يرجى تحميل فيديو بتنسيق MP4 أو WebM أو QuickTime.")
      return
    }

    // التحقق من حجم الملف
    if (file.size > MAX_FILE_SIZE) {
      setError("حجم الملف كبير جدًا. الحد الأقصى هو 50 ميجابايت.")
      return
    }

    try {
      setError(null)
      setVideoFile(file)

      // إعداد الفيديو
      if (videoRef.current) {
        videoRef.current.src = URL.createObjectURL(file)
        videoRef.current.onloadedmetadata = () => {
          if (canvasRef.current && videoRef.current) {
            canvasRef.current.width = videoRef.current.videoWidth
            canvasRef.current.height = videoRef.current.videoHeight
          }
        }
      }
    } catch (err) {
      console.error("Error loading video:", err)
      setError("حدث خطأ أثناء تحميل الفيديو. يرجى إعادة المحاولة.")
    }
  }

  // تشغيل/إيقاف الفيديو
  const toggleVideoPlayback = () => {
    if (!videoRef.current) return

    if (isVideoPlaying) {
      videoRef.current.pause()
      setIsVideoPlaying(false)
    } else {
      videoRef.current.play()
      setIsVideoPlaying(true)
      processVideoFrames()
    }
  }

  // معالجة إطارات الفيديو
  const processVideoFrames = async () => {
    if (!videoRef.current || !canvasRef.current || !isModelLoaded || activeTab !== "video" || !isVideoPlaying) {
      return
    }

    try {
      setIsProcessing(true)
      const startTime = performance.now()

      // التأكد من أن الفيديو جاهز
      if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        // ضبط حجم الكانفاس ليتطابق مع الفيديو
        const videoWidth = videoRef.current.videoWidth
        const videoHeight = videoRef.current.videoHeight

        canvasRef.current.width = videoWidth
        canvasRef.current.height = videoHeight

        // اكتشاف الأشخاص في الإطار
        const detectedPeople = await yoloModel.detect(videoRef.current, confidenceThreshold, 0.45)

        // تتبع الأشخاص عبر الإطارات
        const trackedPeople = personTracker.update(detectedPeople)

        // تحديث عدد الأشخاص
        const count = trackedPeople.length
        setPeopleCount(count)
        setDetections(trackedPeople)

        // رسم الكشوفات على الكانفاس
        drawDetections(trackedPeople)

        // حساب وقت المعالجة
        const endTime = performance.now()
        setProcessingTime(endTime - startTime)
      }
    } catch (err) {
      console.error("Error processing video frame:", err)
    } finally {
      setIsProcessing(false)

      // استمرار معالجة الإطارات إذا كان الفيديو قيد التشغيل
      if (activeTab === "video" && isVideoPlaying) {
        requestAnimationFrame(processVideoFrames)
      }
    }
  }

  // إعادة تعيين الفيديو
  const resetVideo = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0

      if (isVideoPlaying) {
        videoRef.current.play()
      }
    }
  }

  // تغيير عتبة الثقة
  const handleConfidenceChange = (value: number[]) => {
    setConfidenceThreshold(value[0])
    setGlobalConfidenceThreshold(value[0])
  }

  // حفظ النتيجة الحالية في قاعدة البيانات
  const handleSaveToDatabase = async () => {
    if (!currentSession) {
      setIsSessionDialogOpen(true)
      return
    }

    if (peopleCount === 0) {
      setError("لا توجد نتائج للحفظ. يرجى تحليل صورة أو فيديو أولاً.")
      return
    }

    try {
      setIsSaving(true)

      // تحويل الكانفاس إلى URL للصورة
      const imageUrl = canvasRef.current?.toDataURL("image/jpeg") || undefined

      await saveCurrentResult(imageUrl)

      setError(null)
      // إظهار رسالة نجاح
      alert("تم حفظ النتيجة بنجاح في قاعدة البيانات!")
    } catch (err) {
      console.error("Error saving to database:", err)
      setError("حدث خطأ أثناء حفظ النتيجة في قاعدة البيانات.")
    } finally {
      setIsSaving(false)
    }
  }

  // إنشاء جلسة جديدة
  const handleCreateSession = async () => {
    if (!newSessionName) {
      setError("يرجى إدخال اسم للجلسة.")
      return
    }

    try {
      await createNewSession(newSessionName, newSessionLocation || undefined)
      setNewSessionName("")
      setNewSessionLocation("")
      setIsSessionDialogOpen(false)
      setError(null)
    } catch (err) {
      console.error("Error creating session:", err)
      setError("حدث خطأ أثناء إنشاء الجلسة.")
    }
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">عداد الأشخاص</h1>
        <Button variant="outline" size="icon" onClick={() => setShowSettings(!showSettings)}>
          <Sliders className="h-4 w-4" />
        </Button>
      </div>

      <Collapsible open={showSettings} onOpenChange={setShowSettings}>
        <CollapsibleContent className="space-y-4 py-2 slide-up">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">عتبة الثقة: {confidenceThreshold.toFixed(2)}</span>
              <span className="text-xs text-muted-foreground">
                {confidenceThreshold < 0.3 ? "منخفضة" : confidenceThreshold < 0.6 ? "متوسطة" : "عالية"}
              </span>
            </div>
            <Slider
              min={0.1}
              max={0.9}
              step={0.05}
              value={[confidenceThreshold]}
              onValueChange={handleConfidenceChange}
            />
          </div>

          <div className="flex items-center justify-between text-sm">
            <span>الجلسة الحالية:</span>
            {currentSession ? (
              <span className="font-medium">{currentSession.session_name}</span>
            ) : (
              <span className="text-muted-foreground">لا توجد جلسة</span>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="camera" className="text-xs">
            <Camera className="h-4 w-4 mr-1" />
            الكاميرا
          </TabsTrigger>
          <TabsTrigger value="image" className="text-xs">
            <Upload className="h-4 w-4 mr-1" />
            صورة
          </TabsTrigger>
          <TabsTrigger value="video" className="text-xs">
            <Video className="h-4 w-4 mr-1" />
            فيديو
          </TabsTrigger>
        </TabsList>

        <TabsContent value="camera" className="space-y-4">
          <div className="relative rounded-lg overflow-hidden border">
            <video ref={videoRef} className="w-full h-auto hidden" autoPlay playsInline muted />
            <canvas ref={canvasRef} className="w-full h-auto" />
            {isProcessing && (
              <div className="absolute top-2 right-2 bg-primary/80 text-primary-foreground px-2 py-1 rounded-full text-xs flex items-center">
                <div className="h-2 w-2 bg-white rounded-full mr-2 animate-pulse"></div>
                جاري التحليل...
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="image" className="space-y-4">
          <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-6">
            <Input
              ref={fileInputRef}
              type="file"
              accept={ALLOWED_IMAGE_TYPES.join(",")}
              onChange={handleImageUpload}
              className="hidden"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="bg-primary text-primary-foreground"
            >
              <Upload className="h-4 w-4 mr-2" />
              تحميل صورة
            </Button>
          </div>

          {imageFile && (
            <div className="relative rounded-lg overflow-hidden border">
              <canvas ref={canvasRef} className="w-full h-auto" />
              {isProcessing && (
                <div className="absolute top-2 right-2 bg-primary/80 text-primary-foreground px-2 py-1 rounded-full text-xs flex items-center">
                  <div className="h-2 w-2 bg-white rounded-full mr-2 animate-pulse"></div>
                  جاري التحليل...
                </div>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="video" className="space-y-4">
          <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-6">
            <Input
              ref={videoInputRef}
              type="file"
              accept={ALLOWED_VIDEO_TYPES.join(",")}
              onChange={handleVideoUpload}
              className="hidden"
            />
            <Button
              onClick={() => videoInputRef.current?.click()}
              disabled={isProcessing}
              className="bg-primary text-primary-foreground"
            >
              <Upload className="h-4 w-4 mr-2" />
              تحميل فيديو
            </Button>
          </div>

          {videoFile && (
            <>
              <div className="relative rounded-lg overflow-hidden border">
                <video ref={videoRef} className="w-full h-auto hidden" playsInline muted />
                <canvas ref={canvasRef} className="w-full h-auto" />
                {isProcessing && (
                  <div className="absolute top-2 right-2 bg-primary/80 text-primary-foreground px-2 py-1 rounded-full text-xs flex items-center">
                    <div className="h-2 w-2 bg-white rounded-full mr-2 animate-pulse"></div>
                    جاري التحليل...
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Button onClick={toggleVideoPlayback} className="flex-1">
                  {isVideoPlaying ? (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      إيقاف
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      تشغيل
                    </>
                  )}
                </Button>

                <Button variant="outline" onClick={resetVideo}>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  إعادة
                </Button>
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Card className="stat-card">
            <div className="stat-card-label">عدد الأشخاص</div>
            <div className="stat-card-value">{peopleCount}</div>
          </Card>

          <Card className="stat-card">
            <div className="stat-card-label">الكثافة</div>
            <div className="stat-card-value text-xl">
              {peopleCount === 0 && "منخفضة جدًا"}
              {peopleCount > 0 && peopleCount <= 5 && "منخفضة"}
              {peopleCount > 5 && peopleCount <= 15 && "متوسطة"}
              {peopleCount > 15 && peopleCount <= 30 && "عالية"}
              {peopleCount > 30 && "عالية جدًا"}
            </div>
          </Card>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center">
            {isProcessing ? (
              <div className="flex items-center text-blue-500">
                <div className="h-2 w-2 bg-blue-500 rounded-full mr-2 animate-pulse"></div>
                جاري التفكير...
              </div>
            ) : (
              <div className="flex items-center text-green-500">
                <div className="h-2 w-2 bg-green-500 rounded-full mr-2"></div>
                جاهز
              </div>
            )}
          </div>

          {processingTime > 0 && (
            <div className="text-muted-foreground">وقت المعالجة: {processingTime.toFixed(1)} مللي ثانية</div>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start">
            <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      <Button
        onClick={handleSaveToDatabase}
        disabled={isProcessing || isSaving || peopleCount === 0}
        className="w-full bg-primary text-primary-foreground"
      >
        <Database className="h-4 w-4 mr-2" />
        {isSaving ? "جاري الحفظ..." : "حفظ في قاعدة البيانات"}
      </Button>

      <Dialog open={isSessionDialogOpen} onOpenChange={setIsSessionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إنشاء جلسة تحليل جديدة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="session-name" className="text-sm font-medium">
                اسم الجلسة
              </label>
              <Input
                id="session-name"
                placeholder="أدخل اسم الجلسة"
                value={newSessionName}
                onChange={(e) => setNewSessionName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="session-location" className="text-sm font-medium">
                الموقع (اختياري)
              </label>
              <Input
                id="session-location"
                placeholder="أدخل موقع الجلسة"
                value={newSessionLocation}
                onChange={(e) => setNewSessionLocation(e.target.value)}
              />
            </div>
            <Button onClick={handleCreateSession} className="w-full">
              إنشاء جلسة
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default PeopleCounterMobile
