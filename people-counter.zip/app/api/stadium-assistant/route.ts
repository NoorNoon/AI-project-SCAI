import { NextResponse } from "next/server"
import { getChatResponse, formatMessagesForAPI } from "@/lib/ai-chat-model"

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // إذا كانت هذه أول رسالة، قدم ترحيباً
    if (!messages || messages.length <= 1) {
      return NextResponse.json({
        response: "مرحباً! أنا مساعد الملعب الذكي. كيف يمكنني مساعدتك اليوم؟",
      })
    }

    // الحصول على آخر رسالة من المستخدم
    const lastUserMessage = messages[messages.length - 1].content

    // تنسيق الرسائل للواجهة البرمجية
    const formattedMessages = formatMessagesForAPI(messages)

    // الحصول على رد من نموذج الدردشة
    const response = await getChatResponse(formattedMessages, lastUserMessage)

    return NextResponse.json({ response })
  } catch (error) {
    console.error("Error in stadium assistant:", error)
    return NextResponse.json({ response: "حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى." }, { status: 500 })
  }
}
