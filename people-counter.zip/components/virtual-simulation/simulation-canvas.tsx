"use client"

import type React from "react"
import { useRef, useEffect, useState } from "react"
import type { SimulationEngine, SimulationState, EmergencyType } from "./simulation-engine"

interface SimulationCanvasProps {
  width: number
  height: number
  engine: SimulationEngine
}

const SimulationCanvas: React.FC<SimulationCanvasProps> = ({ width, height, engine }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [state, setState] = useState<SimulationState>(engine.getState())
  const [selectedTool, setSelectedTool] = useState<
    "move" | "people" | "fire" | "riot" | "medical" | "congestion" | "security" | "medical-team"
  >("move")
  const [isDragging, setIsDragging] = useState(false)
  const [dragTarget, setDragTarget] = useState<{ type: string; index: number } | null>(null)

  useEffect(() => {
    const handleStateChanged = (newState: SimulationState) => {
      setState({ ...newState })
    }

    engine.on("stateChanged", handleStateChanged)

    return () => {
      engine.off("stateChanged", handleStateChanged)
    }
  }, [engine])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // تنظيف الكانفاس
    ctx.clearRect(0, 0, width, height)

    // رسم خلفية الاستاد
    drawStadium(ctx)

    // رسم المخارج
    state.exits.forEach((exit) => {
      ctx.beginPath()
      ctx.arc(exit.x, exit.y, 15, 0, Math.PI * 2)
      ctx.fillStyle = exit.isBlocked ? "#ff6b6b" : "#4cd137"
      ctx.fill()
      ctx.strokeStyle = "#333"
      ctx.lineWidth = 2
      ctx.stroke()

      // رسم أيقونة المخرج
      ctx.fillStyle = "#fff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("EXIT", exit.x, exit.y)

      // رسم مؤشر الحمل
      if (exit.currentLoad > 0) {
        const loadPercentage = Math.min(100, (exit.currentLoad / exit.capacity) * 100)
        ctx.fillStyle = loadPercentage > 80 ? "#ff6b6b" : loadPercentage > 50 ? "#ffa502" : "#4cd137"
        ctx.fillRect(exit.x - 15, exit.y + 20, 30 * (loadPercentage / 100), 5)
        ctx.strokeStyle = "#333"
        ctx.strokeRect(exit.x - 15, exit.y + 20, 30, 5)
      }
    })

    // رسم فرق الأمن
    state.securityTeams.forEach((team, index) => {
      ctx.beginPath()
      ctx.arc(team.x, team.y, team.radius, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(52, 152, 219, 0.2)"
      ctx.fill()

      ctx.beginPath()
      ctx.arc(team.x, team.y, 15, 0, Math.PI * 2)
      ctx.fillStyle = "#3498db"
      ctx.fill()
      ctx.strokeStyle = "#2980b9"
      ctx.lineWidth = 2
      ctx.stroke()

      // رسم أيقونة فريق الأمن
      ctx.fillStyle = "#fff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("👮", team.x, team.y)
    })

    // رسم الفرق الطبية
    state.medicalTeams.forEach((team, index) => {
      ctx.beginPath()
      ctx.arc(team.x, team.y, team.radius, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(231, 76, 60, 0.2)"
      ctx.fill()

      ctx.beginPath()
      ctx.arc(team.x, team.y, 15, 0, Math.PI * 2)
      ctx.fillStyle = "#e74c3c"
      ctx.fill()
      ctx.strokeStyle = "#c0392b"
      ctx.lineWidth = 2
      ctx.stroke()

      // رسم أيقونة الفريق الطبي
      ctx.fillStyle = "#fff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("🏥", team.x, team.y)
    })

    // رسم حالات الطوارئ
    state.emergencies.forEach((emergency) => {
      // رسم منطقة التأثير
      ctx.beginPath()
      ctx.arc(emergency.x, emergency.y, emergency.radius, 0, Math.PI * 2)

      let fillColor = "rgba(255, 0, 0, 0.3)"
      let strokeColor = "#ff0000"
      let icon = "🔥"

      switch (emergency.type) {
        case "fire":
          fillColor = "rgba(255, 0, 0, 0.3)"
          strokeColor = "#ff0000"
          icon = "🔥"
          break
        case "riot":
          fillColor = "rgba(255, 165, 0, 0.3)"
          strokeColor = "#ffa500"
          icon = "⚠️"
          break
        case "medical":
          fillColor = "rgba(255, 0, 255, 0.3)"
          strokeColor = "#ff00ff"
          icon = "🚑"
          break
        case "congestion":
          fillColor = "rgba(0, 0, 255, 0.3)"
          strokeColor = "#0000ff"
          icon = "👥"
          break
      }

      ctx.fillStyle = fillColor
      ctx.fill()
      ctx.strokeStyle = strokeColor
      ctx.lineWidth = 2
      ctx.stroke()

      // رسم أيقونة الطوارئ
      ctx.fillStyle = "#fff"
      ctx.font = "20px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(icon, emergency.x, emergency.y)

      // رسم مؤشر الشدة
      ctx.fillStyle = emergency.intensity > 70 ? "#ff6b6b" : emergency.intensity > 40 ? "#ffa502" : "#4cd137"
      ctx.fillRect(emergency.x - 20, emergency.y + 20, 40 * (emergency.intensity / 100), 5)
      ctx.strokeStyle = "#333"
      ctx.strokeRect(emergency.x - 20, emergency.y + 20, 40, 5)
    })

    // رسم الأشخاص
    state.people.forEach((person) => {
      ctx.beginPath()

      let radius = 5
      let fillColor = "#2ecc71"

      // تحديد لون وحجم الشخص بناءً على حالته
      switch (person.status) {
        case "normal":
          fillColor =
            person.type === "spectator"
              ? "#2ecc71"
              : person.type === "security"
                ? "#3498db"
                : person.type === "medical"
                  ? "#e74c3c"
                  : "#f1c40f"
          radius = 5
          break
        case "panicked":
          fillColor = "#f39c12"
          radius = 6
          break
        case "injured":
          fillColor = "#c0392b"
          radius = 6
          break
        case "evacuating":
          fillColor = "#9b59b6"
          radius = 5
          break
      }

      ctx.arc(person.x, person.y, radius, 0, Math.PI * 2)
      ctx.fillStyle = fillColor
      ctx.fill()

      // رسم خط يشير إلى الاتجاه إذا كان الشخص يتحرك
      if (person.vx !== 0 || person.vy !== 0) {
        const speed = Math.sqrt(person.vx * person.vx + person.vy * person.vy)
        const dirX = person.vx / speed
        const dirY = person.vy / speed

        ctx.beginPath()
        ctx.moveTo(person.x, person.y)
        ctx.lineTo(person.x + dirX * 10, person.y + dirY * 10)
        ctx.strokeStyle = fillColor
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // رسم مؤشر الصحة إذا كانت أقل من 100
      if (person.health < 100) {
        ctx.fillStyle = person.health > 70 ? "#4cd137" : person.health > 30 ? "#ffa502" : "#ff6b6b"
        ctx.fillRect(person.x - 5, person.y - 10, 10 * (person.health / 100), 2)
        ctx.strokeStyle = "#333"
        ctx.strokeRect(person.x - 5, person.y - 10, 10, 2)
      }
    })
  }, [state, width, height])

  const drawStadium = (ctx: CanvasRenderingContext2D) => {
    // رسم أرضية الملعب
    ctx.fillStyle = "#229954"
    ctx.fillRect(width * 0.2, height * 0.2, width * 0.6, height * 0.6)

    // رسم المدرجات
    ctx.fillStyle = "#7f8c8d"

    // المدرجات الشمالية
    ctx.fillRect(width * 0.2, 0, width * 0.6, height * 0.2)

    // المدرجات الجنوبية
    ctx.fillRect(width * 0.2, height * 0.8, width * 0.6, height * 0.2)

    // المدرجات الشرقية
    ctx.fillRect(0, height * 0.2, width * 0.2, height * 0.6)

    // المدرجات الغربية
    ctx.fillRect(width * 0.8, height * 0.2, width * 0.2, height * 0.6)

    // رسم خطوط الملعب
    ctx.strokeStyle = "#fff"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.25, height * 0.25, width * 0.5, height * 0.5)

    // رسم دائرة المنتصف
    ctx.beginPath()
    ctx.arc(width * 0.5, height * 0.5, width * 0.1, 0, Math.PI * 2)
    ctx.stroke()

    // رسم نقطة المنتصف
    ctx.beginPath()
    ctx.arc(width * 0.5, height * 0.5, 5, 0, Math.PI * 2)
    ctx.fillStyle = "#fff"
    ctx.fill()

    // رسم مناطق الجزاء
    // المنطقة اليسرى
    ctx.strokeRect(width * 0.25, height * 0.35, width * 0.1, height * 0.3)

    // المنطقة اليمنى
    ctx.strokeRect(width * 0.65, height * 0.35, width * 0.1, height * 0.3)
  }

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    switch (selectedTool) {
      case "people":
        engine.addPeople(10, "spectator")
        break
      case "fire":
      case "riot":
      case "medical":
      case "congestion":
        engine.createEmergency(selectedTool as EmergencyType, x, y)
        break
      case "security":
        // تحريك أقرب فريق أمن
        moveClosestSecurityTeam(x, y)
        break
      case "medical-team":
        // تحريك أقرب فريق طبي
        moveClosestMedicalTeam(x, y)
        break
    }
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (selectedTool !== "move") return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // التحقق مما إذا كان النقر على فريق أمن
    for (let i = 0; i < state.securityTeams.length; i++) {
      const team = state.securityTeams[i]
      const distance = Math.sqrt(Math.pow(team.x - x, 2) + Math.pow(team.y - y, 2))

      if (distance < 15) {
        setIsDragging(true)
        setDragTarget({ type: "security", index: i })
        return
      }
    }

    // التحقق مما إذا كان النقر على فريق طبي
    for (let i = 0; i < state.medicalTeams.length; i++) {
      const team = state.medicalTeams[i]
      const distance = Math.sqrt(Math.pow(team.x - x, 2) + Math.pow(team.y - y, 2))

      if (distance < 15) {
        setIsDragging(true)
        setDragTarget({ type: "medical", index: i })
        return
      }
    }
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !dragTarget) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    if (dragTarget.type === "security") {
      engine.moveSecurityTeam(dragTarget.index, x, y)
    } else if (dragTarget.type === "medical") {
      engine.moveMedicalTeam(dragTarget.index, x, y)
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    setDragTarget(null)
  }

  const moveClosestSecurityTeam = (x: number, y: number) => {
    if (state.securityTeams.length === 0) return

    let closestIndex = 0
    let minDistance = Number.MAX_VALUE

    state.securityTeams.forEach((team, index) => {
      const distance = Math.sqrt(Math.pow(team.x - x, 2) + Math.pow(team.y - y, 2))

      if (distance < minDistance) {
        minDistance = distance
        closestIndex = index
      }
    })

    engine.moveSecurityTeam(closestIndex, x, y)
  }

  const moveClosestMedicalTeam = (x: number, y: number) => {
    if (state.medicalTeams.length === 0) return

    let closestIndex = 0
    let minDistance = Number.MAX_VALUE

    state.medicalTeams.forEach((team, index) => {
      const distance = Math.sqrt(Math.pow(team.x - x, 2) + Math.pow(team.y - y, 2))

      if (distance < minDistance) {
        minDistance = distance
        closestIndex = index
      }
    })

    engine.moveMedicalTeam(closestIndex, x, y)
  }

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        onClick={handleCanvasClick}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="border border-gray-800 bg-gray-900 rounded-lg cursor-pointer"
      />

      <div className="absolute bottom-4 left-4 flex space-x-2">
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "move" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("move")}
        >
          تحريك
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "people" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("people")}
        >
          إضافة أشخاص
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "fire" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("fire")}
        >
          حريق
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "riot" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("riot")}
        >
          شغب
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "medical" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("medical")}
        >
          إغماء
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "congestion" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("congestion")}
        >
          ازدحام
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "security" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("security")}
        >
          فريق أمن
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm ${selectedTool === "medical-team" ? "bg-yellow-500 text-black" : "bg-gray-700 text-white"}`}
          onClick={() => setSelectedTool("medical-team")}
        >
          فريق طبي
        </button>
      </div>
    </div>
  )
}

export default SimulationCanvas
