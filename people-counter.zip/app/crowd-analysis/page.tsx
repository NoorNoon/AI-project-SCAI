import PeopleCounterPage from "@/components/people-counter/people-counter-page"

export default function CrowdAnalysisPage() {
  return <PeopleCounterPage />
}
