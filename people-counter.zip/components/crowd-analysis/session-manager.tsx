"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { format } from "date-fns"
import { ar } from "date-fns/locale"
import { Plus, RefreshCw, Trash2 } from "lucide-react"
import { useCrowdAnalysis } from "../context/crowd-analysis-context"
import { deleteSession } from "@/lib/crowd-analysis-service"

const SessionManager = () => {
  const { sessions, loadSessions, createNewSession } = useCrowdAnalysis()

  const [newSessionName, setNewSessionName] = useState<string>("")
  const [newSessionLocation, setNewSessionLocation] = useState<string>("")
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [sessionToDelete, setSessionToDelete] = useState<string | null>(null)

  // إنشاء جلسة جديدة
  const handleCreateSession = async () => {
    if (!newSessionName) return

    setIsLoading(true)
    try {
      await createNewSession(newSessionName, newSessionLocation || undefined)
      setNewSessionName("")
      setNewSessionLocation("")
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error creating session:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // حذف جلسة
  const handleDeleteSession = async () => {
    if (!sessionToDelete) return

    setIsLoading(true)
    try {
      const success = await deleteSession(sessionToDelete)
      if (success) {
        await loadSessions()
      }
    } catch (error) {
      console.error("Error deleting session:", error)
    } finally {
      setIsLoading(false)
      setSessionToDelete(null)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>إدارة جلسات التحليل</CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={loadSessions}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                جلسة جديدة
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>إنشاء جلسة تحليل جديدة</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="session-name">اسم الجلسة</Label>
                  <Input
                    id="session-name"
                    placeholder="أدخل اسم الجلسة"
                    value={newSessionName}
                    onChange={(e) => setNewSessionName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="session-location">الموقع (اختياري)</Label>
                  <Input
                    id="session-location"
                    placeholder="أدخل موقع الجلسة"
                    value={newSessionLocation}
                    onChange={(e) => setNewSessionLocation(e.target.value)}
                  />
                </div>
                <Button onClick={handleCreateSession} className="w-full" disabled={!newSessionName || isLoading}>
                  {isLoading ? "جاري الإنشاء..." : "إنشاء جلسة"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>اسم الجلسة</TableHead>
                <TableHead>الموقع</TableHead>
                <TableHead>تاريخ الإنشاء</TableHead>
                <TableHead>آخر تحديث</TableHead>
                <TableHead className="w-[80px]">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sessions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">
                    لا توجد جلسات
                  </TableCell>
                </TableRow>
              ) : (
                sessions.map((session) => (
                  <TableRow key={session.id}>
                    <TableCell>{session.session_name || "بدون اسم"}</TableCell>
                    <TableCell>{session.location || "-"}</TableCell>
                    <TableCell>{format(new Date(session.created_at), "yyyy-MM-dd HH:mm", { locale: ar })}</TableCell>
                    <TableCell>{format(new Date(session.updated_at), "yyyy-MM-dd HH:mm", { locale: ar })}</TableCell>
                    <TableCell>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => setSessionToDelete(session.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>هل أنت متأكد من حذف هذه الجلسة؟</AlertDialogTitle>
                            <AlertDialogDescription>
                              سيتم حذف الجلسة وجميع نتائج التحليل المرتبطة بها. هذا الإجراء لا يمكن التراجع عنه.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setSessionToDelete(null)}>إلغاء</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteSession} className="bg-red-500 hover:bg-red-600">
                              حذف
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

export default SessionManager
