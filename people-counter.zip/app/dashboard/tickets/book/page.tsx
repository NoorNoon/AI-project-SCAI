"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ChevronLeft, CreditCard } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function BookTicketPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedMatch, setSelectedMatch] = useState("match1")
  const [selectedSection, setSelectedSection] = useState("")
  const [selectedRow, setSelectedRow] = useState("")
  const [selectedSeat, setSelectedSeat] = useState("")
  const [ticketType, setTicketType] = useState("standard")
  const [isBooking, setIsBooking] = useState(false)
  const [step, setStep] = useState(1)

  // Simulated data
  const matches = [
    {
      id: "match1",
      homeTeam: "الهلال",
      awayTeam: "النصر",
      date: "الجمعة، 15 نوفمبر",
      time: "9:00 م",
      stadium: "استاد الملك فهد الدولي",
      price: 150,
    },
    {
      id: "match2",
      homeTeam: "الاتحاد",
      awayTeam: "الأهلي",
      date: "السبت، 16 نوفمبر",
      time: "8:30 م",
      stadium: "استاد الجوهرة",
      price: 120,
    },
    {
      id: "match3",
      homeTeam: "الاتفاق",
      awayTeam: "التعاون",
      date: "الأحد، 17 نوفمبر",
      time: "7:00 م",
      stadium: "استاد الأمير محمد بن فهد",
      price: 100,
    },
  ]

  const sections = ["A", "B", "C", "D", "VIP"]
  const rows = Array.from({ length: 20 }, (_, i) => (i + 1).toString())
  const seats = Array.from({ length: 30 }, (_, i) => (i + 1).toString())

  // AI-based crowd density simulation
  const [crowdDensity, setCrowdDensity] = useState<Record<string, number>>({
    A: 85,
    B: 65,
    C: 45,
    D: 75,
    VIP: 30,
  })

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))
    setLoading(false)

    // Simulate AI crowd analysis
    const interval = setInterval(() => {
      setCrowdDensity((prev) => {
        const updated = { ...prev }
        const keys = Object.keys(updated)
        const randomKey = keys[Math.floor(Math.random() * keys.length)]
        const change = Math.floor(Math.random() * 10) - 5 // -5 to +5
        updated[randomKey] = Math.max(10, Math.min(95, updated[randomKey] + change))
        return updated
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [router])

  const handleBookTicket = async () => {
    setIsBooking(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Get existing tickets or initialize empty array
      const existingTickets = JSON.parse(localStorage.getItem("tickets") || "[]")

      // Add new ticket
      const selectedMatchData = matches.find((match) => match.id === selectedMatch)
      const newTicket = {
        id: Date.now().toString(),
        matchId: selectedMatch,
        homeTeam: selectedMatchData?.homeTeam,
        awayTeam: selectedMatchData?.awayTeam,
        date: selectedMatchData?.date,
        time: selectedMatchData?.time,
        stadium: selectedMatchData?.stadium,
        section: selectedSection,
        row: selectedRow,
        seat: selectedSeat,
        type: ticketType,
        price: ticketType === "vip" ? (selectedMatchData?.price || 0) * 2 : selectedMatchData?.price,
        purchaseDate: new Date().toLocaleDateString("ar-SA"),
      }

      localStorage.setItem("tickets", JSON.stringify([...existingTickets, newTicket]))

      // Redirect to tickets page
      router.push("/dashboard/tickets")
    } catch (error) {
      console.error("Error booking ticket:", error)
    } finally {
      setIsBooking(false)
    }
  }

  const getTicketPrice = () => {
    const basePrice = matches.find((match) => match.id === selectedMatch)?.price || 0
    return ticketType === "vip" ? basePrice * 2 : basePrice
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black pb-20 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center">
          <Link href="/dashboard" className="ml-4">
            <Button variant="ghost" size="icon">
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">حجز تذكرة</h1>
        </div>

        {/* Booking Steps */}
        <div className="mb-8">
          <div className="mb-2 flex justify-between">
            <span className={step >= 1 ? "text-yellow-500" : "text-gray-500"}>اختيار المباراة</span>
            <span className={step >= 2 ? "text-yellow-500" : "text-gray-500"}>اختيار المقعد</span>
            <span className={step >= 3 ? "text-yellow-500" : "text-gray-500"}>الدفع</span>
          </div>
          <Progress value={(step / 3) * 100} className="h-2 bg-gray-700">
            <div className="h-full bg-yellow-500" style={{ width: `${(step / 3) * 100}%` }} />
          </Progress>
        </div>

        {step === 1 && (
          <Card className="border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <h2 className="mb-4 text-xl font-semibold">اختر المباراة</h2>

              <div className="space-y-4">
                {matches.map((match) => (
                  <div
                    key={match.id}
                    className={`cursor-pointer rounded-lg border p-4 transition-colors ${
                      selectedMatch === match.id
                        ? "border-yellow-500 bg-yellow-500/10"
                        : "border-gray-700 bg-gray-800 hover:border-gray-600"
                    }`}
                    onClick={() => setSelectedMatch(match.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">
                          {match.homeTeam} ضد {match.awayTeam}
                        </div>
                        <div className="mt-1 text-sm text-gray-400">
                          {match.date} - {match.time}
                        </div>
                        <div className="mt-1 text-sm text-gray-400">{match.stadium}</div>
                      </div>
                      <div className="text-lg font-bold text-yellow-500">{match.price} ريال</div>
                    </div>
                  </div>
                ))}
              </div>

              <Button className="mt-6 w-full bg-yellow-500 text-black hover:bg-yellow-600" onClick={() => setStep(2)}>
                التالي
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card className="border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <h2 className="mb-4 text-xl font-semibold">اختر المقعد</h2>

              <div className="mb-6 space-y-4">
                <div className="space-y-2">
                  <Label>القسم</Label>
                  <Select value={selectedSection} onValueChange={setSelectedSection}>
                    <SelectTrigger className="border-gray-700 bg-gray-800">
                      <SelectValue placeholder="اختر القسم" />
                    </SelectTrigger>
                    <SelectContent>
                      {sections.map((section) => (
                        <SelectItem key={section} value={section}>
                          <div className="flex items-center justify-between">
                            <span>القسم {section}</span>
                            <Badge
                              className={
                                crowdDensity[section] > 80
                                  ? "bg-red-500"
                                  : crowdDensity[section] > 60
                                    ? "bg-yellow-500 text-black"
                                    : "bg-green-500"
                              }
                            >
                              {crowdDensity[section] > 80 ? "مزدحم" : crowdDensity[section] > 60 ? "متوسط" : "متاح"}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>الصف</Label>
                  <Select value={selectedRow} onValueChange={setSelectedRow} disabled={!selectedSection}>
                    <SelectTrigger className="border-gray-700 bg-gray-800">
                      <SelectValue placeholder="اختر الصف" />
                    </SelectTrigger>
                    <SelectContent>
                      {rows.map((row) => (
                        <SelectItem key={row} value={row}>
                          صف {row}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>المقعد</Label>
                  <Select value={selectedSeat} onValueChange={setSelectedSeat} disabled={!selectedRow}>
                    <SelectTrigger className="border-gray-700 bg-gray-800">
                      <SelectValue placeholder="اختر المقعد" />
                    </SelectTrigger>
                    <SelectContent>
                      {seats.map((seat) => (
                        <SelectItem key={seat} value={seat}>
                          مقعد {seat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>نوع التذكرة</Label>
                  <RadioGroup value={ticketType} onValueChange={setTicketType}>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="standard" id="standard" />
                      <Label htmlFor="standard">قياسية</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="vip" id="vip" />
                      <Label htmlFor="vip">VIP (ضعف السعر)</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              {/* Stadium Map */}
              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <h3 className="mb-2 font-medium">خريطة الملعب</h3>
                <div className="relative aspect-video overflow-hidden rounded bg-gray-700">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <img
                      src="/placeholder.svg?height=300&width=500&text=Stadium+Map"
                      alt="خريطة الملعب"
                      className="h-full w-full object-cover"
                    />
                    {selectedSection && (
                      <div className="absolute">
                        <div className="rounded-full bg-yellow-500 px-3 py-1 text-sm font-bold text-black">
                          القسم {selectedSection}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-400">
                  <span className="ml-2 inline-block h-3 w-3 rounded-full bg-green-500"></span> متاح
                  <span className="mx-2 inline-block h-3 w-3 rounded-full bg-yellow-500"></span> متوسط
                  <span className="mx-2 inline-block h-3 w-3 rounded-full bg-red-500"></span> مزدحم
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  السابق
                </Button>
                <Button
                  className="bg-yellow-500 text-black hover:bg-yellow-600"
                  onClick={() => setStep(3)}
                  disabled={!selectedSection || !selectedRow || !selectedSeat}
                >
                  التالي
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card className="border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <h2 className="mb-4 text-xl font-semibold">تأكيد الحجز والدفع</h2>

              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <h3 className="mb-3 font-medium">تفاصيل التذكرة</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">المباراة:</span>
                    <span>
                      {matches.find((match) => match.id === selectedMatch)?.homeTeam} ضد{" "}
                      {matches.find((match) => match.id === selectedMatch)?.awayTeam}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">التاريخ والوقت:</span>
                    <span>
                      {matches.find((match) => match.id === selectedMatch)?.date} -{" "}
                      {matches.find((match) => match.id === selectedMatch)?.time}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">الملعب:</span>
                    <span>{matches.find((match) => match.id === selectedMatch)?.stadium}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">القسم:</span>
                    <span>القسم {selectedSection}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">الصف:</span>
                    <span>صف {selectedRow}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">المقعد:</span>
                    <span>مقعد {selectedSeat}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">نوع التذكرة:</span>
                    <span>{ticketType === "vip" ? "VIP" : "قياسية"}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>السعر الإجمالي:</span>
                    <span className="text-yellow-500">{getTicketPrice()} ريال</span>
                  </div>
                </div>
              </div>

              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <h3 className="mb-3 font-medium">طريقة الدفع</h3>
                <div className="flex items-center space-x-2 space-x-reverse rounded-lg border border-gray-700 bg-gray-900 p-3">
                  <CreditCard className="h-5 w-5 text-yellow-500" />
                  <span>بطاقة ائتمان / مدى</span>
                </div>
                <p className="mt-2 text-sm text-gray-400">ملاحظة: هذا نموذج تجريبي، لن يتم خصم أي مبالغ حقيقية.</p>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  السابق
                </Button>
                <Button
                  className="bg-yellow-500 text-black hover:bg-yellow-600"
                  onClick={handleBookTicket}
                  disabled={isBooking}
                >
                  {isBooking ? "جاري الحجز..." : "تأكيد الحجز"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
