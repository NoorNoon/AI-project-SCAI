"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { KeyRound, Mail, UserCircle } from "lucide-react"

export default function RegisterPage() {
  const router = useRouter()
  const [userType, setUserType] = useState<"fan" | "organizer">("fan")

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()
    // Después del registro, redirigimos a la página de inicio de sesión
    router.push("/login")
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-yellow-400 mb-2">نظام إدارة الملاعب الذكي</h1>
        <p className="text-gray-400">أنشئ حسابًا جديدًا</p>
      </div>

      <div className="w-full max-w-md bg-[#0f172a] rounded-lg p-8 shadow-lg">
        <Tabs defaultValue="fan" onValueChange={(value) => setUserType(value as "fan" | "organizer")}>
          <TabsList className="grid grid-cols-2 mb-6">
            <TabsTrigger
              value="fan"
              className="data-[state=active]:bg-black data-[state=active]:text-white py-3 rounded-md"
            >
              مشجع
            </TabsTrigger>
            <TabsTrigger
              value="organizer"
              className="data-[state=active]:bg-[#1e293b] data-[state=active]:text-white py-3 rounded-md"
            >
              منظم
            </TabsTrigger>
          </TabsList>

          <TabsContent value="fan">
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="name" className="block text-white">
                  الاسم الكامل
                </label>
                <div className="relative">
                  <Input
                    id="name"
                    type="text"
                    placeholder="أدخل اسمك الكامل"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <UserCircle className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="block text-white">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="block text-white">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <KeyRound className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="confirm-password" className="block text-white">
                  تأكيد كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="confirm-password"
                    type="password"
                    placeholder="أعد إدخال كلمة المرور"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <KeyRound className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-3 rounded-md mt-6"
              >
                إنشاء حساب
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="organizer">
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="org-name" className="block text-white">
                  اسم المنظمة
                </label>
                <div className="relative">
                  <Input
                    id="org-name"
                    type="text"
                    placeholder="أدخل اسم المنظمة"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <UserCircle className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="org-email" className="block text-white">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <Input
                    id="org-email"
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="org-password" className="block text-white">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="org-password"
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <KeyRound className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="org-confirm-password" className="block text-white">
                  تأكيد كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="org-confirm-password"
                    type="password"
                    placeholder="أعد إدخال كلمة المرور"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <KeyRound className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-3 rounded-md mt-6"
              >
                إنشاء حساب
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <div className="mt-6 text-center">
          <p className="text-gray-400">
            لديك حساب بالفعل؟{" "}
            <Link href="/login" className="text-yellow-400 hover:underline">
              تسجيل الدخول
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
