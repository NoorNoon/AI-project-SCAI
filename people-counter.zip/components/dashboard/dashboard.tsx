"use client"

import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Users, Thermometer, Car, MessageSquare, TrendingUp, Bell, AlertTriangle, CheckCircle } from "lucide-react"
import Link from "next/link"
import CrowdMetrics from "./crowd-metrics"
import StadiumOccupancy from "./stadium-occupancy"
import RecentAlerts from "./recent-alerts"
import CrowdAnalysisWidget from "./crowd-analysis-widget"
import { CrowdAnalysisProvider } from "../context/crowd-analysis-context"

const Dashboard: React.FC = () => {
  return (
    <CrowdAnalysisProvider>
      <div className="p-6 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">لوحة التحكم</h1>
            <p className="text-muted-foreground">نظرة عامة على إدارة الحشود الذكية في الملعب</p>
          </div>

          <div className="flex items-center gap-2">
            <Alert className="max-w-md border-amber-500 bg-amber-50">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              <AlertTitle className="text-amber-700">تنبيه: ازدحام متوسط</AlertTitle>
              <AlertDescription className="text-amber-700">
                تم رصد ازدحام متوسط في المنطقة الشرقية. يرجى توجيه المشجعين إلى المداخل البديلة.
              </AlertDescription>
            </Alert>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">إجمالي الحضور</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24,853</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-500 font-medium">↑ 12%</span> مقارنة بالمباراة السابقة
              </p>
              <div className="mt-4 flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">سعة الملعب: 45,000</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">متوسط الكثافة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">متوسطة</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-amber-500 font-medium">↑ 5%</span> في الساعة الماضية
              </p>
              <div className="mt-4 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">ذروة الكثافة: 16:30</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">درجة الحرارة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24°C</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-500 font-medium">مثالية</span> للمشجعين
              </p>
              <div className="mt-4 flex items-center gap-2">
                <Thermometer className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">الرطوبة: 45%</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">مواقف السيارات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">68%</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-amber-500 font-medium">↑ 15%</span> في الساعة الماضية
              </p>
              <div className="mt-4 flex items-center gap-2">
                <Car className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">متاح: 1,250 موقف</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* إضافة مكون تحليل الحشود */}
        <CrowdAnalysisWidget />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>إشغال الملعب</CardTitle>
              <CardDescription>توزيع المشجعين في مناطق الملعب المختلفة</CardDescription>
            </CardHeader>
            <CardContent>
              <StadiumOccupancy />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>مقاييس الحشود</CardTitle>
              <CardDescription>تحليل الحشود في الوقت الفعلي</CardDescription>
            </CardHeader>
            <CardContent>
              <CrowdMetrics />
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>تحليل المشاعر</CardTitle>
              <CardDescription>مشاعر المشجعين بناءً على تحليل الصوت والفيديو</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="sentiment">
                <TabsList className="mb-4">
                  <TabsTrigger value="sentiment">المشاعر</TabsTrigger>
                  <TabsTrigger value="volume">مستوى الصوت</TabsTrigger>
                </TabsList>

                <TabsContent value="sentiment">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>إيجابي</span>
                      <span className="font-medium">68%</span>
                      <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-500 h-2.5 rounded-full" style={{ width: "68%" }}></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>محايد</span>
                      <span className="font-medium">22%</span>
                      <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: "22%" }}></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>سلبي</span>
                      <span className="font-medium">10%</span>
                      <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                        <div className="bg-red-500 h-2.5 rounded-full" style={{ width: "10%" }}></div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="volume">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>مرتفع</span>
                      <span className="font-medium">45%</span>
                      <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                        <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: "45%" }}></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>متوسط</span>
                      <span className="font-medium">35%</span>
                      <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                        <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: "35%" }}></div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>منخفض</span>
                      <span className="font-medium">20%</span>
                      <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: "20%" }}></div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>التنبيهات الأخيرة</CardTitle>
              <CardDescription>آخر التنبيهات من نظام إدارة الحشود</CardDescription>
            </CardHeader>
            <CardContent>
              <RecentAlerts />
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-3">
            <CardHeader>
              <CardTitle>أنظمة إدارة الحشود الذكية</CardTitle>
              <CardDescription>الوصول السريع إلى أنظمة إدارة الحشود المتكاملة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Link href="/sentiment-analysis" className="block">
                  <Card className="hover:bg-gray-50 transition-colors">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <MessageSquare className="h-8 w-8 mb-2 text-purple-500" />
                      <h3 className="font-medium">تحليل المشاعر</h3>
                      <p className="text-sm text-muted-foreground">تحليل مشاعر المشجعين ومستوى الصوت</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/climate-control" className="block">
                  <Card className="hover:bg-gray-50 transition-colors">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <Thermometer className="h-8 w-8 mb-2 text-red-500" />
                      <h3 className="font-medium">التحكم بالمناخ</h3>
                      <p className="text-sm text-muted-foreground">مراقبة وضبط درجة الحرارة والتهوية</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/parking-guidance" className="block">
                  <Card className="hover:bg-gray-50 transition-colors">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <Car className="h-8 w-8 mb-2 text-green-500" />
                      <h3 className="font-medium">إرشاد المواقف</h3>
                      <p className="text-sm text-muted-foreground">إدارة مواقف السيارات وتوجيه المشجعين</p>
                    </CardContent>
                  </Card>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <span className="text-sm text-muted-foreground">جميع الأنظمة تعمل بشكل طبيعي</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-md">
              <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></div>
              <span className="text-sm">النظام يفكر...</span>
            </div>

            <Button variant="outline">
              <Bell className="h-4 w-4 mr-2" />
              إدارة التنبيهات
            </Button>
          </div>
        </div>
      </div>
    </CrowdAnalysisProvider>
  )
}

export default Dashboard
