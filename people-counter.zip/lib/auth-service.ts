import { getSupabaseClient } from "./supabase"

// واجهة لبيانات المستخدم
export interface User {
  id: string
  email: string
  name: string
  user_type: "fan" | "organizer"
  created_at: string
}

// تسجيل مستخدم جديد
export async function registerUser(
  email: string,
  password: string,
  name: string,
  userType: "fan" | "organizer",
): Promise<{ user: User | null; error: string | null }> {
  const supabase = getSupabaseClient()

  try {
    // إنشاء المستخدم في نظام المصادقة
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    })

    if (authError) {
      return { user: null, error: authError.message }
    }

    if (!authData.user) {
      return { user: null, error: "فشل في إنشاء المستخدم" }
    }

    // إضافة بيانات المستخدم إلى جدول المستخدمين
    const { data: userData, error: userError } = await supabase
      .from("users")
      .insert({
        id: authData.user.id,
        email: email,
        name: name,
        user_type: userType,
      })
      .select()
      .single()

    if (userError) {
      return { user: null, error: userError.message }
    }

    return { user: userData, error: null }
  } catch (error) {
    console.error("Error during registration:", error)
    return { user: null, error: "حدث خطأ أثناء التسجيل" }
  }
}

// تسجيل الدخول
export async function loginUser(email: string, password: string): Promise<{ user: User | null; error: string | null }> {
  const supabase = getSupabaseClient()

  try {
    // تسجيل الدخول باستخدام البريد الإلكتروني وكلمة المرور
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (authError) {
      return { user: null, error: authError.message }
    }

    if (!authData.user) {
      return { user: null, error: "فشل في تسجيل الدخول" }
    }

    // الحصول على بيانات المستخدم من جدول المستخدمين
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("*")
      .eq("id", authData.user.id)
      .single()

    if (userError) {
      return { user: null, error: userError.message }
    }

    return { user: userData, error: null }
  } catch (error) {
    console.error("Error during login:", error)
    return { user: null, error: "حدث خطأ أثناء تسجيل الدخول" }
  }
}

// تسجيل الخروج
export async function logoutUser(): Promise<{ error: string | null }> {
  const supabase = getSupabaseClient()

  try {
    const { error } = await supabase.auth.signOut()

    if (error) {
      return { error: error.message }
    }

    return { error: null }
  } catch (error) {
    console.error("Error during logout:", error)
    return { error: "حدث خطأ أثناء تسجيل الخروج" }
  }
}

// الحصول على المستخدم الحالي
export async function getCurrentUser(): Promise<{ user: User | null; error: string | null }> {
  const supabase = getSupabaseClient()

  try {
    const { data: authData, error: authError } = await supabase.auth.getUser()

    if (authError) {
      return { user: null, error: authError.message }
    }

    if (!authData.user) {
      return { user: null, error: null }
    }

    // الحصول على بيانات المستخدم من جدول المستخدمين
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("*")
      .eq("id", authData.user.id)
      .single()

    if (userError) {
      return { user: null, error: userError.message }
    }

    return { user: userData, error: null }
  } catch (error) {
    console.error("Error getting current user:", error)
    return { user: null, error: "حدث خطأ أثناء الحصول على المستخدم الحالي" }
  }
}
