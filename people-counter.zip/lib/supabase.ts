import { createClient } from "@supabase/supabase-js"
import type { Database } from "./database.types"

// إنشاء عميل Supabase للاستخدام على جانب العميل
const createSupabaseClient = () => {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string

  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error("Missing Supabase environment variables")
  }

  return createClient<Database>(supabaseUrl, supabaseAnonKey)
}

// عميل Supabase للاستخدام على جانب العميل (singleton)
let clientSideSupabaseClient: ReturnType<typeof createSupabaseClient>

export const getSupabaseClient = () => {
  if (typeof window === "undefined") {
    // استخدام على جانب الخادم
    return createSupabaseClient()
  }

  // استخدام على جانب العميل (singleton)
  if (!clientSideSupabaseClient) {
    clientSideSupabaseClient = createSupabaseClient()
  }

  return clientSideSupabaseClient
}

// عميل Supabase للاستخدام على جانب الخادم
export const createServerSupabaseClient = () => {
  const supabaseUrl = process.env.SUPABASE_URL as string
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY as string

  if (!supabaseUrl || !supabaseServiceKey) {
    throw new Error("Missing Supabase environment variables for server")
  }

  return createClient<Database>(supabaseUrl, supabaseServiceKey)
}
