"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Home, Users, BarChart2, Settings, Menu, X, Bell, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { CrowdAnalysisProvider } from "../context/crowd-analysis-context"
import StadiumChatbot from "@/components/stadium-assistant/stadium-chatbot"

interface MobileLayoutProps {
  children: React.ReactNode
}

export default function MobileLayout({ children }: MobileLayoutProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [notificationCount, setNotificationCount] = useState(3)

  // تأثير الظهور التدريجي عند تغيير الصفحة
  const [isTransitioning, setIsTransitioning] = useState(false)

  useEffect(() => {
    setIsTransitioning(true)
    const timer = setTimeout(() => setIsTransitioning(false), 300)
    return () => clearTimeout(timer)
  }, [pathname])

  const navItems = [
    { name: "الرئيسية", path: "/dashboard", icon: Home },
    { name: "تحليل الحشود", path: "/crowd-analysis", icon: Users },
    { name: "الإحصائيات", path: "/stats", icon: BarChart2 },
    { name: "الإعدادات", path: "/settings", icon: Settings },
  ]

  const handleNavigation = (path: string) => {
    router.push(path)
  }

  return (
    <CrowdAnalysisProvider>
      <div className="mobile-container">
        <header className="mobile-header">
          <div className="flex items-center">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="mr-2">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[80%] sm:w-[350px]">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between py-4 border-b">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-2">
                        <AvatarImage src="/placeholder.svg?height=40&width=40" />
                        <AvatarFallback>أح</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">أحمد محمد</div>
                        <div className="text-xs text-muted-foreground">مدير النظام</div>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(false)}>
                      <X className="h-5 w-5" />
                    </Button>
                  </div>

                  <div className="flex-1 py-4">
                    <div className="space-y-1">
                      {navItems.map((item) => (
                        <Button
                          key={item.path}
                          variant={pathname === item.path ? "secondary" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => {
                            handleNavigation(item.path)
                            setIsMenuOpen(false)
                          }}
                        >
                          <item.icon className="h-5 w-5 mr-2" />
                          {item.name}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="border-t py-4">
                    <Button variant="outline" className="w-full">
                      تسجيل الخروج
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>

            <div className="font-bold text-lg">نظام الملعب الذكي</div>
          </div>

          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {notificationCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  {notificationCount}
                </Badge>
              )}
            </Button>

            <Button variant="ghost" size="icon" className="ml-1">
              <Search className="h-5 w-5" />
            </Button>
          </div>
        </header>

        <main className={`mobile-content ${isTransitioning ? "fade-in" : ""}`}>{children}</main>

        <footer className="mobile-footer">
          {navItems.map((item) => (
            <button
              key={item.path}
              className={`mobile-nav-item ${pathname === item.path ? "active" : ""}`}
              onClick={() => handleNavigation(item.path)}
            >
              <item.icon className="mobile-nav-item-icon" />
              <span>{item.name}</span>
            </button>
          ))}
        </footer>
        {/* Stadium Chatbot */}
        <StadiumChatbot />
      </div>
    </CrowdAnalysisProvider>
  )
}
