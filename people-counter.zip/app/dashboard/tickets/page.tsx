"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, Ticket, Calendar, MapPin, QrCode, Users, Video } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MyTicketsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [tickets, setTickets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTicket, setSelectedTicket] = useState<any>(null)
  const [activeTab, setActiveTab] = useState<"all" | "physical" | "virtual">("all")

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))

    // Get tickets from localStorage
    const ticketsData = localStorage.getItem("tickets")
    if (ticketsData) {
      setTickets(JSON.parse(ticketsData))
    }

    setLoading(false)
  }, [router])

  const filteredTickets = tickets.filter((ticket) => {
    if (activeTab === "all") return true
    if (activeTab === "physical") return !ticket.isVirtual
    if (activeTab === "virtual") return ticket.isVirtual
    return true
  })

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black pb-20 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center">
          <Link href="/dashboard" className="ml-4">
            <Button variant="ghost" size="icon">
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">تذاكري</h1>
        </div>

        {/* Tabs */}
        <Tabs
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as "all" | "physical" | "virtual")}
          className="mb-6"
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">جميع التذاكر</TabsTrigger>
            <TabsTrigger value="physical">تذاكر حضور</TabsTrigger>
            <TabsTrigger value="virtual">تذاكر افتراضية</TabsTrigger>
          </TabsList>
        </Tabs>

        {filteredTickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-lg border border-gray-800 bg-gray-900 p-8 text-center">
            <Ticket className="mb-4 h-16 w-16 text-gray-600" />
            <h2 className="mb-2 text-xl font-semibold">لا توجد تذاكر</h2>
            <p className="mb-6 text-gray-400">لم تقم بحجز أي تذاكر بعد</p>
            <div className="flex flex-wrap gap-4">
              <Link href="/dashboard/tickets/book">
                <Button className="bg-yellow-500 text-black hover:bg-yellow-600">حجز تذكرة حضور</Button>
              </Link>
              <Link href="/dashboard/tickets/virtual-booking">
                <Button variant="outline">حجز تذكرة افتراضية</Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredTickets.map((ticket) => (
              <Dialog key={ticket.id}>
                <DialogTrigger asChild>
                  <Card
                    className="cursor-pointer border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800"
                    onClick={() => setSelectedTicket(ticket)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="mb-1 font-medium">
                            {ticket.homeTeam} ضد {ticket.awayTeam}
                          </div>
                          <div className="mb-2 text-sm text-gray-400">
                            {ticket.date} - {ticket.time}
                          </div>
                          <div className="flex items-center text-sm text-gray-400">
                            <MapPin className="mr-1 h-4 w-4" />
                            {ticket.stadium}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge className={ticket.type === "vip" ? "bg-purple-500" : "bg-yellow-500 text-black"}>
                            {ticket.type === "vip" ? "VIP" : "قياسية"}
                          </Badge>
                          {ticket.isVirtual && (
                            <Badge variant="outline" className="border-blue-500 text-blue-500">
                              حضور افتراضي
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </DialogTrigger>
                <DialogContent className="border-gray-800 bg-gray-900 text-white sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-center text-xl">تفاصيل التذكرة</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="mx-auto mb-4 flex h-40 w-40 items-center justify-center rounded-lg bg-gray-800">
                      {ticket.isVirtual ? (
                        <Video className="h-32 w-32 text-blue-500" />
                      ) : (
                        <QrCode className="h-32 w-32 text-yellow-500" />
                      )}
                    </div>

                    <div className="rounded-lg border border-gray-800 bg-gray-800 p-4">
                      <div className="mb-4 text-center">
                        <h3 className="text-lg font-semibold">
                          {ticket.homeTeam} ضد {ticket.awayTeam}
                        </h3>
                        <p className="text-gray-400">
                          {ticket.date} - {ticket.time}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="rounded-lg bg-gray-700 p-2">
                          <div className="text-gray-400">الملعب</div>
                          <div>{ticket.stadium}</div>
                        </div>
                        <div className="rounded-lg bg-gray-700 p-2">
                          <div className="text-gray-400">القسم</div>
                          <div>القسم {ticket.section}</div>
                        </div>
                        <div className="rounded-lg bg-gray-700 p-2">
                          <div className="text-gray-400">الصف</div>
                          <div>صف {ticket.row}</div>
                        </div>
                        <div className="rounded-lg bg-gray-700 p-2">
                          <div className="text-gray-400">المقعد</div>
                          <div>مقعد {ticket.seat}</div>
                        </div>
                        <div className="rounded-lg bg-gray-700 p-2">
                          <div className="text-gray-400">نوع التذكرة</div>
                          <div>
                            {ticket.type === "vip" ? "VIP" : "قياسية"}
                            {ticket.isVirtual ? " افتراضية" : ""}
                          </div>
                        </div>
                        <div className="rounded-lg bg-gray-700 p-2">
                          <div className="text-gray-400">السعر</div>
                          <div>{ticket.price} ريال</div>
                        </div>
                      </div>

                      <div className="mt-4 text-center text-xs text-gray-400">
                        <div>رقم التذكرة: {ticket.id}</div>
                        <div>تاريخ الشراء: {ticket.purchaseDate}</div>
                      </div>
                    </div>

                    <div className="flex justify-center">
                      {ticket.isVirtual ? (
                        <Link href="/dashboard/tickets/virtual-attendance">
                          <Button className="bg-blue-500 text-white hover:bg-blue-600">
                            <Users className="mr-2 h-4 w-4" />
                            الحضور الافتراضي
                          </Button>
                        </Link>
                      ) : (
                        <Button className="bg-yellow-500 text-black hover:bg-yellow-600">
                          <Calendar className="mr-2 h-4 w-4" />
                          إضافة إلى التقويم
                        </Button>
                      )}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            ))}

            <div className="mt-6 flex flex-wrap justify-center gap-4">
              <Link href="/dashboard/tickets/book">
                <Button className="bg-yellow-500 text-black hover:bg-yellow-600">حجز تذكرة حضور</Button>
              </Link>
              <Link href="/dashboard/tickets/virtual-booking">
                <Button variant="outline">حجز تذكرة افتراضية</Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
