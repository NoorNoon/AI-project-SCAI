"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, Users, Thermometer, Car, Volume2, BarChart } from "lucide-react"
import Link from "next/link"

export default function CrowdManagementPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [totalAttendance, setTotalAttendance] = useState(35420)
  const [stadiumCapacity, setStadiumCapacity] = useState(45000)
  const [occupancyRate, setOccupancyRate] = useState(0)

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))
    setLoading(false)

    // Calculate occupancy rate
    setOccupancyRate(Math.round((totalAttendance / stadiumCapacity) * 100))

    // Simulate attendance changes
    const interval = setInterval(() => {
      setTotalAttendance((prev) => {
        const change = Math.floor(Math.random() * 100) - 30 // -30 to +70
        const newAttendance = Math.max(20000, Math.min(stadiumCapacity, prev + change))
        setOccupancyRate(Math.round((newAttendance / stadiumCapacity) * 100))
        return newAttendance
      })
    }, 30000)

    return () => clearInterval(interval)
  }, [router, stadiumCapacity])

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black pb-20 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center">
          <Link href="/dashboard" className="ml-4">
            <Button variant="ghost" size="icon">
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">إدارة الجماهير الذكية</h1>
        </div>

        {/* Stadium Occupancy Overview */}
        <Card className="mb-6 border-gray-800 bg-gray-900">
          <CardContent className="p-4">
            <h2 className="mb-3 text-xl font-semibold">نظرة عامة على الحضور</h2>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <div className="rounded-lg bg-gray-800 p-4 text-center">
                <Users className="mx-auto mb-2 h-8 w-8 text-blue-500" />
                <div className="text-2xl font-bold">{totalAttendance.toLocaleString()}</div>
                <div className="text-sm text-gray-400">إجمالي الحضور</div>
              </div>

              <div className="rounded-lg bg-gray-800 p-4 text-center">
                <BarChart className="mx-auto mb-2 h-8 w-8 text-green-500" />
                <div className="text-2xl font-bold">{occupancyRate}%</div>
                <div className="text-sm text-gray-400">نسبة الإشغال</div>
              </div>

              <div className="rounded-lg bg-gray-800 p-4 text-center">
                <div className="mx-auto mb-2 h-8 w-8 rounded-full border-4 border-yellow-500 text-center">
                  <span className="text-lg font-bold leading-6 text-yellow-500">!</span>
                </div>
                <div className="text-2xl font-bold">{stadiumCapacity - totalAttendance}</div>
                <div className="text-sm text-gray-400">المقاعد المتبقية</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Management Features Cards */}
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Link href="/dashboard/crowd-management/sentiment">
            <Card className="border-gray-800 bg-gray-900 transition-transform hover:scale-105 hover:bg-gray-800">
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Volume2 className="mb-4 h-12 w-12 text-blue-500" />
                <h3 className="text-lg font-semibold">تحليل المشاعر</h3>
                <p className="mt-2 text-sm text-gray-400">تحليل مشاعر الجماهير ومستوى الصوت في الملعب</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/crowd-management/climate">
            <Card className="border-gray-800 bg-gray-900 transition-transform hover:scale-105 hover:bg-gray-800">
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Thermometer className="mb-4 h-12 w-12 text-red-500" />
                <h3 className="text-lg font-semibold">التحكم بالمناخ</h3>
                <p className="mt-2 text-sm text-gray-400">مراقبة وضبط درجة الحرارة والتهوية في الملعب</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/crowd-management/parking">
            <Card className="border-gray-800 bg-gray-900 transition-transform hover:scale-105 hover:bg-gray-800">
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Car className="mb-4 h-12 w-12 text-green-500" />
                <h3 className="text-lg font-semibold">مواقف السيارات</h3>
                <p className="mt-2 text-sm text-gray-400">إدارة مواقف السيارات وتوجيه المشجعين</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/crowd-management/crowd-analysis">
            <Card className="border-gray-800 bg-gray-900 transition-transform hover:scale-105 hover:bg-gray-800">
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Users className="mb-4 h-12 w-12 text-purple-500" />
                <h3 className="text-lg font-semibold">تحليل الحشود</h3>
                <p className="mt-2 text-sm text-gray-400">تحليل وإدارة الحشود في مناطق الملعب المختلفة</p>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Recommendations */}
        <Card className="border-gray-800 bg-gray-900">
          <CardContent className="p-4">
            <h2 className="mb-3 text-xl font-semibold">توصيات النظام</h2>
            <div className="space-y-3">
              <div className="rounded-lg bg-blue-900/30 p-3">
                <h3 className="mb-1 font-medium text-blue-300">إعادة توزيع الجماهير</h3>
                <p className="text-sm text-blue-200">
                  المدرجات الشرقية مزدحمة بنسبة 90%. يُنصح بتوجيه الجماهير الجديدة إلى المدرجات الغربية (70% إشغال).
                </p>
              </div>

              <div className="rounded-lg bg-green-900/30 p-3">
                <h3 className="mb-1 font-medium text-green-300">تعديل درجة الحرارة</h3>
                <p className="text-sm text-green-200">
                  تم خفض درجة الحرارة في المدرجات الشرقية إلى 22°C بسبب ارتفاع كثافة الجماهير.
                </p>
              </div>

              <div className="rounded-lg bg-yellow-900/30 p-3">
                <h3 className="mb-1 font-medium text-yellow-300">تنبيه مواقف السيارات</h3>
                <p className="text-sm text-yellow-200">
                  موقف السيارات الشمالي سيمتلئ خلال 30 دقيقة. يُنصح بتوجيه السيارات القادمة إلى الموقف الجنوبي.
                </p>
              </div>

              <div className="rounded-lg bg-purple-900/30 p-3">
                <h3 className="mb-1 font-medium text-purple-300">تحليل المشاعر</h3>
                <p className="text-sm text-purple-200">
                  تم رصد هتافات سلبية في المدرجات الجنوبية. يُنصح بعرض رسائل تهدئة على الشاشات في تلك المنطقة.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
