import PeopleCounterPageMobile from "@/components/people-counter/people-counter-page-mobile"

export default function CrowdAnalysisPage() {
  return <PeopleCounterPageMobile />
}
