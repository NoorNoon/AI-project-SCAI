import { createServerSupabaseClient } from "./supabase"

export async function setupDatabase() {
  const supabase = createServerSupabaseClient()

  // التحقق من وجود الجداول
  const { data: sessions, error: sessionsError } = await supabase
    .from("crowd_analysis_sessions")
    .select("count")
    .limit(1)

  if (sessionsError) {
    console.error("Error checking database tables:", sessionsError)
    return false
  }

  // إذا كانت الجداول موجودة، لا داعي للإعداد
  if (sessions && sessions.length > 0) {
    console.log("Database already set up")
    return true
  }

  // إنشاء جلسة افتراضية
  const { data: defaultSession, error: sessionError } = await supabase
    .from("crowd_analysis_sessions")
    .insert({
      session_name: "الجلسة الافتراضية",
      location: "الملعب الرئيسي",
    })
    .select()
    .single()

  if (sessionError) {
    console.error("Error creating default session:", sessionError)
    return false
  }

  console.log("Database setup completed successfully")
  return true
}

// يمكن استدعاء هذه الدالة عند بدء تشغيل التطبيق
export async function initializeDatabase() {
  try {
    await setupDatabase()
  } catch (error) {
    console.error("Database initialization failed:", error)
  }
}
