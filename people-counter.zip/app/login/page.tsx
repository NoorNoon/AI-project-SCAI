"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { User, KeyRound } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()
  const [userType, setUserType] = useState<"fan" | "organizer">("fan")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // En la versión de demostración, navegamos directamente al dashboard
    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-yellow-400 mb-2">نظام إدارة الملاعب الذكي</h1>
        <p className="text-gray-400">سجل دخولك للوصول إلى حسابك</p>
      </div>

      <div className="w-full max-w-md bg-[#0f172a] rounded-lg p-8 shadow-lg">
        <Tabs defaultValue="fan" onValueChange={(value) => setUserType(value as "fan" | "organizer")}>
          <TabsList className="grid grid-cols-2 mb-6">
            <TabsTrigger
              value="fan"
              className="data-[state=active]:bg-black data-[state=active]:text-white py-3 rounded-md"
            >
              مشجع
            </TabsTrigger>
            <TabsTrigger
              value="organizer"
              className="data-[state=active]:bg-[#1e293b] data-[state=active]:text-white py-3 rounded-md"
            >
              منظم
            </TabsTrigger>
          </TabsList>

          <TabsContent value="fan">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="email" className="block text-white">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="block text-white">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <KeyRound className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-3 rounded-md"
              >
                تسجيل الدخول
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="organizer">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="organizer-email" className="block text-white">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <Input
                    id="organizer-email"
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="organizer-password" className="block text-white">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Input
                    id="organizer-password"
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    className="bg-[#0f172a] border-[#1e293b] text-white pl-10 h-12 rounded-md"
                    dir="rtl"
                  />
                  <KeyRound className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-3 rounded-md"
              >
                تسجيل الدخول
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <div className="mt-6 text-center">
          <p className="text-gray-400">
            ليس لديك حساب؟{" "}
            <Link href="/register" className="text-yellow-400 hover:underline">
              إنشاء حساب جديد
            </Link>
          </p>
        </div>
      </div>

      <p className="mt-8 text-gray-500 text-sm">للتجربة، يمكنك استخدام أي بريد إلكتروني وكلمة مرور</p>
    </div>
  )
}
