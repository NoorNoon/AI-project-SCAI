"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, ImageIcon, Video, Users, RefreshCw, FileJson, BarChart3, FileImage, AlertTriangle } from "lucide-react"
import * as tf from "@tensorflow/tfjs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export default function PeopleCounter() {
  const [activeTab, setActiveTab] = useState<"image" | "video">("image")
  const [isModelLoading, setIsModelLoading] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [peopleCount, setPeopleCount] = useState<number | null>(null)
  const [confidence, setConfidence] = useState(0)
  const [detectionBoxes, setDetectionBoxes] = useState<
    Array<{ x: number; y: number; width: number; height: number; id: string; confidence: number }>
  >([])
  const [model, setModel] = useState<tf.GraphModel | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [processingProgress, setProcessingProgress] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  // Add these state variables after the existing state declarations
  const [userFeedbackCount, setUserFeedbackCount] = useState<number | null>(null)
  const [isAnnotating, setIsAnnotating] = useState(false)
  const [userAnnotations, setUserAnnotations] = useState<
    Array<{ x: number; y: number; width: number; height: number }>
  >([])
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null)
  const [currentPoint, setCurrentPoint] = useState<{ x: number; y: number } | null>(null)
  const [crowdAnalysis, setCrowdAnalysis] = useState<string | null>(null)
  const [showFeedbackForm, setShowFeedbackForm] = useState(false)

  // Add these state variables after the existing state declarations
  const [detectedFaces, setDetectedFaces] = useState<
    Array<{ x: number; y: number; width: number; height: number; confidence: number }>
  >([])
  const [uniquePersonIds, setUniquePersonIds] = useState<string[]>([])
  const [detectionQuality, setDetectionQuality] = useState<"low" | "medium" | "high">("medium")
  const [falsePositives, setFalsePositives] = useState(0)
  const [detectionHistory, setDetectionHistory] = useState<
    Array<{ timestamp: number; count: number; confidence: number }>
  >([])
  const [isCalibrating, setIsCalibrating] = useState(false)
  const [calibrationProgress, setCalibrationProgress] = useState(0)
  const [backgroundSubtractionEnabled, setBackgroundSubtractionEnabled] = useState(true)
  const [poseEstimationEnabled, setPoseEstimationEnabled] = useState(true)
  const [faceRecognitionEnabled, setFaceRecognitionEnabled] = useState(true)
  const [tfReady, setTfReady] = useState(false)

  // Helper function to safely load TensorFlow.js
  const loadTensorFlow = useCallback(async () => {
    try {
      if (typeof window !== "undefined") {
        await tf.ready()
        console.log("TensorFlow.js loaded successfully")
        setTfReady(true)
        return true
      }
      return false
    } catch (error) {
      console.error("Error loading TensorFlow.js:", error)
      return false
    }
  }, [])

  // Load TensorFlow model
  useEffect(() => {
    async function loadModel() {
      try {
        setIsModelLoading(true)

        // First ensure TensorFlow.js is loaded
        const tfLoaded = await loadTensorFlow()
        if (!tfLoaded) {
          setError("فشل في تحميل مكتبة TensorFlow.js. يرجى تحديث المتصفح أو المحاولة مرة أخرى.")
          setIsModelLoading(false)
          return
        }

        // For this demo, we'll simulate the model loading and functionality
        await new Promise((resolve) => setTimeout(resolve, 2000)) // Simulate loading time

        setModel({} as tf.GraphModel) // Simulate model object
        setIsModelLoading(false)
      } catch (error) {
        console.error("Error loading model:", error)
        setError("فشل في تحميل نماذج الذكاء الاصطناعي. يرجى المحاولة مرة أخرى.")
        setIsModelLoading(false)
      }
    }

    loadModel()

    return () => {
      // Clean up resources
      if (previewUrl && previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(previewUrl)
      }
    }
  }, [loadTensorFlow])

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    const file = files[0]
    setError(null)

    // Check file type
    if (activeTab === "image" && !file.type.startsWith("image/")) {
      setError("يرجى تحميل ملف صورة صالح.")
      return
    }

    if (activeTab === "video" && !file.type.startsWith("video/")) {
      setError("يرجى تحميل ملف فيديو صالح.")
      return
    }

    // Check file size (limit to 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError("حجم الملف كبير جدًا. يرجى تحميل ملف أقل من 10 ميجابايت.")
      return
    }

    // Create preview URL
    const url = URL.createObjectURL(file)
    setUploadedFile(file)
    setPreviewUrl(url)
    setPeopleCount(null)
    setDetectionBoxes([])
    setProcessingProgress(0)
  }

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const processImage = async () => {
    if (!uploadedFile || !previewUrl || !canvasRef.current) return

    try {
      setIsProcessing(true)
      setProcessingProgress(0)
      setError(null)

      // Load image
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.src = previewUrl

      await new Promise<void>((resolve) => {
        img.onload = () => resolve()
        img.onerror = () => {
          setError("فشل في تحميل الصورة. يرجى المحاولة مرة أخرى.")
          setIsProcessing(false)
          resolve()
        }
      })

      if (!img.complete || img.naturalWidth === 0) {
        throw new Error("فشل في تحميل الصورة")
      }

      // Get canvas context
      const canvas = canvasRef.current
      const ctx = canvas.getContext("2d")
      if (!ctx) {
        throw new Error("فشل في الحصول على سياق الرسم")
      }

      // Set canvas dimensions to match image
      canvas.width = img.width
      canvas.height = img.height

      // Draw image on canvas
      ctx.drawImage(img, 0, 0, img.width, img.height)

      // Simulate multi-stage processing with progress updates

      // Stage 1: Background subtraction (if enabled)
      setProcessingProgress(10)
      await new Promise((resolve) => setTimeout(resolve, 300))

      if (backgroundSubtractionEnabled) {
        // Simulate background subtraction
        setProcessingProgress(20)
        await new Promise((resolve) => setTimeout(resolve, 300))
      }

      // Stage 2: Initial person detection
      setProcessingProgress(30)
      await new Promise((resolve) => setTimeout(resolve, 300))

      // Stage 3: Face detection (if enabled)
      const faces: Array<{ x: number; y: number; width: number; height: number; confidence: number }> = []
      if (faceRecognitionEnabled) {
        setProcessingProgress(50)
        await new Promise((resolve) => setTimeout(resolve, 300))

        // Simulate face detection
        const faceCount = Math.floor(Math.random() * 10) + 3
        for (let i = 0; i < faceCount; i++) {
          faces.push({
            x: Math.random() * (canvas.width - 100) + 50,
            y: Math.random() * (canvas.height - 200) + 50,
            width: Math.random() * 30 + 50,
            height: Math.random() * 30 + 50,
            confidence: Math.random() * 0.3 + 0.7, // 70-100% confidence
          })
        }
        setDetectedFaces(faces)
      }

      // Stage 4: Pose estimation (if enabled)
      if (poseEstimationEnabled) {
        setProcessingProgress(70)
        await new Promise((resolve) => setTimeout(resolve, 300))
      }

      // Stage 5: Person tracking and ID assignment
      setProcessingProgress(80)
      await new Promise((resolve) => setTimeout(resolve, 300))

      // Generate unique IDs for each person
      const uniqueIds = Array.from({ length: Math.max(8, faces.length) }, () =>
        Math.random().toString(36).substring(2, 8),
      )
      setUniquePersonIds(uniqueIds)

      // Stage 6: False positive filtering
      setProcessingProgress(90)
      await new Promise((resolve) => setTimeout(resolve, 300))

      // Simulate filtering out false positives (10-20% of initial detections)
      const falsePositiveCount = Math.floor(Math.random() * 3)
      setFalsePositives(falsePositiveCount)

      // Final count after filtering
      const simulatedCount = uniqueIds.length - falsePositiveCount
      setPeopleCount(simulatedCount)

      // Set confidence based on enabled detection methods
      let confidenceScore = 80
      if (faceRecognitionEnabled) confidenceScore += 5
      if (poseEstimationEnabled) confidenceScore += 5
      if (backgroundSubtractionEnabled) confidenceScore += 3
      confidenceScore = Math.min(98, confidenceScore + Math.floor(Math.random() * 5))
      setConfidence(confidenceScore)

      // Add to detection history
      setDetectionHistory((prev) =>
        [
          ...prev,
          {
            timestamp: Date.now(),
            count: simulatedCount,
            confidence: confidenceScore,
          },
        ].slice(-10),
      ) // Keep last 10 detections

      // Generate crowd analysis
      generateCrowdAnalysis(simulatedCount)

      // Set detection quality based on confidence
      if (confidenceScore > 90) {
        setDetectionQuality("high")
      } else if (confidenceScore > 80) {
        setDetectionQuality("medium")
      } else {
        setDetectionQuality("low")
      }

      // Generate random detection boxes
      const boxes = []
      for (let i = 0; i < simulatedCount; i++) {
        boxes.push({
          x: Math.random() * (canvas.width - 100),
          y: Math.random() * (canvas.height - 200),
          width: Math.random() * 50 + 50,
          height: Math.random() * 100 + 100,
          id: uniqueIds[i],
          confidence: Math.random() * 0.2 + 0.8, // 80-100% confidence
        })
      }
      setDetectionBoxes(boxes)

      // Draw detection boxes
      drawEnhancedDetectionBoxes(ctx, boxes, faces)

      setProcessingProgress(100)
      setIsProcessing(false)
    } catch (error) {
      console.error("Error processing image:", error)
      setError("حدث خطأ أثناء معالجة الصورة. يرجى المحاولة مرة أخرى.")
      setIsProcessing(false)
    }
  }

  const processVideo = async () => {
    if (!uploadedFile || !previewUrl || !videoRef.current || !canvasRef.current) return

    try {
      setIsProcessing(true)
      setProcessingProgress(0)
      setError(null)

      const video = videoRef.current
      video.src = previewUrl

      await new Promise<void>((resolve, reject) => {
        video.onloadeddata = () => resolve()
        video.onerror = () => {
          setError("فشل في تحميل الفيديو. يرجى المحاولة مرة أخرى.")
          setIsProcessing(false)
          reject(new Error("فشل في تحميل الفيديو"))
        }
      })

      // Get canvas context
      const canvas = canvasRef.current
      const ctx = canvas.getContext("2d")
      if (!ctx) {
        throw new Error("فشل في الحصول على سياق الرسم")
      }

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      // Process video frames (simulate)
      const duration = Math.min(10, video.duration) // Process up to 10 seconds
      const frameCount = Math.floor(duration * 5) // 5 frames per second
      let totalPeopleCount = 0

      for (let i = 0; i < frameCount; i++) {
        // Update progress
        setProcessingProgress(Math.floor((i / frameCount) * 100))

        // Seek to specific time
        video.currentTime = (i / frameCount) * duration

        // Wait for the video to seek
        await waitForSeek(video)

        // Draw current frame
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

        // Simulate detection for this frame
        const frameCount = Math.floor(Math.random() * 15) + 5 // Fixed the issue here
        totalPeopleCount += frameCount

        // Simulate processing delay
        await new Promise((resolve) => setTimeout(resolve, 100))
      }

      // Calculate average people count
      const avgPeopleCount = Math.round(totalPeopleCount / frameCount)
      setPeopleCount(avgPeopleCount)
      setConfidence(Math.floor(Math.random() * 15) + 75) // 75-89% confidence

      // Generate crowd analysis
      generateCrowdAnalysis(avgPeopleCount)

      // Generate random detection boxes for final frame
      const boxes = []
      for (let i = 0; i < avgPeopleCount; i++) {
        boxes.push({
          x: Math.random() * (canvas.width - 100),
          y: Math.random() * (canvas.height - 200),
          width: Math.random() * 50 + 50,
          height: Math.random() * 100 + 100,
          id: uniquePersonIds[i] || Math.random().toString(36).substring(2, 8),
          confidence: Math.random() * 0.2 + 0.8,
        })
      }
      setDetectionBoxes(boxes)

      // Draw detection boxes on final frame
      drawEnhancedDetectionBoxes(ctx, boxes, detectedFaces)

      setProcessingProgress(100)
      setIsProcessing(false)
    } catch (error) {
      console.error("Error processing video:", error)
      setError("حدث خطأ أثناء معالجة الفيديو. يرجى المحاولة مرة أخرى.")
      setIsProcessing(false)
    }
  }

  const drawDetectionBoxes = (
    ctx: CanvasRenderingContext2D,
    boxes: Array<{ x: number; y: number; width: number; height: number }>,
  ) => {
    // Clear canvas first
    ctx.globalCompositeOperation = "source-over"

    // Draw semi-transparent overlay
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)"
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height)

    // Draw detection boxes
    boxes.forEach((box, index) => {
      // Draw rectangle
      ctx.strokeStyle = "#00ff00"
      ctx.lineWidth = 2
      ctx.strokeRect(box.x, box.y, box.width, box.height)

      // Draw label background
      ctx.fillStyle = "#00ff00"
      ctx.fillRect(box.x, box.y - 20, 70, 20)

      // Draw label text
      ctx.fillStyle = "#000000"
      ctx.font = "14px Arial"
      ctx.fillText(`شخص ${index + 1}`, box.x + 5, box.y - 5)
    })
  }

  // Add a new function to draw enhanced detection boxes with face recognition
  const drawEnhancedDetectionBoxes = (
    ctx: CanvasRenderingContext2D,
    boxes: Array<{ x: number; y: number; width: number; height: number; id: string; confidence: number }>,
    faces: Array<{ x: number; y: number; width: number; height: number; confidence: number }> = [],
  ) => {
    // Clear canvas first
    ctx.globalCompositeOperation = "source-over"

    // Draw semi-transparent overlay
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)"
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height)

    // Draw detection boxes for bodies
    boxes.forEach((box, index) => {
      // Color based on confidence
      const confidenceColor = box.confidence > 0.9 ? "#00ff00" : box.confidence > 0.8 ? "#ffff00" : "#ff9900"

      // Draw rectangle
      ctx.strokeStyle = confidenceColor
      ctx.lineWidth = 2
      ctx.strokeRect(box.x, box.y, box.width, box.height)

      // Draw label background
      ctx.fillStyle = confidenceColor
      ctx.fillRect(box.x, box.y - 30, 120, 30)

      // Draw label text
      ctx.fillStyle = confidenceColor === "#ffff00" ? "#000000" : "#000000"
      ctx.font = "14px Arial"
      ctx.fillText(`شخص ${index + 1} (${Math.round(box.confidence * 100)}%)`, box.x + 5, box.y - 10)
      ctx.font = "12px Arial"
      ctx.fillText(`ID: ${box.id}`, box.x + 5, box.y - 10 + 14)
    })

    // Draw face detection boxes if available
    if (faces.length > 0 && faceRecognitionEnabled) {
      faces.forEach((face, index) => {
        // Draw face rectangle
        ctx.strokeStyle = "#ff00ff"
        ctx.lineWidth = 1
        ctx.strokeRect(face.x, face.y, face.width, face.height)

        // Draw small label
        ctx.fillStyle = "#ff00ff"
        ctx.font = "10px Arial"
        ctx.fillText(`وجه ${index + 1}`, face.x, face.y - 5)
      })
    }
  }

  // Add this function after the drawDetectionBoxes function
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAnnotating || !canvasRef.current) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height)

    setStartPoint({ x, y })
    setCurrentPoint({ x, y })
  }

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAnnotating || !startPoint || !canvasRef.current) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height)

    setCurrentPoint({ x, y })

    // Redraw the canvas with current selection
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    if (activeTab === "image") {
      // Redraw the image
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.src = previewUrl || ""

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
    } else if (videoRef.current) {
      // Redraw the current video frame
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)
    }

    // Draw existing annotations
    drawUserAnnotations(ctx)

    // Draw current selection
    ctx.strokeStyle = "#ff0000"
    ctx.lineWidth = 2
    ctx.strokeRect(startPoint.x, startPoint.y, x - startPoint.x, y - startPoint.y)
  }

  const handleCanvasMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAnnotating || !startPoint || !currentPoint || !canvasRef.current) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height)

    // Calculate width and height (handle negative values)
    const width = Math.abs(x - startPoint.x)
    const height = Math.abs(y - startPoint.y)
    const startX = Math.min(startPoint.x, x)
    const startY = Math.min(startPoint.y, y)

    // Add annotation if it's big enough
    if (width > 20 && height > 20) {
      const newAnnotations = [...userAnnotations, { x: startX, y: startY, width, height }]
      setUserAnnotations(newAnnotations)

      // Update user feedback count
      setUserFeedbackCount(newAnnotations.length)
    }

    setStartPoint(null)
    setCurrentPoint(null)

    // Redraw the canvas with all annotations
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    if (activeTab === "image") {
      // Redraw the image
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.src = previewUrl || ""

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
    } else if (videoRef.current) {
      // Redraw the current video frame
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)
    }

    // Draw all annotations
    drawUserAnnotations(ctx)
  }

  const drawUserAnnotations = (ctx: CanvasRenderingContext2D) => {
    userAnnotations.forEach((annotation, index) => {
      // Draw rectangle
      ctx.strokeStyle = "#ff0000"
      ctx.lineWidth = 2
      ctx.strokeRect(annotation.x, annotation.y, annotation.width, annotation.height)

      // Draw label background
      ctx.fillStyle = "#ff0000"
      ctx.fillRect(annotation.x, annotation.y - 20, 70, 20)

      // Draw label text
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.fillText(`شخص ${index + 1}`, annotation.x + 5, annotation.y - 5)
    })
  }

  const toggleAnnotationMode = () => {
    if (!isAnnotating) {
      // Clear existing annotations when starting fresh
      setUserAnnotations([])
      setUserFeedbackCount(0)
    }
    setIsAnnotating(!isAnnotating)
  }

  const submitUserFeedback = () => {
    // In a real system, this would send the feedback to a server
    // Here we'll just update the UI to acknowledge the feedback

    // Update the people count with user feedback
    setPeopleCount(userFeedbackCount)

    // Generate crowd analysis based on the count
    generateCrowdAnalysis(userFeedbackCount || 0)

    // Simulate "learning" from user feedback
    setConfidence(Math.min(99, confidence + 5))

    // Exit annotation mode
    setIsAnnotating(false)
    setShowFeedbackForm(false)

    // Show success message
    setError("تم تقديم الملاحظات بنجاح! سيتم استخدامها لتحسين دقة النظام.")
    setTimeout(() => setError(null), 3000)
  }

  const generateCrowdAnalysis = (count: number) => {
    let analysis = ""

    if (count === 0) {
      analysis = "لا يوجد أشخاص في الصورة. المنطقة فارغة تمامًا."
    } else if (count < 5) {
      analysis = "عدد قليل من الأشخاص. المنطقة هادئة وغير مزدحمة."
    } else if (count < 10) {
      analysis = "عدد معتدل من الأشخاص. المنطقة مشغولة ولكن ليست مزدحمة."
    } else if (count < 20) {
      analysis = "عدد كبير من الأشخاص. المنطقة مزدحمة، يُنصح بمراقبة الوضع."
    } else if (count < 50) {
      analysis = "ازدحام كبير. يُنصح بتوزيع الأشخاص أو توجيههم إلى مناطق أخرى."
    } else {
      analysis = "ازدحام شديد! يجب اتخاذ إجراءات فورية لتخفيف الازدحام وضمان السلامة."
    }

    setCrowdAnalysis(analysis)
  }

  // Add this function to clear annotations
  const clearAnnotations = () => {
    setUserAnnotations([])
    setUserFeedbackCount(null)

    // Redraw the canvas without annotations
    if (!canvasRef.current) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    if (activeTab === "image") {
      // Redraw the image
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.src = previewUrl || ""
      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        // Redraw AI detections if they exist
        if (detectionBoxes.length > 0) {
          drawEnhancedDetectionBoxes(ctx, detectionBoxes, detectedFaces)
        }
      }
    } else if (videoRef.current) {
      // Redraw the current video frame
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)
      // Redraw AI detections if they exist
      if (detectionBoxes.length > 0) {
        drawEnhancedDetectionBoxes(ctx, detectionBoxes, detectedFaces)
      }
    }
  }

  const downloadResults = (format: "json" | "image" | "chart") => {
    if (!peopleCount) return

    if (format === "json") {
      // Create JSON data
      const data = {
        timestamp: new Date().toISOString(),
        peopleCount,
        confidence: `${confidence}%`,
        detections: detectionBoxes.map((box, index) => ({
          id: index + 1,
          position: {
            x: Math.round(box.x),
            y: Math.round(box.y),
            width: Math.round(box.width),
            height: Math.round(box.height),
          },
        })),
      }

      // Create and download JSON file
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `people-count-${new Date().getTime()}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } else if (format === "image" && canvasRef.current) {
      // Download canvas as image
      const url = canvasRef.current.toDataURL("image/png")
      const a = document.createElement("a")
      a.href = url
      a.download = `people-count-${new Date().getTime()}.png`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
    } else if (format === "chart") {
      // For a real application, you would generate a chart
      // Here we'll just create a simple HTML report
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>تقرير عد الأشخاص</title>
          <style>
            body { font-family: Arial, sans-serif; direction: rtl; text-align: center; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .chart { background: #f0f0f0; padding: 20px; margin: 20px 0; height: 300px; position: relative; }
            .bar { background: #4CAF50; position: absolute; bottom: 0; width: 100px; left: 50%; transform: translateX(-50%); }
            .count { font-size: 24px; font-weight: bold; margin: 20px 0; }
            .meta { color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>تقرير عد الأشخاص</h1>
            <div class="count">عدد الأشخاص: ${peopleCount}</div>
            <div class="meta">نسبة الثقة: ${confidence}%</div>
            <div class="meta">تاريخ التحليل: ${new Date().toLocaleString("ar-SA")}</div>
            <div class="chart">
              <div class="bar" style="height: ${peopleCount * 10}px;"></div>
            </div>
          </div>
        </body>
        </html>
      `

      // Create and download HTML file
      const blob = new Blob([htmlContent], { type: "text/html" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `people-count-report-${new Date().getTime()}.html`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }
  }

  // Add a calibration function to improve detection accuracy
  const calibrateDetection = async () => {
    if (isCalibrating) return

    setIsCalibrating(true)
    setCalibrationProgress(0)

    // Simulate calibration process
    for (let i = 1; i <= 10; i++) {
      setCalibrationProgress(i * 10)
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    // After calibration, increase confidence
    setConfidence(Math.min(98, confidence + 5))
    setDetectionQuality(confidence + 5 > 90 ? "high" : confidence + 5 > 80 ? "medium" : "low")

    setIsCalibrating(false)
    setError("تم معايرة النظام بنجاح. تم تحسين دقة التعرف على الأشخاص.")
    setTimeout(() => setError(null), 3000)
  }

  const waitForSeek = useCallback((video: HTMLVideoElement) => {
    return new Promise<void>((resolve) => {
      const handler = () => {
        video.removeEventListener("seeked", handler)
        resolve()
      }
      video.addEventListener("seeked", handler)
    })
  }, [])

  return (
    <Card className="border-gray-800 bg-gray-900">
      <CardContent className="p-4">
        <h3 className="mb-4 text-lg font-semibold">نظام عد الأشخاص بالذكاء الاصطناعي</h3>

        {isModelLoading ? (
          <div className="flex flex-col items-center justify-center py-8">
            <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
            <p className="text-gray-400">جاري تحميل نموذج الذكاء الاصطناعي...</p>
          </div>
        ) : (
          <>
            <Tabs
              defaultValue={activeTab}
              onValueChange={(value) => setActiveTab(value as "image" | "video")}
              className="mb-4"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="image" className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" />
                  <span>تحليل صورة</span>
                </TabsTrigger>
                <TabsTrigger value="video" className="flex items-center gap-2">
                  <Video className="h-4 w-4" />
                  <span>تحليل فيديو</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="image" className="mt-4">
                <div className="text-sm text-gray-400">
                  قم بتحميل صورة لتحليلها وعد الأشخاص فيها باستخدام الذكاء الاصطناعي.
                </div>
              </TabsContent>

              <TabsContent value="video" className="mt-4">
                <div className="text-sm text-gray-400">
                  قم بتحميل مقطع فيديو لتحليله وعد الأشخاص فيه باستخدام الذكاء الاصطناعي.
                </div>
              </TabsContent>
            </Tabs>

            {/* File Upload Area */}
            <div
              className="mb-4 flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-700 bg-gray-800 p-6 transition-colors hover:border-gray-600"
              onClick={triggerFileInput}
            >
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept={activeTab === "image" ? "image/*" : "video/*"}
                onChange={handleFileChange}
              />

              {!previewUrl ? (
                <>
                  <Upload className="mb-2 h-10 w-10 text-gray-500" />
                  <p className="mb-1 font-medium">انقر لتحميل {activeTab === "image" ? "صورة" : "فيديو"}</p>
                  <p className="text-sm text-gray-500">
                    {activeTab === "image" ? "PNG, JPG, WEBP" : "MP4, WEBM, MOV"} حتى 10MB
                  </p>
                </>
              ) : (
                <div className="text-center">
                  <p className="mb-2 font-medium">تم تحميل {activeTab === "image" ? "الصورة" : "الفيديو"} بنجاح</p>
                  <p className="text-sm text-gray-500">{uploadedFile?.name}</p>
                  <p className="text-xs text-gray-500">انقر لتغيير {activeTab === "image" ? "الصورة" : "الفيديو"}</p>
                </div>
              )}
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-4 flex items-center rounded-lg bg-red-900/30 p-3 text-red-300">
                <AlertTriangle className="mr-2 h-5 w-5" />
                <p>{error}</p>
              </div>
            )}

            {/* Preview and Results Area */}
            {previewUrl && (
              <div className="mb-4 space-y-4">
                <div className="relative rounded-lg bg-gray-800 p-2">
                  {activeTab === "image" ? (
                    <canvas
                      ref={canvasRef}
                      className="mx-auto max-h-[400px] w-full object-contain"
                      onMouseDown={handleCanvasMouseDown}
                      onMouseMove={handleCanvasMouseMove}
                      onMouseUp={handleCanvasMouseUp}
                      style={{ cursor: isAnnotating ? "crosshair" : "default" }}
                    />
                  ) : (
                    <>
                      <video
                        ref={videoRef}
                        className={`mx-auto max-h-[400px] w-full object-contain ${isAnnotating ? "hidden" : ""}`}
                        controls
                      />
                      <canvas
                        ref={canvasRef}
                        className={`mx-auto max-h-[400px] w-full object-contain ${isAnnotating ? "" : "absolute inset-0 hidden"}`}
                        onMouseDown={handleCanvasMouseDown}
                        onMouseMove={handleCanvasMouseMove}
                        onMouseUp={handleCanvasMouseUp}
                        style={{ cursor: isAnnotating ? "crosshair" : "default" }}
                      />
                    </>
                  )}

                  {/* Processing Overlay */}
                  {isProcessing && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center rounded-lg bg-black/70">
                      <div className="mb-4 h-10 w-10 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
                      <p className="mb-2 text-lg font-medium">
                        جاري تحليل {activeTab === "image" ? "الصورة" : "الفيديو"}...
                      </p>
                      <div className="w-3/4">
                        <Progress value={processingProgress} className="h-2 bg-gray-700">
                          <div className="h-full bg-yellow-500" style={{ width: `${processingProgress}%` }} />
                        </Progress>
                        <p className="mt-1 text-center text-sm text-gray-400">{processingProgress}%</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Process Button */}
                {!isProcessing && !peopleCount && (
                  <Button
                    className="w-full bg-yellow-500 text-black hover:bg-yellow-600"
                    onClick={activeTab === "image" ? processImage : processVideo}
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    تحليل {activeTab === "image" ? "الصورة" : "الفيديو"}
                  </Button>
                )}

                {/* Detection Settings */}
                {!isProcessing && peopleCount !== null && (
                  <div className="space-y-4 rounded-lg border border-gray-800 bg-gray-800 p-4 mt-4">
                    <h4 className="font-medium">إعدادات متقدمة للتعرف على الأشخاص</h4>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={faceRecognitionEnabled}
                            onCheckedChange={setFaceRecognitionEnabled}
                            id="face-recognition"
                          />
                          <Label htmlFor="face-recognition">تمكين التعرف على الوجوه</Label>
                        </div>
                        <Badge className={faceRecognitionEnabled ? "bg-green-500" : "bg-gray-500"}>
                          {faceRecognitionEnabled ? "مفعل" : "معطل"}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={poseEstimationEnabled}
                            onCheckedChange={setPoseEstimationEnabled}
                            id="pose-estimation"
                          />
                          <Label htmlFor="pose-estimation">تمكين تحليل وضعية الجسم</Label>
                        </div>
                        <Badge className={poseEstimationEnabled ? "bg-green-500" : "bg-gray-500"}>
                          {poseEstimationEnabled ? "مفعل" : "معطل"}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={backgroundSubtractionEnabled}
                            onCheckedChange={setBackgroundSubtractionEnabled}
                            id="background-subtraction"
                          />
                          <Label htmlFor="background-subtraction">تمكين فصل الخلفية</Label>
                        </div>
                        <Badge className={backgroundSubtractionEnabled ? "bg-green-500" : "bg-gray-500"}>
                          {backgroundSubtractionEnabled ? "مفعل" : "معطل"}
                        </Badge>
                      </div>
                    </div>

                    <Button variant="outline" className="w-full" onClick={calibrateDetection} disabled={isCalibrating}>
                      {isCalibrating ? (
                        <>
                          <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                          معايرة النظام ({calibrationProgress}%)
                        </>
                      ) : (
                        "معايرة النظام لتحسين الدقة"
                      )}
                    </Button>
                  </div>
                )}

                {/* Results */}
                {peopleCount !== null && (
                  <div className="space-y-4 rounded-lg border border-gray-800 bg-gray-800 p-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">نتائج التحليل</h4>
                      <Badge className="bg-green-500">تم التحليل بنجاح</Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-lg bg-gray-900 p-3 text-center">
                        <Users className="mx-auto mb-2 h-6 w-6 text-yellow-500" />
                        <div className="text-2xl font-bold">{peopleCount}</div>
                        <div className="text-sm text-gray-400">عدد الأشخاص</div>
                      </div>

                      <div className="rounded-lg bg-gray-900 p-3 text-center">
                        <div className="mx-auto mb-2 h-6 w-6 rounded-full border-2 border-yellow-500 text-center">
                          <span className="text-sm font-bold leading-6 text-yellow-500">%</span>
                        </div>
                        <div className="text-2xl font-bold">{confidence}%</div>
                        <div className="text-sm text-gray-400">نسبة الثقة</div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => downloadResults("json")}
                      >
                        <FileJson className="h-4 w-4" />
                        <span>تنزيل JSON</span>
                      </Button>

                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => downloadResults("image")}
                      >
                        <FileImage className="h-4 w-4" />
                        <span>تنزيل الصورة</span>
                      </Button>

                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => downloadResults("chart")}
                      >
                        <BarChart3 className="h-4 w-4" />
                        <span>تنزيل التقرير</span>
                      </Button>
                    </div>

                    <div className="text-center text-xs text-gray-400">
                      تم تحليل {activeTab === "image" ? "الصورة" : "الفيديو"} باستخدام نموذج الذكاء الاصطناعي لعد
                      الأشخاص
                    </div>
                  </div>
                )}

                {/* Advanced Analysis Details */}
                {peopleCount !== null && (
                  <div className="space-y-4 rounded-lg border border-gray-800 bg-gray-800 p-4 mt-4">
                    <h4 className="font-medium">تفاصيل التحليل المتقدمة</h4>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-lg bg-gray-900 p-3">
                        <h5 className="text-sm font-medium text-gray-400">جودة الكشف</h5>
                        <div className="flex items-center mt-1">
                          <Badge
                            className={
                              detectionQuality === "high"
                                ? "bg-green-500"
                                : detectionQuality === "medium"
                                  ? "bg-yellow-500 text-black"
                                  : "bg-red-500"
                            }
                          >
                            {detectionQuality === "high"
                              ? "عالية"
                              : detectionQuality === "medium"
                                ? "متوسطة"
                                : "منخفضة"}
                          </Badge>
                        </div>
                      </div>

                      <div className="rounded-lg bg-gray-900 p-3">
                        <h5 className="text-sm font-medium text-gray-400">الكشف الخاطئ</h5>
                        <div className="flex items-center mt-1">
                          <span className="text-lg font-bold">{falsePositives}</span>
                          <span className="mr-1 text-sm text-gray-400">تم استبعادها</span>
                        </div>
                      </div>

                      <div className="rounded-lg bg-gray-900 p-3">
                        <h5 className="text-sm font-medium text-gray-400">الوجوه المكتشفة</h5>
                        <div className="flex items-center mt-1">
                          <span className="text-lg font-bold">{detectedFaces.length}</span>
                          <span className="mr-1 text-sm text-gray-400">وجه</span>
                        </div>
                      </div>

                      <div className="rounded-lg bg-gray-900 p-3">
                        <h5 className="text-sm font-medium text-gray-400">معرفات فريدة</h5>
                        <div className="flex items-center mt-1">
                          <span className="text-lg font-bold">{uniquePersonIds.length}</span>
                          <span className="mr-1 text-sm text-gray-400">شخص</span>
                        </div>
                      </div>
                    </div>

                    {detectionHistory.length > 0 && (
                      <div>
                        <h5 className="text-sm font-medium text-gray-400 mb-2">سجل الكشف</h5>
                        <div className="h-20 w-full bg-gray-900 rounded-lg p-2 relative">
                          {detectionHistory.map((entry, index) => {
                            const x = (index / (detectionHistory.length - 1 || 1)) * 100
                            const y =
                              100 - (entry.count / (Math.max(...detectionHistory.map((e) => e.count)) || 1)) * 100
                            return (
                              <div
                                key={entry.timestamp}
                                className="absolute w-2 h-2 rounded-full bg-yellow-500"
                                style={{
                                  left: `${x}%`,
                                  top: `${y}%`,
                                  transform: "translate(-50%, -50%)",
                                }}
                                title={`${entry.count} أشخاص (${entry.confidence}% ثقة)`}
                              />
                            )
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Feedback UI */}
                {peopleCount !== null && !isProcessing && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => setShowFeedbackForm(!showFeedbackForm)}
                      >
                        {showFeedbackForm ? "إلغاء" : "تقديم ملاحظات على النتائج"}
                      </Button>
                    </div>

                    {showFeedbackForm && (
                      <div className="rounded-lg border border-gray-700 bg-gray-800 p-4">
                        <h4 className="mb-3 font-medium">تقديم ملاحظات لتحسين النظام</h4>

                        <div className="mb-4 space-y-2">
                          <p className="text-sm text-gray-400">
                            هل عدد الأشخاص المكتشف صحيح؟ إذا لم يكن كذلك، يمكنك تحديد الأشخاص يدويًا.
                          </p>

                          <div className="flex items-center gap-2">
                            <Button
                              variant={isAnnotating ? "destructive" : "outline"}
                              size="sm"
                              onClick={toggleAnnotationMode}
                            >
                              {isAnnotating ? "إلغاء التحديد" : "تحديد الأشخاص يدويًا"}
                            </Button>

                            {isAnnotating && (
                              <Button variant="outline" size="sm" onClick={clearAnnotations}>
                                مسح التحديدات
                              </Button>
                            )}
                          </div>

                          {isAnnotating && (
                            <div className="rounded bg-yellow-900/30 p-2 text-sm text-yellow-300">
                              انقر واسحب لتحديد الأشخاص في الصورة. كل مستطيل يمثل شخصًا واحدًا.
                            </div>
                          )}

                          <div className="flex items-center gap-2">
                            <label className="text-sm">العدد الصحيح للأشخاص:</label>
                            <input
                              type="number"
                              min="0"
                              className="w-20 rounded bg-gray-700 px-2 py-1 text-center"
                              value={userFeedbackCount !== null ? userFeedbackCount : peopleCount || 0}
                              onChange={(e) => setUserFeedbackCount(Number.parseInt(e.target.value) || 0)}
                            />
                          </div>
                        </div>

                        <Button
                          className="w-full bg-yellow-500 text-black hover:bg-yellow-600"
                          onClick={submitUserFeedback}
                          disabled={userFeedbackCount === null}
                        >
                          إرسال الملاحظات
                        </Button>
                      </div>
                    )}

                    {/* Crowd Analysis */}
                    {crowdAnalysis && (
                      <div className="rounded-lg border border-gray-700 bg-gray-800 p-4">
                        <h4 className="mb-2 font-medium">تحليل الحشود</h4>
                        <p className="text-gray-300">{crowdAnalysis}</p>

                        {peopleCount && peopleCount > 20 && (
                          <div className="mt-3 rounded bg-red-900/30 p-2 text-sm text-red-300">
                            <strong>تنبيه:</strong> تم اكتشاف ازدحام كبير. يرجى اتخاذ الإجراءات اللازمة لإدارة الحشود.
                          </div>
                        )}

                        {peopleCount && peopleCount > 10 && peopleCount <= 20 && (
                          <div className="mt-3 rounded bg-yellow-900/30 p-2 text-sm text-yellow-300">
                            <strong>ملاحظة:</strong> المنطقة مزدحمة. يُنصح بمراقبة الوضع.
                          </div>
                        )}

                        {peopleCount && peopleCount <= 10 && (
                          <div className="mt-3 rounded bg-green-900/30 p-2 text-sm text-green-300">
                            <strong>حالة جيدة:</strong> المنطقة غير مزدحمة ومستويات الحشود ضمن الحدود الآمنة.
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            <div className="text-center text-xs text-gray-500">
              يمكنك تحميل صور أو مقاطع فيديو لتحليلها وعد الأشخاص فيها باستخدام الذكاء الاصطناعي
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
