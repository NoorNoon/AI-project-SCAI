"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Users, Camera, RefreshCw } from "lucide-react"
import * as tf from "@tensorflow/tfjs"
import {
  createCrowdCountingModel,
  processImageForCrowdCounting,
  analyzeCrowdDensity,
  trainModelWithSampleData,
} from "@/lib/ai-utils"

export function CrowdAnalyzer() {
  const [model, setModel] = useState<tf.LayersModel | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [crowdCount, setCrowdCount] = useState(0)
  const [crowdDensity, setCrowdDensity] = useState(0)
  const [modelReady, setModelReady] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isStreaming, setIsStreaming] = useState(false)

  // Load TensorFlow.js model
  useEffect(() => {
    async function loadModel() {
      try {
        // Load TensorFlow.js
        await tf.ready()
        console.log("TensorFlow.js loaded successfully")

        // Create model
        const crowdModel = createCrowdCountingModel()

        // Train with sample data
        console.log("Training model with sample data...")
        await trainModelWithSampleData(crowdModel)
        console.log("Model training complete")

        setModel(crowdModel)
        setModelReady(true)
        setIsLoading(false)
      } catch (error) {
        console.error("Error loading TensorFlow.js model:", error)
        setIsLoading(false)
      }
    }

    loadModel()

    // Clean up
    return () => {
      if (model) {
        model.dispose()
      }
    }
  }, [])

  // Start camera stream
  const startCamera = async () => {
    if (!videoRef.current) return

    try {
      // Simulate camera access (in a real app, we would use navigator.mediaDevices.getUserMedia)
      setIsStreaming(true)

      // Simulate video frames with canvas
      const simulateVideoFrames = () => {
        if (!canvasRef.current || !isStreaming) return

        const ctx = canvasRef.current.getContext("2d")
        if (!ctx) return

        // Draw a simulated crowd scene
        ctx.fillStyle = "#333"
        ctx.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height)

        // Draw random dots to simulate people
        const numPeople = Math.floor(Math.random() * 100) + 50
        for (let i = 0; i < numPeople; i++) {
          const x = Math.random() * canvasRef.current.width
          const y = Math.random() * canvasRef.current.height
          const size = Math.random() * 3 + 1

          ctx.fillStyle = "rgba(255, 255, 255, 0.7)"
          ctx.beginPath()
          ctx.arc(x, y, size, 0, Math.PI * 2)
          ctx.fill()
        }

        if (isStreaming) {
          requestAnimationFrame(simulateVideoFrames)
        }
      }

      simulateVideoFrames()
    } catch (error) {
      console.error("Error accessing camera:", error)
      setIsStreaming(false)
    }
  }

  // Stop camera stream
  const stopCamera = () => {
    setIsStreaming(false)
  }

  // Analyze crowd from current frame
  const analyzeCrowd = async () => {
    if (!model || !canvasRef.current || !modelReady) return

    setIsAnalyzing(true)

    try {
      // Create an image from the canvas
      const image = new Image()
      image.src = canvasRef.current.toDataURL()

      await new Promise((resolve) => {
        image.onload = resolve
      })

      // Process the image
      const tensor = await processImageForCrowdCounting(image)

      // Analyze crowd density
      const result = await analyzeCrowdDensity(model, tensor)

      // Update state with results
      setCrowdCount(result.count)
      setCrowdDensity(result.density)

      // Clean up
      tensor.dispose()
    } catch (error) {
      console.error("Error analyzing crowd:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <Card className="border-gray-800 bg-gray-900">
      <CardContent className="p-4">
        <h3 className="mb-4 text-lg font-semibold">تحليل الحشود بالذكاء الاصطناعي</h3>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-8">
            <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
            <p className="text-gray-400">جاري تحميل نموذج الذكاء الاصطناعي...</p>
          </div>
        ) : (
          <>
            <div className="mb-4 rounded-lg bg-gray-800 p-2">
              <canvas ref={canvasRef} width={320} height={240} className="mx-auto rounded" />
              <video ref={videoRef} width={320} height={240} className="hidden" autoPlay playsInline muted />
            </div>

            <div className="mb-4 flex justify-between">
              <Button
                variant={isStreaming ? "destructive" : "default"}
                className={isStreaming ? "" : "bg-yellow-500 text-black hover:bg-yellow-600"}
                onClick={isStreaming ? stopCamera : startCamera}
                disabled={!modelReady}
              >
                <Camera className="mr-2 h-4 w-4" />
                {isStreaming ? "إيقاف الكاميرا" : "تشغيل الكاميرا"}
              </Button>

              <Button variant="outline" onClick={analyzeCrowd} disabled={!isStreaming || isAnalyzing || !modelReady}>
                {isAnalyzing ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                    جاري التحليل...
                  </>
                ) : (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    تحليل الحشد
                  </>
                )}
              </Button>
            </div>

            <div className="space-y-3">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-sm">كثافة الحشد</span>
                  <Badge
                    className={
                      crowdDensity > 80 ? "bg-red-500" : crowdDensity > 60 ? "bg-yellow-500 text-black" : "bg-green-500"
                    }
                  >
                    {crowdDensity > 80 ? "مزدحم" : crowdDensity > 60 ? "متوسط" : "متاح"}
                  </Badge>
                </div>
                <Progress value={crowdDensity} className="h-2 bg-gray-700">
                  <div
                    className={`h-full ${
                      crowdDensity > 80 ? "bg-red-500" : crowdDensity > 60 ? "bg-yellow-500" : "bg-green-500"
                    }`}
                    style={{ width: `${crowdDensity}%` }}
                  />
                </Progress>
              </div>

              <div className="flex items-center justify-between rounded-lg bg-gray-800 p-3">
                <span>عدد الأشخاص (تقريبي)</span>
                <div className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-yellow-500" />
                  <span className="text-lg font-bold">{crowdCount}</span>
                </div>
              </div>

              <p className="text-center text-xs text-gray-400">ملاحظة: هذا تحليل تقريبي باستخدام الذكاء الاصطناعي</p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
