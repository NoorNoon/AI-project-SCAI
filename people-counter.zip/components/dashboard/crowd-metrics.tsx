import type React from "react"
import { Card } from "@/components/ui/card"

const CrowdMetrics: React.FC = () => {
  // بيانات تمثيلية لمقاييس الحشود
  const metrics = [
    { time: "14:00", count: 12500, density: "منخفضة" },
    { time: "15:00", count: 18700, density: "متوسطة" },
    { time: "16:00", count: 22300, density: "متوسطة" },
    { time: "17:00", count: 24853, density: "متوسطة" },
  ]

  // حساب النسبة المئوية للتغير
  const calculateChange = (current: number, previous: number) => {
    if (previous === 0) return 100
    return ((current - previous) / previous) * 100
  }

  return (
    <div className="space-y-4">
      {metrics.map((metric, index) => {
        const previousCount = index > 0 ? metrics[index - 1].count : 0
        const change = calculateChange(metric.count, previousCount)
        const isPositive = change >= 0

        return (
          <Card key={index} className="p-3 flex justify-between items-center">
            <div>
              <div className="text-sm font-medium">{metric.time}</div>
              <div className="text-xs text-muted-foreground">كثافة {metric.density}</div>
            </div>

            <div className="text-right">
              <div className="font-medium">{metric.count.toLocaleString()}</div>
              {index > 0 && (
                <div className={`text-xs ${isPositive ? "text-green-500" : "text-red-500"}`}>
                  {isPositive ? "↑" : "↓"} {Math.abs(change).toFixed(1)}%
                </div>
              )}
            </div>
          </Card>
        )
      })}

      <div className="text-center text-sm text-muted-foreground pt-2">تحديث آخر: 17:15</div>
    </div>
  )
}

export default CrowdMetrics
