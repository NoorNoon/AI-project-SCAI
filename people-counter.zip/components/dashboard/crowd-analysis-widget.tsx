"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { getLatestResults, type CrowdAnalysisResult } from "@/lib/crowd-analysis-service"
import { format } from "date-fns"
import { ar } from "date-fns/locale"
import { ArrowRight } from "lucide-react"
import Link from "next/link"
import { useCrowdAnalysis } from "../context/crowd-analysis-context"
import PeopleCounter from "../people-counter/people-counter"

const CrowdAnalysisWidget = () => {
  const { peopleCount, crowdDensity, alertLevel } = useCrowdAnalysis()
  const [latestResults, setLatestResults] = useState<CrowdAnalysisResult[]>([])

  useEffect(() => {
    const loadData = async () => {
      const results = await getLatestResults(10)
      setLatestResults(results)
    }

    loadData()
  }, [])

  // تحويل النتائج إلى تنسيق مناسب للرسوم البيانية
  const getChartData = () => {
    return latestResults
      .map((result) => ({
        time: format(new Date(result.created_at), "HH:mm", { locale: ar }),
        count: result.people_count,
      }))
      .reverse()
  }

  // تحديد لون التنبيه بناءً على مستوى الخطورة
  const getAlertColor = () => {
    switch (alertLevel) {
      case "critical":
        return "bg-red-500"
      case "high":
        return "bg-orange-500"
      case "medium":
        return "bg-amber-500"
      default:
        return "bg-green-500"
    }
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle>تحليل الحشود المباشر</CardTitle>
          <Link href="/crowd-analysis">
            <Button variant="ghost" size="sm" className="gap-1">
              عرض التفاصيل
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">عدد الأشخاص الحالي</div>
                <div className="text-3xl font-bold">{peopleCount}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">الكثافة</div>
                <div className="text-xl">{crowdDensity}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">الحالة</div>
                <div className="flex items-center">
                  <div className={`h-3 w-3 rounded-full mr-2 ${getAlertColor()}`}></div>
                  <span>
                    {alertLevel === "critical" && "حرجة"}
                    {alertLevel === "high" && "عالية"}
                    {alertLevel === "medium" && "متوسطة"}
                    {alertLevel === "low" && "منخفضة"}
                  </span>
                </div>
              </div>
            </div>

            <div className="h-40">
              {latestResults.length === 0 ? (
                <div className="h-full flex items-center justify-center border rounded-md">
                  <p className="text-muted-foreground">لا توجد بيانات للعرض</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={getChartData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="count" name="عدد الأشخاص" stroke="#8884d8" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="border rounded-md p-2">
            <PeopleCounter embedded={true} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default CrowdAnalysisWidget
