import PeopleCounter from "@/components/people-counter"

export default function PeopleCounterPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="mb-6 text-2xl font-bold">نظام عد الأشخاص</h1>
      <p className="mb-6 text-gray-500">
        استخدم هذه الأداة لتحليل الصور والفيديوهات وعد الأشخاص فيها باستخدام تقنيات الذكاء الاصطناعي المتقدمة.
      </p>
      <PeopleCounter />
    </div>
  )
}
