import { getSupabaseClient } from "./supabase"
import type { Detection } from "@/components/people-counter/yolo-model"

// واجهة لجلسة تحليل الحشود
export interface CrowdAnalysisSession {
  id: string
  session_name: string | null
  location: string | null
  created_at: string
  updated_at: string
}

// واجهة لنتيجة تحليل الحشود
export interface CrowdAnalysisResult {
  id: string
  session_id: string
  people_count: number
  confidence_threshold: number
  processing_time: number | null
  image_url: string | null
  created_at: string
  detections?: DetectionDetail[]
}

// واجهة لتفاصيل الكشف
export interface DetectionDetail {
  id: string
  result_id: string
  detection_id: number | null
  bbox_x: number
  bbox_y: number
  bbox_width: number
  bbox_height: number
  score: number
  created_at: string
}

// إنشاء جلسة تحليل جديدة
export async function createSession(sessionName: string, location?: string): Promise<CrowdAnalysisSession | null> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase
    .from("crowd_analysis_sessions")
    .insert({
      session_name: sessionName,
      location: location || null,
    })
    .select()
    .single()

  if (error) {
    console.error("Error creating session:", error)
    return null
  }

  return data
}

// الحصول على جميع الجلسات
export async function getAllSessions(): Promise<CrowdAnalysisSession[]> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase
    .from("crowd_analysis_sessions")
    .select("*")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching sessions:", error)
    return []
  }

  return data || []
}

// حفظ نتيجة تحليل جديدة
export async function saveAnalysisResult(
  sessionId: string,
  peopleCount: number,
  confidenceThreshold: number,
  processingTime: number | null,
  detections: Detection[],
  imageUrl?: string,
): Promise<CrowdAnalysisResult | null> {
  const supabase = getSupabaseClient()

  // إنشاء نتيجة التحليل
  const { data: resultData, error: resultError } = await supabase
    .from("crowd_analysis_results")
    .insert({
      session_id: sessionId,
      people_count: peopleCount,
      confidence_threshold: confidenceThreshold,
      processing_time: processingTime,
      image_url: imageUrl || null,
    })
    .select()
    .single()

  if (resultError) {
    console.error("Error saving analysis result:", resultError)
    return null
  }

  // حفظ تفاصيل الكشف
  if (detections.length > 0) {
    const detectionInserts = detections.map((detection) => ({
      result_id: resultData.id,
      detection_id: detection.id || null,
      bbox_x: detection.bbox[0],
      bbox_y: detection.bbox[1],
      bbox_width: detection.bbox[2],
      bbox_height: detection.bbox[3],
      score: detection.score,
    }))

    const { error: detectionError } = await supabase.from("detection_details").insert(detectionInserts)

    if (detectionError) {
      console.error("Error saving detection details:", detectionError)
    }
  }

  return resultData
}

// الحصول على نتائج التحليل لجلسة معينة
export async function getResultsBySession(sessionId: string): Promise<CrowdAnalysisResult[]> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase
    .from("crowd_analysis_results")
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching results:", error)
    return []
  }

  return data || []
}

// الحصول على تفاصيل الكشف لنتيجة معينة
export async function getDetectionDetails(resultId: string): Promise<DetectionDetail[]> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase
    .from("detection_details")
    .select("*")
    .eq("result_id", resultId)
    .order("detection_id", { ascending: true })

  if (error) {
    console.error("Error fetching detection details:", error)
    return []
  }

  return data || []
}

// الحصول على آخر النتائج (مع حد أقصى)
export async function getLatestResults(limit = 10): Promise<CrowdAnalysisResult[]> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase
    .from("crowd_analysis_results")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(limit)

  if (error) {
    console.error("Error fetching latest results:", error)
    return []
  }

  return data || []
}

// حذف جلسة وجميع النتائج المرتبطة بها
export async function deleteSession(sessionId: string): Promise<boolean> {
  const supabase = getSupabaseClient()

  const { error } = await supabase.from("crowd_analysis_sessions").delete().eq("id", sessionId)

  if (error) {
    console.error("Error deleting session:", error)
    return false
  }

  return true
}
