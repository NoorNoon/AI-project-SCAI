import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// واجهة لرسائل الدردشة
export interface ChatMessage {
  role: "user" | "assistant" | "system"
  content: string
}

// سياق النظام للمساعد
const systemPrompt = `
أنت مساعد ذكي للملعب الرياضي، مهمتك مساعدة الزوار والمشجعين بكل ما يتعلق بالملعب والمباريات.
يمكنك تقديم معلومات عن:
- جدول المباريات القادمة وأوقاتها
- أسعار التذاكر وكيفية حجزها
- مرافق الملعب (المطاعم، دورات المياه، مواقف السيارات)
- خدمة الحضور الافتراضي
- إجراءات الطوارئ والسلامة
- توجيهات الوصول للملعب والتنقل داخله
- الخدمات المتاحة للأشخاص ذوي الاحتياجات الخاصة
- الأنشطة الترفيهية والفعاليات الخاصة
- خدمات كبار الشخصيات والضيافة
- الأسئلة المتعلقة بالفرق واللاعبين

كن ودودًا ومهذبًا ومفيدًا. قدم إجابات دقيقة وموجزة. إذا لم تكن متأكدًا من المعلومات، اطلب المزيد من التفاصيل أو اقترح التواصل مع موظفي الملعب.
`

// بيانات افتراضية للملعب (يمكن استبدالها بقاعدة بيانات حقيقية)
const stadiumData = {
  matches: [
    { id: 1, teams: "الهلال vs النصر", date: "2024-04-15", time: "21:00", status: "قادمة" },
    { id: 2, teams: "الاتحاد vs الأهلي", date: "2024-04-16", time: "20:30", status: "قادمة" },
    { id: 3, teams: "الاتفاق vs التعاون", date: "2024-04-17", time: "19:00", status: "قادمة" },
  ],
  tickets: {
    categories: [
      { name: "عادية", price: "50-100 ريال" },
      { name: "مميزة", price: "150-300 ريال" },
      { name: "VIP", price: "350-500 ريال" },
    ],
    booking: "يمكن حجز التذاكر عبر التطبيق أو موقع الويب الرسمي للملعب قبل المباراة بأسبوع.",
    online: "يمكنك حجز التذاكر عبر الإنترنت من خلال تطبيق الملعب الرسمي أو الموقع الإلكتروني.",
    refund: "يمكن استرداد قيمة التذكرة قبل 48 ساعة من موعد المباراة مع خصم 10% كرسوم إدارية.",
  },
  facilities: {
    restaurants: ["برجر كينج", "بيتزا هت", "ستاربكس", "باسكن روبنز", "مطاعم محلية"],
    parking: "مواقف متاحة في الجهات الأربع للملعب، مجانية لحاملي التذاكر.",
    restrooms: "دورات مياه في كل طابق، مع دورات مخصصة لذوي الاحتياجات الخاصة.",
    wifi: "خدمة واي فاي مجانية متوفرة في جميع أنحاء الملعب.",
    shops: "متاجر رسمية لبيع منتجات الأندية والتذكارات في الطابق الأرضي.",
    firstAid: "مراكز إسعافات أولية متوفرة في كل قسم من أقسام الملعب.",
    accessibility: "مرافق خاصة لذوي الاحتياجات الخاصة، بما في ذلك المصاعد والمنحدرات والمقاعد المخصصة.",
  },
  virtualAttendance: {
    description: "خدمة تتيح للمشجعين الاستمتاع بتجربة غامرة ثلاثية الأبعاد للملعب والتفاعل مع المشجعين الآخرين.",
    price: "30 ريال",
    features: [
      "مشاهدة المباراة من زوايا متعددة",
      "التنقل بين المدرجات",
      "التقاط صور افتراضية",
      "المشاركة في الهتافات الجماعية",
    ],
    requirements: "تحتاج إلى اتصال إنترنت سريع (10 ميجابت/ثانية على الأقل) وجهاز حديث.",
    howToJoin: "يمكنك الانضمام عبر تطبيق الملعب الرسمي أو الموقع الإلكتروني بعد شراء تذكرة افتراضية.",
  },
  emergencyProcedures: {
    fire: "في حالة الحريق، اتبع إرشادات المنظمين والتوجه إلى أقرب مخرج طوارئ.",
    medical: "نقاط إسعاف متوفرة في كل قسم من أقسام الملعب.",
    evacuation: "مخارج الطوارئ موضحة بإشارات مضيئة خضراء.",
    contact: "في حالات الطوارئ، يمكن الاتصال بالرقم الداخلي 1234 أو التوجه لأقرب موظف أمن.",
    lostChild: "في حالة فقدان طفل، توجه إلى أقرب نقطة أمن أو مكتب استعلامات.",
  },
  transportation: {
    public: "يمكن الوصول إلى الملعب عبر خطوط المترو (الخط الأحمر، محطة الملعب) أو الحافلات العامة (خطوط 15، 23، 47).",
    parking: "مواقف السيارات متوفرة حول الملعب، ويفضل الحجز المسبق في المباريات الكبيرة.",
    shuttle: "خدمة حافلات مكوكية متوفرة من مواقف السيارات البعيدة إلى بوابات الملعب.",
    taxi: "منطقة مخصصة لسيارات الأجرة وخدمات النقل التشاركي عند البوابة الشمالية.",
    directions: "يمكن الوصول إلى الملعب عبر طريق الملك فهد (من الشمال)، طريق الأمير محمد بن سلمان (من الجنوب).",
  },
  vipServices: {
    lounges: "صالات VIP مجهزة بالكامل مع خدمة طعام وشراب فاخرة.",
    parking: "مواقف سيارات خاصة قريبة من المداخل الرئيسية.",
    entrance: "مداخل خاصة لتجنب الازدحام.",
    hospitality: "خدمات ضيافة متميزة تشمل قائمة طعام فاخرة ومشروبات متنوعة.",
    price: "تبدأ أسعار باقات VIP من 1000 ريال للمباراة الواحدة.",
  },
  teams: {
    الهلال: {
      coach: "المدرب: خورخي جيسوس",
      captain: "القائد: سلمان الفرج",
      topScorer: "الهداف: سالم الدوسري (15 هدف)",
      lastMatch: "آخر مباراة: فوز على النصر 2-1",
      nextMatch: "المباراة القادمة: ضد النصر، 15 أبريل، 21:00",
    },
    النصر: {
      coach: "المدرب: لويس كاسترو",
      captain: "القائد: عبدالله العمري",
      topScorer: "الهداف: كريستيانو رونالدو (18 هدف)",
      lastMatch: "آخر مباراة: خسارة أمام الهلال 1-2",
      nextMatch: "المباراة القادمة: ضد الهلال، 15 أبريل، 21:00",
    },
    الاتحاد: {
      coach: "المدرب: كوزمين كونترا",
      captain: "القائد: كريم الأحمدي",
      topScorer: "الهداف: رومارينيو (12 هدف)",
      lastMatch: "آخر مباراة: تعادل مع الأهلي 2-2",
      nextMatch: "المباراة القادمة: ضد الأهلي، 16 أبريل، 20:30",
    },
  },
  events: {
    upcoming: [
      { name: "مهرجان المشجعين", date: "2024-04-20", description: "مهرجان ترفيهي للمشجعين قبل نهائي كأس الملك" },
      {
        name: "معرض تاريخ الكرة السعودية",
        date: "2024-04-25 إلى 2024-05-05",
        description: "معرض يوثق تاريخ كرة القدم السعودية",
      },
    ],
    activities: [
      "منطقة ألعاب للأطفال في الطابق الأرضي",
      "منطقة تجربة الواقع الافتراضي",
      "منطقة التقاط الصور التذكارية مع كؤوس البطولات",
      "منطقة توقيعات اللاعبين قبل المباريات بساعتين",
    ],
  },
}

// قاموس الكلمات المفتاحية لتحسين التعرف على الاستفسارات
const keywordDictionary = {
  // المباريات والجدول
  matches: [
    "مباراة",
    "مباريات",
    "جدول",
    "موعد",
    "متى",
    "توقيت",
    "لقاء",
    "مواجهة",
    "كم الساعة",
    "أي يوم",
    "القادمة",
    "المقبلة",
  ],

  // التذاكر والحجز
  tickets: [
    "تذكرة",
    "تذاكر",
    "حجز",
    "شراء",
    "سعر",
    "تكلفة",
    "كم سعر",
    "أسعار",
    "استرداد",
    "إلغاء",
    "حجوزات",
    "أماكن",
    "مقاعد",
    "أونلاين",
    "الكتروني",
  ],

  // معلومات الملعب
  stadium: [
    "ملعب",
    "استاد",
    "سعة",
    "مدرجات",
    "مقاعد",
    "منشأة",
    "مرافق",
    "مبنى",
    "قسم",
    "منطقة",
    "بوابة",
    "مدخل",
    "خريطة",
  ],

  // المطاعم والطعام
  food: [
    "مطعم",
    "مطاعم",
    "أكل",
    "طعام",
    "وجبة",
    "وجبات",
    "مشروبات",
    "كافيه",
    "كافتيريا",
    "مقهى",
    "مأكولات",
    "شراب",
    "عصير",
    "ماء",
  ],

  // مواقف السيارات
  parking: ["موقف", "مواقف", "سيارة", "سيارات", "باركينج", "وقوف", "ركن", "أين أوقف", "أين أركن", "صف السيارة"],

  // دورات المياه
  restrooms: ["دورة مياه", "دورات مياه", "حمام", "حمامات", "مرحاض", "مغسلة", "غسل اليدين", "توالت"],

  // الوصول والتنقل
  access: [
    "وصول",
    "دخول",
    "بوابة",
    "بوابات",
    "مدخل",
    "مداخل",
    "طريق",
    "اتجاه",
    "كيف أصل",
    "أين",
    "مسار",
    "خريطة",
    "موقع",
    "مكان",
  ],

  // الحضور الافتراضي
  virtual: [
    "افتراضي",
    "حضور عن بعد",
    "اون لاين",
    "أونلاين",
    "عن بعد",
    "رقمي",
    "إلكتروني",
    "فيرتشوال",
    "تجربة افتراضية",
    "محاكاة",
  ],

  // الطوارئ والسلامة
  emergency: [
    "طوارئ",
    "حريق",
    "إسعاف",
    "إخلاء",
    "أمن",
    "سلامة",
    "حادث",
    "إصابة",
    "مساعدة طبية",
    "طبيب",
    "مستشفى",
    "إنقاذ",
    "خطر",
  ],

  // خدمات VIP
  vip: [
    "vip",
    "في آي بي",
    "كبار الشخصيات",
    "كبار الزوار",
    "صالة خاصة",
    "خدمة مميزة",
    "درجة أولى",
    "خدمة فاخرة",
    "ضيافة",
  ],

  // الفرق واللاعبين
  teams: [
    "فريق",
    "نادي",
    "لاعب",
    "لاعبين",
    "مدرب",
    "كابتن",
    "قائد",
    "هداف",
    "تشكيلة",
    "احتياط",
    "أساسي",
    "نجم",
    "نجوم",
    "هلال",
    "نصر",
    "اتحاد",
    "أهلي",
    "شباب",
    "تعاون",
    "اتفاق",
  ],

  // الفعاليات والأنشطة
  events: [
    "فعالية",
    "نشاط",
    "مهرجان",
    "معرض",
    "حدث",
    "احتفال",
    "ترفيه",
    "ألعاب",
    "مسابقة",
    "جائزة",
    "هدية",
    "تذكار",
    "صورة",
    "توقيع",
  ],

  // الواي فاي والخدمات الإلكترونية
  tech: [
    "واي فاي",
    "انترنت",
    "شبكة",
    "اتصال",
    "شحن",
    "بطارية",
    "موبايل",
    "جوال",
    "هاتف",
    "تطبيق",
    "ابليكيشن",
    "موقع الكتروني",
  ],

  // ذوي الاحتياجات الخاصة
  accessibility: [
    "ذوي الاحتياجات",
    "ذوي الهمم",
    "إعاقة",
    "كرسي متحرك",
    "مصعد",
    "منحدر",
    "مساعدة خاصة",
    "احتياجات خاصة",
  ],

  // المواصلات
  transport: ["مواصلات", "نقل", "باص", "حافلة", "مترو", "قطار", "تاكسي", "أجرة", "أوبر", "كريم", "مشاركة", "توصيل"],

  // الشكر والتحية
  thanks: ["شكرا", "شكر", "ممتاز", "رائع", "جميل", "أحسنت", "تمام", "جزاك الله خير", "بارك الله فيك", "مشكور"],
}

// دالة للتعرف على نوع الاستفسار بناءً على الكلمات المفتاحية
function identifyQueryType(query: string): string[] {
  const queryTypes: string[] = []
  const lowerQuery = query.toLowerCase()

  // فحص كل فئة من الكلمات المفتاحية
  for (const [category, keywords] of Object.entries(keywordDictionary)) {
    for (const keyword of keywords) {
      if (lowerQuery.includes(keyword)) {
        queryTypes.push(category)
        break // إذا وجدنا كلمة مفتاحية من هذه الفئة، ننتقل للفئة التالية
      }
    }
  }

  // إذا لم نجد أي نوع، نعتبره استفسارًا عامًا
  if (queryTypes.length === 0) {
    queryTypes.push("general")
  }

  return queryTypes
}

// دالة لتحويل البيانات إلى نص يمكن إضافته للسياق
function getContextData(query: string): string {
  let context = ""

  // تحديد أنواع الاستفسار
  const queryTypes = identifyQueryType(query)

  // إضافة معلومات حسب نوع الاستفسار
  for (const queryType of queryTypes) {
    switch (queryType) {
      case "matches":
        context += "المباريات القادمة:\n"
        stadiumData.matches.forEach((match) => {
          context += `- ${match.teams}: ${match.date} الساعة ${match.time}\n`
        })
        break

      case "tickets":
        context += "\nفئات التذاكر:\n"
        stadiumData.tickets.categories.forEach((cat) => {
          context += `- ${cat.name}: ${cat.price}\n`
        })
        context += `\nمعلومات الحجز: ${stadiumData.tickets.booking}\n`
        context += `الحجز عبر الإنترنت: ${stadiumData.tickets.online}\n`
        context += `سياسة الاسترداد: ${stadiumData.tickets.refund}\n`
        break

      case "food":
        context += "\nالمطاعم المتوفرة: " + stadiumData.facilities.restaurants.join("، ") + "\n"
        break

      case "parking":
        context += "\nمعلومات مواقف السيارات: " + stadiumData.facilities.parking + "\n"
        break

      case "restrooms":
        context += "\nدورات المياه: " + stadiumData.facilities.restrooms + "\n"
        break

      case "virtual":
        context += "\nخدمة الحضور الافتراضي:\n"
        context += `- ${stadiumData.virtualAttendance.description}\n`
        context += `- السعر: ${stadiumData.virtualAttendance.price}\n`
        context += "- المميزات: " + stadiumData.virtualAttendance.features.join("، ") + "\n"
        context += `- المتطلبات التقنية: ${stadiumData.virtualAttendance.requirements}\n`
        context += `- كيفية الانضمام: ${stadiumData.virtualAttendance.howToJoin}\n`
        break

      case "emergency":
        context += "\nإجراءات الطوارئ:\n"
        context += `- حالات الحريق: ${stadiumData.emergencyProcedures.fire}\n`
        context += `- الحالات الطبية: ${stadiumData.emergencyProcedures.medical}\n`
        context += `- الإخلاء: ${stadiumData.emergencyProcedures.evacuation}\n`
        context += `- الاتصال في حالات الطوارئ: ${stadiumData.emergencyProcedures.contact}\n`
        context += `- في حالة فقدان طفل: ${stadiumData.emergencyProcedures.lostChild}\n`
        break

      case "access":
      case "transport":
        context += "\nمعلومات الوصول والمواصلات:\n"
        context += `- المواصلات العامة: ${stadiumData.transportation.public}\n`
        context += `- مواقف السيارات: ${stadiumData.transportation.parking}\n`
        context += `- الحافلات المكوكية: ${stadiumData.transportation.shuttle}\n`
        context += `- سيارات الأجرة: ${stadiumData.transportation.taxi}\n`
        context += `- الاتجاهات: ${stadiumData.transportation.directions}\n`
        break

      case "vip":
        context += "\nخدمات كبار الشخصيات (VIP):\n"
        context += `- الصالات: ${stadiumData.vipServices.lounges}\n`
        context += `- مواقف السيارات: ${stadiumData.vipServices.parking}\n`
        context += `- المداخل: ${stadiumData.vipServices.entrance}\n`
        context += `- خدمات الضيافة: ${stadiumData.vipServices.hospitality}\n`
        context += `- الأسعار: ${stadiumData.vipServices.price}\n`
        break

      case "teams":
        // إضافة معلومات عن الفرق المذكورة في الاستفسار
        for (const [teamName, teamInfo] of Object.entries(stadiumData.teams)) {
          if (query.includes(teamName)) {
            context += `\nمعلومات عن فريق ${teamName}:\n`
            for (const [key, value] of Object.entries(teamInfo)) {
              context += `- ${value}\n`
            }
          }
        }
        // إذا لم يتم ذكر فريق محدد، نضيف معلومات عامة عن جميع الفرق
        if (!context.includes("معلومات عن فريق")) {
          context += "\nمعلومات عن الفرق المشاركة في المباريات القادمة:\n"
          for (const match of stadiumData.matches) {
            context += `- ${match.teams}: ${match.date} الساعة ${match.time}\n`
          }
        }
        break

      case "events":
        context += "\nالفعاليات القادمة:\n"
        stadiumData.events.upcoming.forEach((event) => {
          context += `- ${event.name}: ${event.date} - ${event.description}\n`
        })
        context += "\nالأنشطة المتاحة في الملعب:\n"
        stadiumData.events.activities.forEach((activity) => {
          context += `- ${activity}\n`
        })
        break

      case "tech":
        context += `\nخدمات التكنولوجيا: ${stadiumData.facilities.wifi}\n`
        break

      case "accessibility":
        context += `\nخدمات ذوي الاحتياجات الخاصة: ${stadiumData.facilities.accessibility}\n`
        break

      case "stadium":
        context += "\nمرافق الملعب:\n"
        context += `- المطاعم: ${stadiumData.facilities.restaurants.join("، ")}\n`
        context += `- دورات المياه: ${stadiumData.facilities.restrooms}\n`
        context += `- مواقف السيارات: ${stadiumData.facilities.parking}\n`
        context += `- الواي فاي: ${stadiumData.facilities.wifi}\n`
        context += `- المتاجر: ${stadiumData.facilities.shops}\n`
        context += `- الإسعافات الأولية: ${stadiumData.facilities.firstAid}\n`
        context += `- خدمات ذوي الاحتياجات الخاصة: ${stadiumData.facilities.accessibility}\n`
        break
    }
  }

  return context
}

// نظام الاستجابة الاحتياطي (النموذج البسيط)
class SimpleChatModel {
  private contextMemory: string[] = []
  private maxContextLength = 5

  // إضافة سياق إلى الذاكرة
  addToContext(text: string) {
    this.contextMemory.push(text)
    if (this.contextMemory.length > this.maxContextLength) {
      this.contextMemory.shift() // إزالة أقدم عنصر
    }
  }

  // الحصول على سياق المحادثة الحالي
  getContext(): string {
    return this.contextMemory.join(" ")
  }

  // تحليل النص وتحديد نوع الاستفسار
  async analyzeQuery(text: string): Promise<string[]> {
    // إضافة النص إلى السياق
    this.addToContext(text)

    // استخدام دالة تحديد نوع الاستفسار
    return identifyQueryType(text)
  }

  // تحليل سياق المحادثة وتقديم إجابة مناسبة
  async generateResponse(queryTypes: string[], userQuery: string): Promise<string> {
    // قاعدة بيانات الإجابات حسب نوع الاستفسار
    const responses: Record<string, string[]> = {
      matches: [
        "المباريات القادمة: الهلال ضد النصر (الجمعة، 15 أبريل، 9:00 مساءً)، الاتحاد ضد الأهلي (السبت، 16 أبريل، 8:30 مساءً)، الاتفاق ضد التعاون (الأحد، 17 أبريل، 7:00 مساءً).",
        "مباراة الهلال والنصر ستقام يوم الجمعة القادم الساعة 9 مساءً. هل ترغب في معلومات عن التذاكر؟",
        "جدول المباريات لهذا الأسبوع: الجمعة (الهلال/النصر)، السبت (الاتحاد/الأهلي)، الأحد (الاتفاق/التعاون).",
      ],
      tickets: [
        "يمكنك حجز التذاكر عبر التطبيق أو موقع الويب الرسمي للملعب. تتراوح أسعار التذاكر بين 50 و500 ريال حسب موقع المقعد والمباراة.",
        "التذاكر متوفرة للحجز قبل المباراة بأسبوع. للمباريات الكبيرة مثل الهلال والنصر، ننصح بالحجز مبكراً.",
        "هناك فئات مختلفة من التذاكر: عادية (50-100 ريال)، مميزة (150-300 ريال)، VIP (350-500 ريال). يمكن استرداد قيمة التذكرة قبل 48 ساعة من المباراة مع خصم 10%.",
      ],
      stadium: [
        "استاد الملك فهد الدولي يتسع لـ 45,000 متفرج ويحتوي على مناطق متعددة: المدرجات الشمالية (A)، المدرجات الجنوبية (C)، المدرجات الشرقية (B)، المدرجات الغربية (D)، ومنطقة كبار الشخصيات (VIP).",
        "الملعب مجهز بأحدث التقنيات، بما في ذلك شاشات عرض عملاقة ونظام صوتي متطور ونظام تكييف للحفاظ على درجة حرارة مريحة.",
        "تم تجديد الملعب مؤخراً لتحسين تجربة المشجعين، مع إضافة مقاعد مريحة ومناطق ترفيهية ومطاعم متنوعة.",
      ],
      food: [
        "يوجد في الملعب مجموعة متنوعة من المطاعم والمقاهي في الطابق الأرضي، تقدم وجبات سريعة ومشروبات.",
        "المطاعم المتوفرة: برجر كينج، بيتزا هت، ستاربكس، باسكن روبنز، ومطاعم محلية تقدم المأكولات السعودية التقليدية.",
        "يمكنك طلب الطعام مسبقاً عبر التطبيق وتحديد وقت الاستلام لتجنب الانتظار في الطوابير.",
      ],
      parking: [
        "تتوفر مواقف للسيارات في الجهات الأربع للملعب. يمكنك استخدام خدمة إرشاد المواقف في التطبيق للعثور على أقرب موقف متاح.",
        "مواقف السيارات مجانية لحاملي التذاكر. تفتح المواقف قبل المباراة بثلاث ساعات وتغلق بعد ساعتين من انتهاء المباراة.",
        "هناك خدمة نقل مكوكية من المواقف البعيدة إلى بوابات الملعب. تعمل الخدمة قبل المباراة بساعتين وبعدها بساعة.",
      ],
      restrooms: [
        "توجد دورات مياه في كل طابق من طوابق الملعب، وهي مجهزة بشكل كامل ويتم تنظيفها بانتظام.",
        "دورات المياه متوفرة بالقرب من كل مدرج، وهناك دورات مياه مخصصة لذوي الاحتياجات الخاصة.",
        "يتم تنظيف دورات المياه باستمرار خلال المباريات للحفاظ على نظافتها.",
      ],
      access: [
        "يفتح الملعب أبوابه قبل المباراة بساعتين. يرجى الوصول مبكراً لتجنب الازدحام. البوابات الرئيسية هي A1-A4 (شمال)، B1-B4 (شرق)، C1-C4 (جنوب)، D1-D4 (غرب).",
        "يمكنك الوصول إلى الملعب عبر الطرق الرئيسية: طريق الملك فهد من الشمال، طريق الأمير محمد بن سلمان من الجنوب، طريق الأمير تركي من الشرق.",
        "هناك خدمة حافلات من وإلى محطات المترو الرئيسية. تبدأ الخدمة قبل المباراة بأربع ساعات وتستمر حتى ساعتين بعد المباراة.",
      ],
      virtual: [
        "خدمة الحضور الافتراضي متاحة للمشجعين الذين لا يستطيعون الحضور شخصياً. يمكنك الاستمتاع بتجربة غامرة ثلاثية الأبعاد للملعب والتفاعل مع المشجعين الآخرين.",
        "يمكنك شراء تذكرة افتراضية بسعر 30 ريال والاستمتاع بمشاهدة المباراة من زوايا متعددة والتفاعل مع المشجعين الآخرين.",
        "التجربة الافتراضية تتيح لك التنقل بين المدرجات المختلفة، والتقاط صور افتراضية، والمشاركة في الهتافات الجماعية. تحتاج إلى اتصال إنترنت سريع وجهاز حديث.",
      ],
      thanks: [
        "شكراً لك! يسعدني مساعدتك. هل هناك أي استفسار آخر؟",
        "العفو! أنا هنا لمساعدتك في أي وقت. هل تحتاج إلى معلومات إضافية؟",
        "سعيد بخدمتك! هل يمكنني مساعدتك في شيء آخر؟",
      ],
      emergency: [
        "في حالات الطوارئ، اتبع إرشادات موظفي الأمن والسلامة. مخارج الطوارئ موضحة بإشارات مضيئة خضراء في جميع أنحاء الملعب.",
        "نقاط الإسعافات الأولية متوفرة في كل قسم من أقسام الملعب. في حالة الحريق، اتبع إرشادات المنظمين والتوجه إلى أقرب مخرج طوارئ.",
        "في حالة فقدان طفل، توجه إلى أقرب نقطة أمن أو مكتب استعلامات. يمكن الاتصال بالرقم الداخلي 1234 في حالات الطوارئ.",
      ],
      vip: [
        "خدمات VIP تشمل صالات خاصة مجهزة بالكامل مع خدمة طعام وشراب فاخرة، ومواقف سيارات خاصة، ومداخل منفصلة لتجنب الازدحام.",
        "تبدأ أسعار باقات VIP من 1000 ريال للمباراة الواحدة، وتشمل خدمات ضيافة متميزة وإطلالة مميزة على الملعب.",
        "يمكنك حجز خدمات VIP عبر التطبيق أو الموقع الإلكتروني أو الاتصال بمكتب الحجز الخاص على الرقم 9000.",
      ],
      teams: [
        "فريق الهلال بقيادة المدرب خورخي جيسوس والكابتن سلمان الفرج. الهداف الحالي هو سالم الدوسري برصيد 15 هدفاً.",
        "فريق النصر بقيادة المدرب لويس كاسترو والكابتن عبدالله العمري. الهداف الحالي هو كريستيانو رونالدو برصيد 18 هدفاً.",
        "فريق الاتحاد بقيادة المدرب كوزمين كونترا والكابتن كريم الأحمدي. الهداف الحالي هو رومارينيو برصيد 12 هدفاً.",
      ],
      events: [
        "الفعاليات القادمة: مهرجان المشجعين (20 أبريل)، معرض تاريخ الكرة السعودية (25 أبريل إلى 5 مايو).",
        "توجد منطقة ألعاب للأطفال في الطابق الأرضي، ومنطقة تجربة الواقع الافتراضي، ومنطقة التقاط الصور التذكارية مع كؤوس البطولات.",
        "يمكنك الحصول على توقيعات اللاعبين قبل المباريات بساعتين في منطقة التوقيعات المخصصة بالقرب من المدخل الرئيسي.",
      ],
      tech: [
        "خدمة واي فاي مجانية متوفرة في جميع أنحاء الملعب. اسم الشبكة: StadiumWiFi، وكلمة المرور متوفرة على تذكرتك.",
        "توجد نقاط شحن للهواتف في مناطق متعددة من الملعب. يمكنك استخدام تطبيق الملعب للوصول إلى جميع الخدمات الإلكترونية.",
        "يمكنك تنزيل تطبيق الملعب الرسمي من متجر التطبيقات للوصول إلى خدمات حجز التذاكر، وخريطة الملعب، ومعلومات المباريات، وطلب الطعام.",
      ],
      accessibility: [
        "توجد مرافق خاصة لذوي الاحتياجات الخاصة، بما في ذلك المصاعد والمنحدرات والمقاعد المخصصة في جميع أقسام الملعب.",
        "يمكن حجز مقاعد مخصصة لذوي الاحتياجات الخاصة عند شراء التذاكر. توجد أيضاً دورات مياه مجهزة خصيصاً لهم.",
        "يتوفر موظفون مدربون لمساعدة ذوي الاحتياجات الخاصة. يمكن طلب المساعدة عند أي بوابة دخول أو من خلال التطبيق.",
      ],
      transport: [
        "يمكن الوصول إلى الملعب عبر خطوط المترو (الخط الأحمر، محطة الملعب) أو الحافلات العامة (خطوط 15، 23، 47).",
        "توجد منطقة مخصصة لسيارات الأجرة وخدمات النقل التشاركي مثل أوبر وكريم عند البوابة الشمالية.",
        "خدمة الحافلات المكوكية متوفرة من مواقف السيارات البعيدة إلى بوابات الملعب، وتعمل قبل المباراة بساعتين وبعدها بساعة.",
      ],
      general: [
        "يمكنني مساعدتك بمعلومات عن المباريات القادمة، حجز التذاكر، المطاعم، مواقف السيارات، وغيرها من خدمات الملعب. ما الذي ترغب في معرفته؟",
        "أنا مساعد الملعب الذكي، وأستطيع تقديم معلومات عن جميع جوانب تجربتك في الملعب. كيف يمكنني مساعدتك اليوم؟",
        "مرحباً! يمكنني مساعدتك في العثور على معلومات حول الملعب، المباريات، التذاكر، المرافق، وأكثر من ذلك. ما هو استفسارك؟",
      ],
    }

    // تحليل سياق المحادثة لتقديم إجابة أكثر تخصيصاً
    const context = this.getContext()

    // اختيار نوع الاستفسار الأكثر أهمية
    let primaryQueryType = queryTypes[0]

    // إذا كان هناك أكثر من نوع استفسار، نحاول اختيار النوع الأكثر تحديداً
    if (queryTypes.length > 1) {
      // الأولوية للاستفسارات المحددة على الاستفسارات العامة
      if (primaryQueryType === "general" && queryTypes.length > 1) {
        primaryQueryType = queryTypes[1]
      }

      // إذا كان هناك استفسار عن الشكر، نعطي الأولوية للاستفسارات الأخرى
      if (primaryQueryType === "thanks" && queryTypes.length > 1) {
        primaryQueryType = queryTypes.find((type) => type !== "thanks") || primaryQueryType
      }
    }

    // اختيار الإجابة بناءً على السياق
    let responseIndex = 0

    // تخصيص الإجابة بناءً على محتوى الاستفسار
    if (context.includes("شكرا") || context.includes("ممتاز") || context.includes("رائع")) {
      responseIndex = 0
    } else if (context.includes("سعر") || context.includes("كم") || context.includes("تكلفة")) {
      responseIndex = 1
    } else {
      // اختيار إجابة عشوائية من القائمة
      responseIndex = Math.floor(Math.random() * responses[primaryQueryType].length)
    }

    // إذا كان هناك أكثر من نوع استفسار، نضيف معلومات إضافية
    let additionalInfo = ""
    if (queryTypes.length > 1) {
      // نختار نوع استفسار آخر لإضافة معلومات إضافية
      const secondaryQueryType = queryTypes.find(
        (type) => type !== primaryQueryType && type !== "general" && type !== "thanks",
      )

      if (secondaryQueryType && responses[secondaryQueryType]) {
        additionalInfo =
          "\n\nأيضاً، " + responses[secondaryQueryType][Math.floor(Math.random() * responses[secondaryQueryType].length)]
      }
    }

    return responses[primaryQueryType][responseIndex] + additionalInfo
  }

  // تحليل المحادثة وإنشاء رد
  async chat(userMessage: string): Promise<string> {
    try {
      // تحليل نوع الاستفسار
      const queryTypes = await this.analyzeQuery(userMessage)

      // إنشاء رد مناسب
      return await this.generateResponse(queryTypes, userMessage)
    } catch (error) {
      console.error("Error in simple chat model:", error)
      return "عذراً، حدث خطأ أثناء معالجة طلبك. يمكنني مساعدتك بمعلومات عن المباريات القادمة أو خدمات الملعب."
    }
  }
}

// إنشاء نموذج واحد للاستخدام في التطبيق
let simpleChatModelInstance: SimpleChatModel | null = null

function getSimpleChatModel(): SimpleChatModel {
  if (!simpleChatModelInstance) {
    simpleChatModelInstance = new SimpleChatModel()
  }
  return simpleChatModelInstance
}

// نظام الذاكرة المؤقتة للردود
const responseCache = new Map<string, string>()

// دالة للحصول على رد من OpenAI مع نظام احتياطي
export async function getChatResponse(messages: ChatMessage[], userQuery: string): Promise<string> {
  try {
    // التحقق من وجود الرد في الذاكرة المؤقتة
    const cacheKey = userQuery.trim().toLowerCase()
    if (responseCache.has(cacheKey)) {
      console.log("Using cached response")
      return responseCache.get(cacheKey)!
    }

    // محاولة استخدام OpenAI
    try {
      // إضافة سياق محدد بناءً على الاستفسار
      const contextData = getContextData(userQuery)

      // إنشاء سياق محدث للنظام
      const updatedSystemPrompt =
        systemPrompt + (contextData ? `\n\nمعلومات إضافية للمساعدة في الإجابة:\n${contextData}` : "")

      // إعداد الرسائل للإرسال إلى OpenAI
      const formattedMessages: ChatMessage[] = [{ role: "system", content: updatedSystemPrompt }, ...messages]

      // استخدام AI SDK للحصول على رد
      const { text } = await generateText({
        model: openai("gpt-4o"),
        messages: formattedMessages,
        temperature: 0.7,
        maxTokens: 500,
      })

      // تخزين الرد في الذاكرة المؤقتة
      responseCache.set(cacheKey, text)

      return text
    } catch (error: any) {
      console.warn("OpenAI API error, falling back to simple model:", error.message)

      // استخدام النموذج البسيط كنظام احتياطي
      const simpleChatModel = getSimpleChatModel()
      const response = await simpleChatModel.chat(userQuery)

      // تخزين الرد في الذاكرة المؤقتة
      responseCache.set(cacheKey, response)

      return response
    }
  } catch (error) {
    console.error("Error getting chat response:", error)
    return "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى."
  }
}

// دالة مساعدة للتعامل مع الرسائل
export function formatMessagesForAPI(messages: any[]): ChatMessage[] {
  return messages.map((msg) => ({
    role: msg.role || "user", // استخدام "user" كقيمة افتراضية إذا لم يكن هناك دور محدد
    content: msg.content,
  }))
}
