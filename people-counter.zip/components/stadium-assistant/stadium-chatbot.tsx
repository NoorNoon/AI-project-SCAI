"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bot, Send, Mic, MicOff, X, Maximize, Minimize, VolumeX, Sparkles, Loader2, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface Message {
  role: "user" | "assistant"
  content: string
  timestamp: Date
  isThinking?: boolean
}

// قائمة الكلمات المفتاحية الشائعة للمساعدة في البحث السريع
const keywordCategories = [
  {
    title: "المباريات",
    keywords: ["مباريات", "جدول", "موعد", "الهلال", "النصر", "الاتحاد"],
  },
  {
    title: "التذاكر",
    keywords: ["تذاكر", "حجز", "سعر", "استرداد", "إلغاء"],
  },
  {
    title: "المرافق",
    keywords: ["مطاعم", "مواقف", "دورات مياه", "واي فاي", "متاجر"],
  },
  {
    title: "الخدمات",
    keywords: ["VIP", "حضور افتراضي", "ذوي الاحتياجات", "طوارئ", "مواصلات"],
  },
]

export default function StadiumChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "مرحباً! أنا مساعد الملعب الذكي. كيف يمكنني مساعدتك اليوم؟",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [isOpen, setIsOpen] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [recognizedText, setRecognizedText] = useState("")
  const [showKeywordSuggestions, setShowKeywordSuggestions] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // إعداد التعرف على الكلام
  useEffect(() => {
    if (typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window)) {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = "ar-SA"

      recognitionRef.current.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result: any) => result.transcript)
          .join("")

        setRecognizedText(transcript)
      }

      recognitionRef.current.onend = () => {
        if (isRecording) {
          // إعادة تشغيل التعرف إذا كان لا يزال في وضع التسجيل
          recognitionRef.current.start()
        }
      }
    }

    // إعداد تحويل النص إلى كلام
    if (typeof window !== "undefined" && "SpeechSynthesisUtterance" in window) {
      speechSynthesisRef.current = new SpeechSynthesisUtterance()
      speechSynthesisRef.current.lang = "ar-SA"
      speechSynthesisRef.current.rate = 1.0
      speechSynthesisRef.current.pitch = 1.0

      speechSynthesisRef.current.onend = () => {
        setIsSpeaking(false)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel()
      }
    }
  }, [isRecording])

  // تمرير إلى آخر رسالة عند إضافة رسالة جديدة
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // تحديث النص المدخل عند التعرف على الكلام
  useEffect(() => {
    if (recognizedText) {
      setInput(recognizedText)
    }
  }, [recognizedText])

  // إظهار اقتراحات الكلمات المفتاحية عند التركيز على حقل الإدخال
  const handleInputFocus = () => {
    if (messages.length > 1) {
      setShowKeywordSuggestions(true)
    }
  }

  // إخفاء اقتراحات الكلمات المفتاحية عند فقدان التركيز
  const handleInputBlur = () => {
    // تأخير إخفاء الاقتراحات للسماح بالنقر عليها
    setTimeout(() => {
      setShowKeywordSuggestions(false)
    }, 200)
  }

  const toggleRecording = () => {
    if (!recognitionRef.current) return

    if (isRecording) {
      recognitionRef.current.stop()
      // إرسال الرسالة المتعرف عليها إذا كانت غير فارغة
      if (recognizedText.trim()) {
        handleSendMessage(recognizedText.trim())
      }
    } else {
      setRecognizedText("")
      recognitionRef.current.start()
    }

    setIsRecording(!isRecording)
  }

  const speakMessage = (text: string) => {
    if (!speechSynthesisRef.current || !window.speechSynthesis) return

    // إيقاف أي كلام حالي
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel()
    }

    speechSynthesisRef.current.text = text
    window.speechSynthesis.speak(speechSynthesisRef.current)
    setIsSpeaking(true)
  }

  const stopSpeaking = () => {
    if (window.speechSynthesis && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const handleSendMessage = async (messageText: string = input) => {
    if (!messageText.trim()) return

    // إضافة رسالة المستخدم
    const userMessage: Message = {
      role: "user",
      content: messageText,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setRecognizedText("")
    setIsLoading(true)
    setShowKeywordSuggestions(false)

    // إضافة رسالة "جاري التفكير..."
    setMessages((prev) => [
      ...prev,
      {
        role: "assistant",
        content: "جاري التفكير...",
        timestamp: new Date(),
        isThinking: true,
      },
    ])

    try {
      // إرسال الرسائل إلى API
      const response = await fetch("/api/stadium-assistant", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((msg) => ({
            role: msg.role,
            content: msg.content,
          })),
        }),
      })

      if (!response.ok) {
        throw new Error("فشل في الاتصال بالمساعد")
      }

      const data = await response.json()

      // إزالة رسالة "جاري التفكير..." واستبدالها بالرد الفعلي
      setMessages((prev) => {
        const newMessages = [...prev]
        // إزالة آخر رسالة (رسالة التفكير)
        newMessages.pop()
        // إضافة رد المساعد
        newMessages.push({
          role: "assistant",
          content: data.response,
          timestamp: new Date(),
        })
        return newMessages
      })

      // قراءة الرد صوتياً إذا كان التسجيل نشطاً
      if (isRecording) {
        speakMessage(data.response)
      }
    } catch (error) {
      console.error("Error sending message:", error)

      // إزالة رسالة "جاري التفكير..." واستبدالها برسالة الخطأ
      setMessages((prev) => {
        const newMessages = [...prev]
        // إزالة آخر رسالة (رسالة التفكير)
        newMessages.pop()
        // إضافة رسالة الخطأ
        newMessages.push({
          role: "assistant",
          content: "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.",
          timestamp: new Date(),
        })
        return newMessages
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSendMessage()
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })
  }

  // إضافة كلمة مفتاحية إلى حقل الإدخال
  const addKeywordToInput = (keyword: string) => {
    setInput((prev) => {
      // إذا كان هناك نص بالفعل، نضيف مسافة قبل الكلمة المفتاحية
      const prefix = prev.trim() ? `${prev.trim()} ` : ""
      return `${prefix}${keyword}`
    })
    // التركيز على حقل الإدخال بعد إضافة الكلمة المفتاحية
    inputRef.current?.focus()
  }

  // اقتراحات سريعة للمستخدم
  const quickSuggestions = [
    "ما هي المباريات القادمة؟",
    "كيف يمكنني حجز تذكرة؟",
    "أين توجد المطاعم في الملعب؟",
    "ما هي خدمة الحضور الافتراضي؟",
    "ماذا أفعل في حالة الطوارئ؟",
    "كيف أصل إلى الملعب؟",
  ]

  if (!isOpen) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              onClick={() => setIsOpen(true)}
              className="fixed bottom-4 right-4 rounded-full h-14 w-14 bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 z-50"
            >
              <Bot className="h-6 w-6" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="left">
            <p>مساعد الملعب الذكي</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return (
    <Card
      className={`fixed ${isExpanded ? "inset-4" : "bottom-4 right-4 w-80 h-[450px]"} bg-background shadow-xl transition-all duration-200 z-50`}
    >
      <CardHeader className="p-3 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Stadium Assistant" />
              <AvatarFallback className="bg-primary text-primary-foreground">SA</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-base">مساعد الملعب</CardTitle>
              <div className="flex items-center mt-1">
                <Badge variant="outline" className="text-xs px-1 py-0 h-4 gap-1 border-green-500 text-green-500">
                  <Sparkles className="h-2.5 w-2.5" />
                  <span>ذكاء اصطناعي</span>
                </Badge>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => setIsExpanded(!isExpanded)} className="h-7 w-7">
              {isExpanded ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-7 w-7">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0 overflow-hidden">
        <ScrollArea className={`${isExpanded ? "h-[calc(100vh-12rem)]" : "h-[300px]"} p-3`}>
          {messages.map((message, index) => (
            <div key={index} className={`mb-3 ${message.role === "user" ? "flex flex-row-reverse" : "flex"}`}>
              {message.role === "assistant" && (
                <Avatar className="h-8 w-8 mt-1 mr-2">
                  <AvatarFallback className="bg-primary text-primary-foreground">SA</AvatarFallback>
                </Avatar>
              )}
              <div
                className={`max-w-[80%] rounded-lg p-2 ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground ml-2"
                    : message.isThinking
                      ? "bg-muted/50 border border-muted"
                      : "bg-muted"
                }`}
              >
                {message.isThinking ? (
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <p className="text-sm opacity-70">{message.content}</p>
                    <div className="flex space-x-1 space-x-reverse">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce [animation-delay:-0.3s]"></div>
                      <div className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce [animation-delay:-0.15s]"></div>
                      <div className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce"></div>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="text-sm whitespace-pre-line">{message.content}</p>
                    <p className="text-xs mt-1 opacity-70 text-right">{formatTime(message.timestamp)}</p>
                  </>
                )}
              </div>
              {message.role === "user" && (
                <Avatar className="h-8 w-8 mt-1 ml-2">
                  <AvatarFallback>أنت</AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
          {/* اقتراحات سريعة بعد الترحيب */}
          {messages.length === 1 && (
            <div className="mt-4 flex flex-wrap gap-2 justify-center">
              {quickSuggestions.map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => handleSendMessage(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          )}
          <div ref={messagesEndRef} />
        </ScrollArea>

        {isRecording && recognizedText && (
          <div className="px-3 py-2 bg-yellow-500/10 border-t border-yellow-500/20">
            <p className="text-xs text-yellow-500 animate-pulse">جاري الاستماع...</p>
            <p className="text-sm">{recognizedText}</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="p-3 border-t">
        <form onSubmit={handleSubmit} className="flex w-full gap-2 relative">
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              placeholder="اكتب رسالتك هنا..."
              disabled={isLoading || isRecording}
              className="pr-10"
              dir="rtl"
            />
            {isSpeaking && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={stopSpeaking}
                className="absolute left-1 top-1/2 transform -translate-y-1/2 h-7 w-7"
              >
                <VolumeX className="h-4 w-4" />
              </Button>
            )}

            {/* اقتراحات الكلمات المفتاحية */}
            {showKeywordSuggestions && input.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-md shadow-md z-10 max-h-40 overflow-y-auto">
                <div className="p-2">
                  <div className="flex items-center mb-2">
                    <Search className="h-3 w-3 mr-1 opacity-70" />
                    <span className="text-xs text-muted-foreground">كلمات مفتاحية مقترحة:</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {keywordCategories.flatMap((category) =>
                      category.keywords
                        .filter((keyword) => keyword.includes(input) || input.includes(keyword))
                        .map((keyword, idx) => (
                          <Badge
                            key={`${category.title}-${idx}`}
                            variant="outline"
                            className="cursor-pointer hover:bg-muted"
                            onClick={() => addKeywordToInput(keyword)}
                          >
                            {keyword}
                          </Badge>
                        )),
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant={isRecording ? "destructive" : "outline"}
                  size="icon"
                  onClick={toggleRecording}
                  disabled={isLoading}
                  className={isRecording ? "animate-pulse" : ""}
                >
                  {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top">
                <p>{isRecording ? "إيقاف التسجيل" : "تسجيل صوتي"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Button type="submit" disabled={isLoading || !input.trim() || isRecording}>
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
      </CardFooter>
    </Card>
  )
}
