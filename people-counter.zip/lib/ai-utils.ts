import * as tf from "@tensorflow/tfjs"

// Create a simple CNN model for crowd counting
export function createCrowdCountingModel() {
  const model = tf.sequential()

  model.add(
    tf.layers.conv2d({
      inputShape: [64, 64, 3],
      filters: 32,
      kernelSize: 3,
      activation: "relu",
    }),
  )

  model.add(tf.layers.maxPooling2d({ poolSize: [2, 2] }))

  model.add(
    tf.layers.conv2d({
      filters: 64,
      kernelSize: 3,
      activation: "relu",
    }),
  )

  model.add(tf.layers.maxPooling2d({ poolSize: [2, 2] }))

  model.add(tf.layers.flatten())

  model.add(tf.layers.dense({ units: 128, activation: "relu" }))
  model.add(tf.layers.dense({ units: 1, activation: "linear" })) // Output is a single number (crowd count)

  model.compile({
    optimizer: "adam",
    loss: "meanSquaredError",
    metrics: ["accuracy"],
  })

  return model
}

// Process image for crowd counting
export async function processImageForCrowdCounting(imageElement: HTMLImageElement) {
  return tf.tidy(() => {
    // Convert the image to a tensor
    const tensor = tf.browser
      .fromPixels(imageElement)
      .resizeNearestNeighbor([64, 64]) // Resize to model input size
      .toFloat()
      .div(tf.scalar(255)) // Normalize to [0,1]
      .expandDims(0) // Add batch dimension

    return tensor
  })
}

// Analyze crowd density from image
export async function analyzeCrowdDensity(model: tf.LayersModel, imageTensor: tf.Tensor) {
  try {
    // Make prediction
    const prediction = model.predict(imageTensor) as tf.Tensor

    // Get the predicted crowd count
    const count = await prediction.data()

    // Calculate density percentage (0-100%)
    // Assuming max crowd is 1000 people
    const density = Math.min(100, Math.max(0, (count[0] / 1000) * 100))

    // Clean up tensors
    prediction.dispose()

    return {
      count: Math.round(count[0]),
      density: Math.round(density),
    }
  } catch (error) {
    console.error("Error analyzing crowd density:", error)
    return { count: 0, density: 0 }
  }
}

// Train model with sample data (for demonstration)
export async function trainModelWithSampleData(model: tf.LayersModel) {
  // Create some random training data
  const numSamples = 50
  const inputShape = [64, 64, 3]

  // Generate random images and counts
  const xs = tf.randomNormal([numSamples, ...inputShape])
  const ys = tf.randomUniform([numSamples, 1], 0, 1000) // Random crowd counts between 0-1000

  // Train the model
  await model.fit(xs, ys, {
    epochs: 5,
    batchSize: 8,
    validationSplit: 0.2,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        console.log(`Epoch ${epoch + 1}: loss = ${logs?.loss.toFixed(4)}, accuracy = ${logs?.acc?.toFixed(4) || "N/A"}`)
      },
    },
  })

  // Clean up tensors
  xs.dispose()
  ys.dispose()

  return model
}
