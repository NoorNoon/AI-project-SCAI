"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { getResultsBySession, type CrowdAnalysisResult } from "@/lib/crowd-analysis-service"
import { useCrowdAnalysis } from "../context/crowd-analysis-context"
import { format } from "date-fns"
import { ar } from "date-fns/locale"
import { Download, RefreshCw, Calendar, Clock, Users } from "lucide-react"

const AnalysisHistoryMobile = () => {
  const { currentSession, sessions, loadSessions } = useCrowdAnalysis()

  const [selectedSessionId, setSelectedSessionId] = useState<string>("")
  const [results, setResults] = useState<CrowdAnalysisResult[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [activeTab, setActiveTab] = useState<string>("list")

  // تحميل الجلسات عند تحميل المكون
  useEffect(() => {
    if (currentSession && !selectedSessionId) {
      setSelectedSessionId(currentSession.id)
    }
  }, [currentSession])

  // تحميل النتائج عند تغيير الجلسة المحددة
  useEffect(() => {
    if (selectedSessionId) {
      loadResultsForSession(selectedSessionId)
    }
  }, [selectedSessionId])

  // تحميل نتائج الجلسة المحددة
  const loadResultsForSession = async (sessionId: string) => {
    setIsLoading(true)
    try {
      const sessionResults = await getResultsBySession(sessionId)
      setResults(sessionResults)
    } catch (error) {
      console.error("Error loading results:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // تحديث البيانات
  const handleRefresh = async () => {
    await loadSessions()
    if (selectedSessionId) {
      await loadResultsForSession(selectedSessionId)
    }
  }

  // تنزيل البيانات كملف JSON
  const handleDownloadData = () => {
    if (results.length === 0) return

    const dataStr = JSON.stringify(results, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)

    const a = document.createElement("a")
    a.href = url
    a.download = `crowd-analysis-${selectedSessionId}.json`
    document.body.appendChild(a)
    a.click()

    setTimeout(() => {
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }, 100)
  }

  // تحويل النتائج إلى تنسيق مناسب للرسوم البيانية
  const getChartData = () => {
    return results
      .map((result) => ({
        time: format(new Date(result.created_at), "HH:mm", { locale: ar }),
        count: result.people_count,
        confidence: result.confidence_threshold,
        processingTime: result.processing_time || 0,
      }))
      .reverse()
  }

  // الحصول على اسم الجلسة المحددة
  const getSelectedSessionName = () => {
    const session = sessions.find((s) => s.id === selectedSessionId)
    return session ? session.session_name : "جلسة غير معروفة"
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">سجل التحليل</h1>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleDownloadData} disabled={results.length === 0}>
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="اختر جلسة" />
          </SelectTrigger>
          <SelectContent>
            {sessions.map((session) => (
              <SelectItem key={session.id} value={session.id}>
                {session.session_name || "جلسة بدون اسم"}
                {session.location && ` - ${session.location}`}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {selectedSessionId && (
          <div className="text-sm text-muted-foreground flex justify-between">
            <span>الجلسة: {getSelectedSessionName()}</span>
            <span>عدد النتائج: {results.length}</span>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="list">قائمة</TabsTrigger>
            <TabsTrigger value="chart">رسم بياني</TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="pt-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : results.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                <Users className="h-10 w-10 mb-2 opacity-20" />
                <p>لا توجد نتائج للعرض</p>
              </div>
            ) : (
              <div className="space-y-3">
                {results.map((result) => (
                  <Card key={result.id} className="p-3 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium">{result.people_count} شخص</div>
                        <div className="text-xs text-muted-foreground flex items-center mt-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          {format(new Date(result.created_at), "yyyy-MM-dd", { locale: ar })}
                          <Clock className="h-3 w-3 mr-1 ml-2" />
                          {format(new Date(result.created_at), "HH:mm:ss", { locale: ar })}
                        </div>
                      </div>
                      <div className="flex flex-col items-end">
                        <div className="text-sm">الثقة: {result.confidence_threshold.toFixed(2)}</div>
                        {result.processing_time && (
                          <div className="text-xs text-muted-foreground">
                            {result.processing_time.toFixed(1)} مللي ثانية
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="chart" className="pt-4">
            <div className="chart-container">
              {isLoading ? (
                <div className="flex justify-center items-center h-full">
                  <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : results.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <Users className="h-10 w-10 mb-2 opacity-20" />
                  <p>لا توجد بيانات للعرض</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={getChartData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="count"
                      name="عدد الأشخاص"
                      stroke="#3b82f6"
                      activeDot={{ r: 8 }}
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default AnalysisHistoryMobile
