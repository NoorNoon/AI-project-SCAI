"use client"

import type React from "react"
import { useState } from "react"
import PeopleCounter from "./people-counter"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Download, Info } from "lucide-react"
import { CrowdAnalysisProvider } from "../context/crowd-analysis-context"
import AnalysisHistory from "../crowd-analysis/analysis-history"
import SessionManager from "../crowd-analysis/session-manager"

const PeopleCounterPage: React.FC = () => {
  const [peopleCount, setPeopleCount] = useState<number>(0)
  const [showInfo, setShowInfo] = useState<boolean>(false)

  const handleCountChange = (count: number) => {
    setPeopleCount(count)
  }

  const downloadResults = () => {
    const data = {
      timestamp: new Date().toISOString(),
      peopleCount: peopleCount,
      location: "Stadium Section A",
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = `people-count-${new Date().toISOString()}.json`
    document.body.appendChild(a)
    a.click()

    setTimeout(() => {
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }, 100)
  }

  return (
    <CrowdAnalysisProvider>
      <div className="container mx-auto p-4 space-y-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>تحليل الحشود</CardTitle>
            <Button variant="outline" size="icon" onClick={() => setShowInfo(!showInfo)}>
              <Info className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            {showInfo && (
              <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-md text-sm">
                <h3 className="font-semibold mb-2">معلومات عن النموذج</h3>
                <p>
                  يستخدم هذا النظام نموذج YOLOv8 (You Only Look Once) من Ultralytics للكشف عن الأشخاص في الصور والفيديو.
                  YOLOv8 هو نموذج شبكة عصبية عميقة متطور للكشف عن الكائنات في الوقت الفعلي.
                </p>
                <h4 className="font-semibold mt-2">مميزات النموذج:</h4>
                <ul className="list-disc list-inside">
                  <li>دقة عالية في الكشف عن الأشخاص في ظروف مختلفة</li>
                  <li>سرعة معالجة عالية تناسب التطبيقات في الوقت الفعلي</li>
                  <li>قدرة على التعرف على الأشخاص حتى في الحشود المزدحمة</li>
                  <li>إمكانية التدريب على بيانات مخصصة لتحسين الأداء</li>
                </ul>
                <h4 className="font-semibold mt-2">الخوارزميات المستخدمة:</h4>
                <ul className="list-disc list-inside">
                  <li>خوارزمية Non-Maximum Suppression (NMS) لتقليل الكشوفات المتداخلة</li>
                  <li>تتبع الأشخاص عبر إطارات الفيديو باستخدام خوارزمية تتبع مخصصة</li>
                  <li>حساب IoU (Intersection over Union) لتحديد مدى تداخل الكشوفات</li>
                </ul>
              </div>
            )}

            <Tabs defaultValue="counter">
              <TabsList className="mb-4">
                <TabsTrigger value="counter">عداد الأشخاص</TabsTrigger>
                <TabsTrigger value="history">سجل التحليل</TabsTrigger>
                <TabsTrigger value="sessions">إدارة الجلسات</TabsTrigger>
                <TabsTrigger value="stats">الإحصائيات</TabsTrigger>
              </TabsList>

              <TabsContent value="counter">
                <PeopleCounter onCountChange={handleCountChange} />
              </TabsContent>

              <TabsContent value="history">
                <AnalysisHistory />
              </TabsContent>

              <TabsContent value="sessions">
                <SessionManager />
              </TabsContent>

              <TabsContent value="stats">
                <Card>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-md">
                        <h3 className="text-lg font-semibold mb-2">عدد الأشخاص الحالي</h3>
                        <div className="text-4xl font-bold">{peopleCount}</div>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-md">
                        <h3 className="text-lg font-semibold mb-2">الكثافة</h3>
                        <div className="text-xl">
                          {peopleCount === 0 && "منخفضة جدًا"}
                          {peopleCount > 0 && peopleCount <= 5 && "منخفضة"}
                          {peopleCount > 5 && peopleCount <= 15 && "متوسطة"}
                          {peopleCount > 15 && peopleCount <= 30 && "عالية"}
                          {peopleCount > 30 && "عالية جدًا"}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 bg-gray-50 p-4 rounded-md">
                      <h3 className="text-lg font-semibold mb-2">أداء النظام</h3>
                      <div className="flex items-center justify-between mb-2">
                        <span>سرعة المعالجة:</span>
                        <span className="font-medium text-green-600">عالية</span>
                      </div>
                      <div className="flex items-center justify-between mb-2">
                        <span>دقة الكشف:</span>
                        <span className="font-medium text-blue-600">95%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>حالة النظام:</span>
                        <div className="flex items-center">
                          <div className="h-2 w-2 bg-green-500 rounded-full mr-2"></div>
                          <span>يعمل بكفاءة</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 flex justify-end">
                      <Button onClick={downloadResults}>
                        <Download className="mr-2 h-4 w-4" />
                        تنزيل النتائج
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </CrowdAnalysisProvider>
  )
}

export default PeopleCounterPage
