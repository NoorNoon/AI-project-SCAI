export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          name: string
          user_type: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          name: string
          user_type: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          user_type?: string
          created_at?: string
          updated_at?: string
        }
      }
      crowd_analysis_sessions: {
        Row: {
          id: string
          session_name: string | null
          location: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          session_name?: string | null
          location?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          session_name?: string | null
          location?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      crowd_analysis_results: {
        Row: {
          id: string
          session_id: string
          people_count: number
          confidence_threshold: number
          processing_time: number | null
          image_url: string | null
          created_at: string
        }
        Insert: {
          id?: string
          session_id: string
          people_count: number
          confidence_threshold: number
          processing_time?: number | null
          image_url?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          session_id?: string
          people_count?: number
          confidence_threshold?: number
          processing_time?: number | null
          image_url?: string | null
          created_at?: string
        }
      }
      detection_details: {
        Row: {
          id: string
          result_id: string
          detection_id: number | null
          bbox_x: number
          bbox_y: number
          bbox_width: number
          bbox_height: number
          score: number
          created_at: string
        }
        Insert: {
          id?: string
          result_id: string
          detection_id?: number | null
          bbox_x: number
          bbox_y: number
          bbox_width: number
          bbox_height: number
          score: number
          created_at?: string
        }
        Update: {
          id?: string
          result_id?: string
          detection_id?: number | null
          bbox_x?: number
          bbox_y?: number
          bbox_width?: number
          bbox_height?: number
          score?: number
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
