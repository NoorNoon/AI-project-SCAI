import type { Detection } from "./yolo-model"

// فئة لتتبع الأشخاص عبر إطارات الفيديو
export class PersonTracker {
  private tracks: Array<{
    id: number
    bbox: [number, number, number, number]
    score: number
    history: Array<[number, number, number, number]>
    lastSeen: number
    color: string
  }> = []

  private nextId = 1
  private maxHistory = 30
  private maxLastSeen = 15

  // تحديث المسارات بناءً على الكشوفات الجديدة
  update(detections: Detection[]): Detection[] {
    if (this.tracks.length === 0) {
      // إنشاء مسارات جديدة لجميع الكشوفات
      this.tracks = detections.map((detection) => ({
        id: this.nextId++,
        bbox: detection.bbox,
        score: detection.score,
        history: [detection.bbox],
        lastSeen: 0,
        color: detection.color || `hsl(${Math.random() * 360}, 100%, 50%)`,
      }))

      return this.tracks.map((track) => ({
        id: track.id,
        bbox: track.bbox,
        class: "person",
        score: track.score,
        color: track.color,
      }))
    }

    // مصفوفة تكلفة للمطابقة بين المسارات والكشوفات
    const costMatrix = this.tracks.map((track) => {
      return detections.map((detection) => {
        const iou = this.calculateIoU(track.bbox, detection.bbox)
        return 1 - iou // التكلفة هي 1 - IoU
      })
    })

    // استخدام خوارزمية المطابقة
    const assignments = this.hungarianAlgorithm(costMatrix)

    // تحديث المسارات الموجودة وإنشاء مسارات جديدة
    const updatedTracks = []
    const assignedDetections = new Set()

    for (const [trackIdx, detectionIdx] of assignments) {
      if (costMatrix[trackIdx][detectionIdx] > 0.7) {
        // التكلفة عالية جدًا، لا تطابق
        continue
      }

      const track = this.tracks[trackIdx]
      const detection = detections[detectionIdx]

      // تحديث المسار
      track.bbox = detection.bbox
      track.score = detection.score
      track.history.push(detection.bbox)

      // الاحتفاظ فقط بآخر N إطار
      if (track.history.length > this.maxHistory) {
        track.history.shift()
      }

      track.lastSeen = 0

      updatedTracks.push(track)
      assignedDetections.add(detectionIdx)
    }

    // إضافة المسارات غير المطابقة (مع زيادة عداد lastSeen)
    for (let i = 0; i < this.tracks.length; i++) {
      if (!assignments.some(([trackIdx, _]) => trackIdx === i)) {
        const track = this.tracks[i]
        track.lastSeen++

        // الاحتفاظ بالمسار إذا لم يتم رؤيته لأكثر من N إطار
        if (track.lastSeen < this.maxLastSeen) {
          updatedTracks.push(track)
        }
      }
    }

    // إنشاء مسارات جديدة للكشوفات غير المطابقة
    for (let i = 0; i < detections.length; i++) {
      if (!assignedDetections.has(i)) {
        const detection = detections[i]
        updatedTracks.push({
          id: this.nextId++,
          bbox: detection.bbox,
          score: detection.score,
          history: [detection.bbox],
          lastSeen: 0,
          color: detection.color || `hsl(${Math.random() * 360}, 100%, 50%)`,
        })
      }
    }

    this.tracks = updatedTracks

    // تحويل المسارات إلى كشوفات
    return this.tracks.map((track) => ({
      id: track.id,
      bbox: track.bbox,
      class: "person",
      score: track.score,
      color: track.color,
    }))
  }

  // حساب IoU (Intersection over Union) بين صندوقين
  private calculateIoU(boxA: [number, number, number, number], boxB: [number, number, number, number]): number {
    // تحويل [x, y, width, height] إلى [x1, y1, x2, y2]
    const boxACoords = [boxA[0], boxA[1], boxA[0] + boxA[2], boxA[1] + boxA[3]]

    const boxBCoords = [boxB[0], boxB[1], boxB[0] + boxB[2], boxB[1] + boxB[3]]

    // حساب منطقة التقاطع
    const xA = Math.max(boxACoords[0], boxBCoords[0])
    const yA = Math.max(boxACoords[1], boxBCoords[1])
    const xB = Math.min(boxACoords[2], boxBCoords[2])
    const yB = Math.min(boxACoords[3], boxBCoords[3])

    // التحقق من وجود تقاطع
    if (xB < xA || yB < yA) return 0

    const intersectionArea = (xB - xA) * (yB - yA)

    // حساب مساحة كل صندوق
    const boxAArea = (boxACoords[2] - boxACoords[0]) * (boxACoords[3] - boxACoords[1])
    const boxBArea = (boxBCoords[2] - boxBCoords[0]) * (boxBCoords[3] - boxBCoords[1])

    // حساب IoU
    return intersectionArea / (boxAArea + boxBArea - intersectionArea)
  }

  // تنفيذ مبسط لخوارزمية المطابقة
  private hungarianAlgorithm(costMatrix: number[][]): [number, number][] {
    const assignments: [number, number][] = []

    // لكل مسار، ابحث عن الكشف ذو أقل تكلفة
    for (let i = 0; i < costMatrix.length; i++) {
      let minCost = Number.POSITIVE_INFINITY
      let minIdx = -1

      for (let j = 0; j < costMatrix[i].length; j++) {
        if (costMatrix[i][j] < minCost) {
          minCost = costMatrix[i][j]
          minIdx = j
        }
      }

      if (minIdx !== -1) {
        assignments.push([i, minIdx])
      }
    }

    return assignments
  }

  // الحصول على جميع المسارات
  getTracks(): Detection[] {
    return this.tracks.map((track) => ({
      id: track.id,
      bbox: track.bbox,
      class: "person",
      score: track.score,
      color: track.color,
    }))
  }

  // تفريغ المسارات
  clear(): void {
    this.tracks = []
  }
}

// إنشاء نسخة واحدة من متتبع الأشخاص للاستخدام في جميع أنحاء التطبيق
export const personTracker = new PersonTracker()
