"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"
import { User, Lock } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()
  const [loginType, setLoginType] = useState<"fan" | "organizer">("fan")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Store user info in localStorage
      localStorage.setItem(
        "user",
        JSON.stringify({
          id: "123456",
          name: loginType === "fan" ? "محمد عبدالله" : "أحمد المشرف",
          email,
          type: loginType,
          avatar: "/placeholder.svg?height=100&width=100",
        }),
      )

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (err) {
      setError("حدث خطأ في تسجيل الدخول. يرجى المحاولة مرة أخرى.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-black p-4 text-white">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="mb-2 text-3xl font-bold text-yellow-500">نظام إدارة الملاعب الذكي</h1>
          <p className="text-gray-400">سجل دخولك للوصول إلى حسابك</p>
        </div>

        <Card className="border-gray-800 bg-gray-900">
          <CardContent className="pt-6">
            <Tabs defaultValue="fan" onValueChange={(value) => setLoginType(value as "fan" | "organizer")}>
              <TabsList className="mb-6 grid w-full grid-cols-2">
                <TabsTrigger value="fan">مشجع</TabsTrigger>
                <TabsTrigger value="organizer">منظم</TabsTrigger>
              </TabsList>

              <form onSubmit={handleLogin}>
                <div className="mb-4 space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <div className="relative">
                    <User className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                    <Input
                      id="email"
                      type="email"
                      className="border-gray-700 bg-gray-800 pr-10"
                      placeholder="أدخل بريدك الإلكتروني"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="mb-6 space-y-2">
                  <Label htmlFor="password">كلمة المرور</Label>
                  <div className="relative">
                    <Lock className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                    <Input
                      id="password"
                      type="password"
                      className="border-gray-700 bg-gray-800 pr-10"
                      placeholder="أدخل كلمة المرور"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>

                {error && (
                  <div className="mb-4 rounded bg-red-900/50 p-2 text-center text-sm text-red-300">{error}</div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-yellow-500 text-black hover:bg-yellow-600"
                  disabled={loading}
                >
                  {loading ? "جاري تسجيل الدخول..." : "تسجيل الدخول"}
                </Button>

                <div className="mt-4 text-center text-sm text-gray-400">
                  ليس لديك حساب؟{" "}
                  <Button variant="link" className="p-0 text-yellow-500" onClick={() => setError("")}>
                    إنشاء حساب جديد
                  </Button>
                </div>
              </form>
            </Tabs>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>للتجربة، يمكنك استخدام أي بريد إلكتروني وكلمة مرور</p>
        </div>
      </div>
    </div>
  )
}
