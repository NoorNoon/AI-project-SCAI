"use client"

import { Label } from "@/components/ui/label"
import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import {
  ChevronLeft,
  Users,
  Mic,
  MicOff,
  Volume2,
  Share2,
  Camera,
  Download,
  Maximize,
  Eye,
  EyeOff,
  Move,
  Trophy,
  Star,
  Calendar,
  ArrowLeft,
  ArrowRight,
  Gamepad2,
  PlayIcon as Clap,
  ThumbsUp,
  Medal,
  Crown,
  Share,
  Sparkles,
} from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Toggle } from "@/components/ui/toggle"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import StadiumChatbot from "@/components/stadium-assistant/stadium-chatbot"

export default function VirtualAttendancePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [tickets, setTickets] = useState<any[]>([])
  const [selectedTicket, setSelectedTicket] = useState<any>(null)
  const [viewMode, setViewMode] = useState<"2d" | "3d" | "vr">("3d")
  const [zoomLevel, setZoomLevel] = useState(1)
  const [isRecording, setIsRecording] = useState(false)
  const [transcribedText, setTranscribedText] = useState("")
  const [showChantSuggestion, setShowChantSuggestion] = useState(false)
  const [suggestedChant, setSuggestedChant] = useState("")
  const [chatMessages, setChatMessages] = useState<Array<{ user: string; message: string; time: string }>>([])
  const [newMessage, setNewMessage] = useState("")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [crowdNoise, setCrowdNoise] = useState(70)
  const [showControls, setShowControls] = useState(true)
  const [attendees, setAttendees] = useState<Array<{ id: string; name: string; section: string; seat: string }>>([])
  const [vrPosition, setVrPosition] = useState({ x: 0.5, y: 0.5, rotation: 0 })
  const [isFirstPerson, setIsFirstPerson] = useState(false)
  const [showVRControls, setShowVRControls] = useState(false)
  const [vrMovementSpeed, setVrMovementSpeed] = useState(5)
  const [vrRotationSpeed, setVrRotationSpeed] = useState(2)
  const [isMovingForward, setIsMovingForward] = useState(false)
  const [isMovingBackward, setIsMovingBackward] = useState(false)
  const [isMovingLeft, setIsMovingLeft] = useState(false)
  const [isMovingRight, setIsMovingRight] = useState(false)
  const [isRotatingLeft, setIsRotatingLeft] = useState(false)
  const [isRotatingRight, setIsRotatingRight] = useState(false)

  // نظام المسارات الافتراضية
  const [showVirtualPath, setShowVirtualPath] = useState(true)
  const [pathDestination, setPathDestination] = useState<string>("مقعدك")
  const [pathInstructions, setPathInstructions] = useState<string[]>([])
  const [currentPathStep, setCurrentPathStep] = useState(0)

  // تحديات المشاركة الاجتماعية
  const [userPoints, setUserPoints] = useState(75)
  const [userLevel, setUserLevel] = useState("مشجع فضي")
  const [completedChallenges, setCompletedChallenges] = useState<string[]>([])
  const [activeChallenges, setActiveChallenges] = useState<
    Array<{
      id: string
      title: string
      description: string
      points: number
      type: string
      completed: boolean
      reward?: string
      hashtag?: string
      participants?: number
      deadline?: string
      options?: Array<{ id: string; text: string; votes: number }>
      playerPredictions?: Array<{ id: string; text: string; votes: number }>
      topChants?: Array<{ text: string; rating: number; author: string }>
    }>
  >([])

  // الألعاب التفاعلية
  const [showClapGame, setShowClapGame] = useState(false)
  const [clapPattern, setClapPattern] = useState<number[]>([])
  const [userClaps, setUserClaps] = useState<number[]>([])
  const [clapScore, setClapScore] = useState(0)
  const [showVoting, setShowVoting] = useState(false)
  const [votingOptions, setVotingOptions] = useState<
    Array<{
      id: string
      title: string
      votes: number
      voted: boolean
      stats?: { goals: number; assists: number; rating: number }
    }>
  >([])
  const [clapPatternLibrary, setClapPatternLibrary] = useState<number[][]>([])
  const [clapDifficulty, setClapDifficulty] = useState<"سهل" | "متوسط" | "متقدم">("سهل")
  const [clapCompetitionMode, setClapCompetitionMode] = useState<"فردي" | "جماعي" | "تنافسي">("فردي")
  const [clapOpponent, setClapOpponent] = useState<{ name: string; score: number } | null>(null)
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [selectedPrediction, setSelectedPrediction] = useState<string | null>(null)
  const [selectedPlayerPrediction, setSelectedPlayerPrediction] = useState<string | null>(null)
  const [aiChantAnalysis, setAiChantAnalysis] = useState<{
    sentiment: "إيجابي" | "محايد" | "سلبي"
    score: number
    suggestions: string[]
    keywords: string[]
  } | null>(null)

  // التحدي اليومي
  const [dailyQuests, setDailyQuests] = useState<
    Array<{
      id: string
      title: string
      description: string
      difficulty: "سهل" | "متوسط" | "صعب"
      points: number
      completed: boolean
    }>
  >([])

  // نظام المستويات
  const [nextLevelPoints, setNextLevelPoints] = useState(300)
  const [levelProgress, setLevelProgress] = useState(0)

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const audioRef = useRef<HTMLAudioElement>(null)
  const animationFrameRef = useRef<number>(0)

  // Chant suggestions
  const chantSuggestions = {
    "الحكم ظالم": "نحترم قرارات الحكم ونركز على اللعب",
    "فريق ضعيف": "فريق يحتاج للدعم والتشجيع",
    "خسارة مستحقة": "فرصة للتعلم والتحسن في المباريات القادمة",
    "لاعب سيء": "لاعب يحتاج للدعم والتشجيع من الجماهير",
  }

  // Positive chants
  const positiveChants = ["يا هلال", "فوز فوز", "الله الله يا نصر", "فريقنا فريقنا", "نحن معك يا بطل", "لا يهزنا أحد"]

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))

    // Get tickets from localStorage
    const ticketsData = localStorage.getItem("tickets")
    if (ticketsData) {
      const allTickets = JSON.parse(ticketsData)
      // Filter only virtual tickets
      const virtualTickets = allTickets.filter((ticket: any) => ticket.isVirtual)
      setTickets(virtualTickets)

      if (virtualTickets.length > 0) {
        setSelectedTicket(virtualTickets[0])
      }
    }

    setLoading(false)

    // Generate random attendees
    const randomAttendees = Array.from({ length: 50 }, (_, i) => ({
      id: `user-${i}`,
      name: `مشجع ${i + 1}`,
      section: ["A", "B", "C", "D", "VIP"][Math.floor(Math.random() * 5)],
      seat: `${Math.floor(Math.random() * 20) + 1}-${Math.floor(Math.random() * 30) + 1}`,
    }))
    setAttendees(randomAttendees)

    // Generate initial chat messages
    const initialMessages = [
      { user: "النظام", message: "مرحباً بك في الحضور الافتراضي!", time: "الآن" },
      { user: "مشجع 5", message: "أهلاً بالجميع!", time: "قبل 2 دقيقة" },
      { user: "مشجع 12", message: "المباراة ستبدأ قريباً", time: "قبل 5 دقائق" },
    ]
    setChatMessages(initialMessages)

    // Simulate crowd noise
    if (audioRef.current) {
      audioRef.current.volume = crowdNoise / 100
      audioRef.current.play().catch((e) => console.log("Audio play prevented:", e))
    }

    // Simulate chat messages
    const chatInterval = setInterval(() => {
      const randomUser = `مشجع ${Math.floor(Math.random() * 50) + 1}`
      const randomMessages = [
        "يا هلال!",
        "هدف!",
        "ما هذا الحكم!",
        "رائع!",
        "تسديدة قوية!",
        "دفاع ممتاز!",
        "كاد أن يسجل!",
        "فرصة ضائعة!",
      ]
      const randomMessage = randomMessages[Math.floor(Math.random() * randomMessages.length)]

      setChatMessages((prev) =>
        [
          ...prev,
          {
            user: randomUser,
            message: randomMessage,
            time: "الآن",
          },
        ].slice(-20),
      ) // Keep only last 20 messages
    }, 10000)

    // Set up keyboard controls for VR mode
    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    // إعداد المسارات الافتراضية
    initializeVirtualPaths()

    // إعداد التحديات
    initializeChallenges()

    // إعداد التحديات اليومية
    initializeDailyQuests()

    // حساب تقدم المستوى
    calculateLevelProgress()

    return () => {
      clearInterval(chatInterval)
      if (audioRef.current) {
        audioRef.current.pause()
      }
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      cancelAnimationFrame(animationFrameRef.current)
    }
  }, [router])

  // حساب تقدم المستوى
  const calculateLevelProgress = () => {
    let nextLevel = 300
    let currentLevel = "مشجع فضي"

    if (userPoints < 100) {
      nextLevel = 100
      currentLevel = "مبتدئ"
      setLevelProgress(userPoints)
    } else if (userPoints < 300) {
      nextLevel = 300
      currentLevel = "مشجع فضي"
      setLevelProgress(((userPoints - 100) / 200) * 100)
    } else if (userPoints < 1000) {
      nextLevel = 1000
      currentLevel = "مشجع ذهبي"
      setLevelProgress(((userPoints - 300) / 700) * 100)
    } else {
      nextLevel = 1000
      currentLevel = "سفير الفريق"
      setLevelProgress(100)
    }

    setNextLevelPoints(nextLevel)
    setUserLevel(currentLevel)
  }

  // إعداد المسارات الافتراضية
  const initializeVirtualPaths = () => {
    // إنشاء تعليمات المسار الافتراضي
    const instructions = [
      "اتجه شمالاً 20 متراً للوصول إلى المدخل الرئيسي",
      "انعطف يميناً واصعد السلم إلى الطابق الثاني",
      "اتجه شرقاً 15 متراً حتى تصل إلى القسم C",
      "ابحث عن الصف 5 واتجه إلى المقعد رقم 23",
    ]

    setPathInstructions(instructions)
  }

  // إعداد التحديات
  const initializeChallenges = () => {
    const challenges = [
      {
        id: "challenge-1",
        title: "تحدي القميص",
        description: "ارفع صورة مع منتجات الفريق",
        points: 15,
        type: "social",
        completed: false,
        reward: "ظهور في قاعة المشجعين",
        hashtag: "#هلالي_في_العمل",
        participants: 342,
        deadline: "قبل المباراة القادمة",
      },
      {
        id: "challenge-2",
        title: "توقع النتيجة",
        description: "اختر النتيجة المتوقعة للمباراة",
        points: 20,
        type: "prediction",
        completed: false,
        reward: "نقاط مضاعفة عند التوقع الصحيح",
        hashtag: "#توقعات_المباراة",
        participants: 1205,
        options: [
          { id: "p1", text: "فوز الهلال 2-0", votes: 450 },
          { id: "p2", text: "فوز الهلال 3-1", votes: 320 },
          { id: "p3", text: "تعادل 1-1", votes: 280 },
          { id: "p4", text: "فوز النصر 1-0", votes: 155 },
        ],
        playerPredictions: [
          { id: "pp1", text: "سيسجل رونالدو أول هدف", votes: 620 },
          { id: "pp2", text: "سيحصل بنزيما على بطاقة صفراء", votes: 340 },
          { id: "pp3", text: "سيكون هناك ركلة جزاء", votes: 480 },
        ],
      },
      {
        id: "challenge-3",
        title: "تحدي الهتاف",
        description: "سجل هتافاً جديداً للفريق",
        points: 25,
        type: "chant",
        completed: false,
        reward: "فوز بأفضل هتاف يذاع في الملعب",
        hashtag: "#هتاف_الجمهور",
        participants: 178,
        topChants: [
          { text: "يا هلال يا زعيم", rating: 4.8, author: "مشجع 23" },
          { text: "النصر فخر الوطن", rating: 4.7, author: "مشجع 105" },
        ],
      },
    ]

    setActiveChallenges(challenges)

    // إعداد خيارات التصويت
    const votingOpts = [
      {
        id: "player-1",
        title: "كريستيانو رونالدو",
        votes: 245,
        voted: false,
        stats: { goals: 2, assists: 1, rating: 8.5 },
      },
      {
        id: "player-2",
        title: "كريم بنزيما",
        votes: 189,
        voted: false,
        stats: { goals: 1, assists: 2, rating: 8.2 },
      },
      {
        id: "player-3",
        title: "سالم الدوسري",
        votes: 156,
        voted: false,
        stats: { goals: 0, assists: 1, rating: 7.8 },
      },
    ]

    setVotingOptions(votingOpts)

    // إعداد لعبة التصفيق بأنماط متنوعة
    const clapPatterns = [
      [1, 2, 1, 3, 1], // نمط بسيط
      [2, 2, 1, 1, 3], // نمط متوسط
      [3, 1, 2, 3, 2, 1], // نمط متقدم
    ]

    setClapPatternLibrary(clapPatterns)
    setClapDifficulty("متوسط")
  }

  // إعداد التحديات اليومية
  const initializeDailyQuests = () => {
    const quests = [
      {
        id: "quest-1",
        title: "شاهد هايلايت هدف الأمس",
        description: "شاهد أفضل لحظات المباراة السابقة",
        difficulty: "سهل" as const,
        points: 5,
        completed: false,
      },
      {
        id: "quest-2",
        title: "أجب عن سؤال تاريخي",
        description: "من كان قائد النصر عام 2015؟",
        difficulty: "متوسط" as const,
        points: 10,
        completed: false,
      },
      {
        id: "quest-3",
        title: "انشر فيديو وأنت تكرر حركة مشهورة للفريق",
        description: "قم بتقليد احتفال أحد اللاعبين المشهورين",
        difficulty: "صعب" as const,
        points: 20,
        completed: false,
      },
    ]

    setDailyQuests(quests)
  }

  // Separate useEffect for canvas drawing
  useEffect(() => {
    if (canvasRef.current && selectedTicket) {
      if (viewMode === "vr") {
        startVRAnimation()
      } else {
        cancelAnimationFrame(animationFrameRef.current)
        drawStadium()
      }
    }

    return () => {
      cancelAnimationFrame(animationFrameRef.current)
    }
  }, [viewMode, zoomLevel, selectedTicket, isFirstPerson, showVirtualPath])

  // Separate useEffect for VR movement
  useEffect(() => {
    if (viewMode === "vr") {
      const updateVRPosition = () => {
        let newX = vrPosition.x
        let newY = vrPosition.y
        let newRotation = vrPosition.rotation

        const moveStep = 0.01 * vrMovementSpeed
        const rotateStep = 0.05 * vrRotationSpeed

        if (isMovingForward) {
          newX += Math.sin(vrPosition.rotation) * moveStep
          newY -= Math.cos(vrPosition.rotation) * moveStep
        }
        if (isMovingBackward) {
          newX -= Math.sin(vrPosition.rotation) * moveStep
          newY += Math.cos(vrPosition.rotation) * moveStep
        }
        if (isMovingLeft) {
          newX -= Math.cos(vrPosition.rotation) * moveStep
          newY -= Math.sin(vrPosition.rotation) * moveStep
        }
        if (isMovingRight) {
          newX += Math.cos(vrPosition.rotation) * moveStep
          newY += Math.sin(vrPosition.rotation) * moveStep
        }
        if (isRotatingLeft) {
          newRotation -= rotateStep
        }
        if (isRotatingRight) {
          newRotation += rotateStep
        }

        // Keep position within bounds
        newX = Math.max(0, Math.min(1, newX))
        newY = Math.max(0, Math.min(1, newY))

        if (newX !== vrPosition.x || newY !== vrPosition.y || newRotation !== vrPosition.rotation) {
          setVrPosition({ x: newX, y: newY, rotation: newRotation })
        }
      }

      const interval = setInterval(updateVRPosition, 50)
      return () => clearInterval(interval)
    }
  }, [
    viewMode,
    vrPosition,
    isMovingForward,
    isMovingBackward,
    isMovingLeft,
    isMovingRight,
    isRotatingLeft,
    isRotatingRight,
    vrMovementSpeed,
    vrRotationSpeed,
  ])

  // Separate useEffect for audio volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = crowdNoise / 100
    }
  }, [crowdNoise])

  const handleKeyDown = (e: KeyboardEvent) => {
    if (viewMode !== "vr") return

    switch (e.key) {
      case "w":
      case "ArrowUp":
        setIsMovingForward(true)
        break
      case "s":
      case "ArrowDown":
        setIsMovingBackward(true)
        break
      case "a":
      case "ArrowLeft":
        setIsRotatingLeft(true)
        break
      case "d":
      case "ArrowRight":
        setIsRotatingRight(true)
        break
      case "q":
        setIsMovingLeft(true)
        break
      case "e":
        setIsMovingRight(true)
        break
      case "v":
        setIsFirstPerson(!isFirstPerson)
        break
    }
  }

  const handleKeyUp = (e: KeyboardEvent) => {
    if (viewMode !== "vr") return

    switch (e.key) {
      case "w":
      case "ArrowUp":
        setIsMovingForward(false)
        break
      case "s":
      case "ArrowDown":
        setIsMovingBackward(false)
        break
      case "a":
      case "ArrowLeft":
        setIsRotatingLeft(false)
        break
      case "d":
      case "ArrowRight":
        setIsRotatingRight(false)
        break
      case "q":
        setIsMovingLeft(false)
        break
      case "e":
        setIsMovingRight(false)
        break
    }
  }

  const startVRAnimation = () => {
    if (!canvasRef.current) return

    const animate = () => {
      drawVRStadium()
      animationFrameRef.current = requestAnimationFrame(animate)
    }

    cancelAnimationFrame(animationFrameRef.current)
    animationFrameRef.current = requestAnimationFrame(animate)
  }

  const drawStadium = () => {
    if (!canvasRef.current || !selectedTicket) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set scale based on zoom level
    ctx.save()
    ctx.scale(zoomLevel, zoomLevel)

    if (viewMode === "2d") {
      // Draw 2D stadium
      draw2DStadium(ctx, canvas.width / zoomLevel, canvas.height / zoomLevel)
    } else if (viewMode === "3d") {
      // Draw 3D stadium
      draw3DStadium(ctx, canvas.width / zoomLevel, canvas.height / zoomLevel)
    }

    ctx.restore()
  }

  const drawVRStadium = () => {
    if (!canvasRef.current || !selectedTicket) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    const width = canvas.width
    const height = canvas.height

    if (isFirstPerson) {
      drawFirstPersonView(ctx, width, height)
    } else {
      drawThirdPersonView(ctx, width, height)
    }

    // رسم المسار الافتراضي إذا كان مفعلاً
    if (showVirtualPath) {
      drawVirtualPath(ctx, width, height)
    }
  }

  // رسم المسار الافتراضي
  const drawVirtualPath = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    if (isFirstPerson) {
      // رسم المسار في منظور الشخص الأول
      ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
      ctx.font = "bold 16px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"

      // رسم الخطوة الحالية
      ctx.fillText(pathInstructions[currentPathStep], width / 2, height - 50)

      // رسم سهم الاتجاه
      const arrowSize = 30
      ctx.fillStyle = "#FFEB3B"

      // تحديد اتجاه السهم بناءً على التعليمات
      if (pathInstructions[currentPathStep].includes("شمالاً")) {
        // سهم للأعلى
        ctx.beginPath()
        ctx.moveTo(width / 2, height - 100)
        ctx.lineTo(width / 2 - arrowSize / 2, height - 100 + arrowSize)
        ctx.lineTo(width / 2 + arrowSize / 2, height - 100 + arrowSize)
        ctx.closePath()
        ctx.fill()
      } else if (pathInstructions[currentPathStep].includes("يميناً")) {
        // سهم لليمين
        ctx.beginPath()
        ctx.moveTo(width / 2 + arrowSize, height - 100)
        ctx.lineTo(width / 2, height - 100 - arrowSize / 2)
        ctx.lineTo(width / 2, height - 100 + arrowSize / 2)
        ctx.closePath()
        ctx.fill()
      } else if (pathInstructions[currentPathStep].includes("شرقاً")) {
        // سهم لليمين
        ctx.beginPath()
        ctx.moveTo(width / 2 + arrowSize, height - 100)
        ctx.lineTo(width / 2, height - 100 - arrowSize / 2)
        ctx.lineTo(width / 2, height - 100 + arrowSize / 2)
        ctx.closePath()
        ctx.fill()
      }

      // رسم مؤشر المسافة
      ctx.fillStyle = "#4CAF50"
      ctx.fillRect(width / 2 - 50, height - 30, 100, 10)

      // رسم مؤشر التقدم
      const progress = (currentPathStep / (pathInstructions.length - 1)) * 100
      ctx.fillStyle = "#FFEB3B"
      ctx.fillRect(width / 2 - 50, height - 30, progress, 10)
    } else {
      // رسم المسار في المنظور الخارجي

      // تحديد نقاط المسار
      const pathPoints = [
        { x: 0.2, y: 0.2 }, // نقطة البداية
        { x: 0.2, y: 0.5 }, // نقطة وسيطة 1
        { x: 0.5, y: 0.5 }, // نقطة وسيطة 2
        { x: 0.5, y: 0.8 }, // نقطة النهاية (المقعد)
      ]

      // رسم خط المسار
      ctx.strokeStyle = "#FFEB3B"
      ctx.lineWidth = 3
      ctx.setLineDash([5, 5])
      ctx.beginPath()
      ctx.moveTo(width * pathPoints[0].x, height * pathPoints[0].y)

      for (let i = 1; i < pathPoints.length; i++) {
        ctx.lineTo(width * pathPoints[i].x, height * pathPoints[i].y)
      }

      ctx.stroke()
      ctx.setLineDash([])

      // رسم نقاط المسار
      for (let i = 0; i < pathPoints.length; i++) {
        // تحديد لون النقطة بناءً على الخطوة الحالية
        if (i < currentPathStep) {
          ctx.fillStyle = "#4CAF50" // نقاط مكتملة
        } else if (i === currentPathStep) {
          ctx.fillStyle = "#FFEB3B" // النقطة الحالية
        } else {
          ctx.fillStyle = "#90A4AE" // نقاط مستقبلية
        }

        // رسم النقطة
        ctx.beginPath()
        ctx.arc(width * pathPoints[i].x, height * pathPoints[i].y, 8, 0, Math.PI * 2)
        ctx.fill()

        // رسم رقم الخطوة
        ctx.fillStyle = "#000"
        ctx.font = "bold 10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText((i + 1).toString(), width * pathPoints[i].x, height * pathPoints[i].y)
      }

      // رسم تعليمات المسار
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(10, 10, 250, 40)

      ctx.fillStyle = "#FFF"
      ctx.font = "14px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(`الخطوة ${currentPathStep + 1}: ${pathInstructions[currentPathStep]}`, 20, 30)
    }
  }

  const drawFirstPersonView = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw sky
    const skyGradient = ctx.createLinearGradient(0, 0, 0, height * 0.5)
    skyGradient.addColorStop(0, "#1a237e")
    skyGradient.addColorStop(1, "#3949ab")
    ctx.fillStyle = skyGradient
    ctx.fillRect(0, 0, width, height * 0.5)

    // Draw field from first person perspective
    const fieldWidth = width
    const fieldHeight = height * 0.5
    const fieldY = height * 0.5

    // Calculate perspective based on rotation
    const perspectiveShift = Math.sin(vrPosition.rotation) * 100

    // Draw field
    ctx.fillStyle = "#4CAF50"
    ctx.beginPath()
    ctx.moveTo(0, fieldY)
    ctx.lineTo(width, fieldY)
    ctx.lineTo(width, height)
    ctx.lineTo(0, height)
    ctx.closePath()
    ctx.fill()

    // Draw field lines with perspective
    const lineSpacing = 20
    const numLines = Math.floor(fieldHeight / lineSpacing)

    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)"
    ctx.lineWidth = 1

    // Draw horizontal lines with perspective
    for (let i = 0; i <= numLines; i++) {
      const y = fieldY + (i / numLines) * fieldHeight
      const perspectiveWidthStart = (i / numLines) * 0.5 * width
      const perspectiveWidthEnd = width - perspectiveWidthStart

      ctx.beginPath()
      ctx.moveTo(perspectiveWidthStart + perspectiveShift, y)
      ctx.lineTo(perspectiveWidthEnd + perspectiveShift, y)
      ctx.stroke()
    }

    // Draw vertical lines with perspective
    const numVertLines = 10
    for (let i = 0; i <= numVertLines; i++) {
      const x = (i / numVertLines) * width
      const adjustedX = x + perspectiveShift * (i / numVertLines)

      ctx.beginPath()
      ctx.moveTo(adjustedX, fieldY)
      ctx.lineTo(width / 2 + perspectiveShift + (adjustedX - width / 2) * 0.5, height)
      ctx.stroke()
    }

    // Draw center circle
    const circleX = width / 2 + perspectiveShift
    const circleY = fieldY + fieldHeight * 0.3
    const radiusX = width * 0.1
    const radiusY = fieldHeight * 0.1

    ctx.strokeStyle = "white"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.ellipse(circleX, circleY, radiusX, radiusY, 0, 0, Math.PI * 2)
    ctx.stroke()

    // Draw goals
    const goalWidth = width * 0.1
    const goalHeight = fieldHeight * 0.1
    const leftGoalX = width * 0.2 + perspectiveShift
    const rightGoalX = width * 0.8 + perspectiveShift
    const goalY = fieldY + fieldHeight * 0.2

    // Left goal
    ctx.strokeStyle = "white"
    ctx.lineWidth = 3
    ctx.strokeRect(leftGoalX - goalWidth / 2, goalY, goalWidth, goalHeight)

    // Right goal
    ctx.strokeRect(rightGoalX - goalWidth / 2, goalY, goalWidth, goalHeight)

    // Draw players
    drawVRPlayers(ctx, width, height, fieldY, perspectiveShift)

    // Draw crowd in stands
    drawVRCrowd(ctx, width, height)

    // Draw UI elements
    if (showVRControls) {
      drawVRControls(ctx, width, height)
    }
  }

  const drawThirdPersonView = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw stadium from third person view (top-down with 3D elements)

    // Draw field
    ctx.fillStyle = "#4CAF50"
    ctx.fillRect(width * 0.1, height * 0.2, width * 0.8, height * 0.6)

    // Draw field lines
    ctx.strokeStyle = "white"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.1, height * 0.2, width * 0.8, height * 0.6)

    // Draw center circle
    ctx.beginPath()
    ctx.arc(width * 0.5, height * 0.5, width * 0.1, 0, Math.PI * 2)
    ctx.stroke()

    // Draw center line
    ctx.beginPath()
    ctx.moveTo(width * 0.5, height * 0.2)
    ctx.lineTo(width * 0.5, height * 0.8)
    ctx.stroke()

    // Draw penalty areas
    ctx.strokeRect(width * 0.1, height * 0.35, width * 0.15, height * 0.3)
    ctx.strokeRect(width * 0.75, height * 0.35, width * 0.15, height * 0.3)

    // Draw goals
    ctx.fillStyle = "#FFFFFF"
    ctx.fillRect(width * 0.08, height * 0.45, width * 0.02, height * 0.1)
    ctx.fillRect(width * 0.9, height * 0.45, width * 0.02, height * 0.1)

    // Draw stands
    drawStands(ctx, width, height)

    // Draw players
    drawPlayers(ctx, width, height)

    // Draw user position
    const userX = width * vrPosition.x
    const userY = height * vrPosition.y

    // Draw direction indicator
    const dirX = userX + Math.sin(vrPosition.rotation) * 20
    const dirY = userY - Math.cos(vrPosition.rotation) * 20

    ctx.strokeStyle = "#FFFF00"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(userX, userY)
    ctx.lineTo(dirX, dirY)
    ctx.stroke()

    // Draw user position
    ctx.fillStyle = "#FFFF00"
    ctx.beginPath()
    ctx.arc(userX, userY, 10, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = "#000"
    ctx.font = "bold 10px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("أنت", userX, userY)

    // Draw UI elements
    if (showVRControls) {
      drawVRControls(ctx, width, height)
    }
  }

  const drawVRPlayers = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    fieldY: number,
    perspectiveShift: number,
  ) => {
    // Team 1 (red)
    const team1Color = "#FF0000"
    const team2Color = "#0000FF"

    // Calculate player positions based on field perspective
    const playerPositions = [
      // Team 1 (left side) - positions are [x, y, team]
      [0.2, 0.3, 1], // Goalkeeper
      [0.3, 0.2, 1],
      [0.3, 0.4, 1],
      [0.3, 0.6, 1],
      [0.3, 0.8, 1],
      [0.4, 0.3, 1],
      [0.4, 0.5, 1],
      [0.4, 0.7, 1],
      [0.5, 0.4, 1],
      [0.5, 0.6, 1],

      // Team 2 (right side)
      [0.8, 0.5, 2], // Goalkeeper
      [0.7, 0.2, 2],
      [0.7, 0.4, 2],
      [0.7, 0.6, 2],
      [0.7, 0.8, 2],
      [0.6, 0.3, 2],
      [0.6, 0.5, 2],
      [0.6, 0.7, 2],
      [0.5, 0.3, 2],
      [0.5, 0.7, 2],
    ]

    // Draw players with perspective
    playerPositions.forEach(([xPos, yPos, team]) => {
      // Apply perspective transformation
      const perspectiveX = width * xPos + perspectiveShift * (xPos as number)
      const fieldDepth = height - fieldY
      const perspectiveY = fieldY + fieldDepth * (yPos as number)

      // Calculate player size based on y position (further = smaller)
      const playerSize = 10 + (yPos as number) * 10

      // Draw player
      ctx.fillStyle = team === 1 ? team1Color : team2Color
      ctx.beginPath()
      ctx.arc(perspectiveX, perspectiveY, playerSize / 2, 0, Math.PI * 2)
      ctx.fill()

      // Draw player shadow
      ctx.fillStyle = "rgba(0, 0, 0, 0.3)"
      ctx.beginPath()
      ctx.ellipse(perspectiveX, perspectiveY + playerSize / 2, playerSize / 2, playerSize / 6, 0, 0, Math.PI * 2)
      ctx.fill()
    })

    // Draw ball
    const ballX = width * 0.52 + perspectiveShift
    const ballY = fieldY + (height - fieldY) * 0.48
    const ballSize = 8

    ctx.fillStyle = "#FFFFFF"
    ctx.beginPath()
    ctx.arc(ballX, ballY, ballSize, 0, Math.PI * 2)
    ctx.fill()

    // Draw ball shadow
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)"
    ctx.beginPath()
    ctx.ellipse(ballX, ballY + ballSize, ballSize, ballSize / 3, 0, 0, Math.PI * 2)
    ctx.fill()
  }

  const drawVRCrowd = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw crowd in the stands (top part of the screen)
    const crowdHeight = height * 0.2

    // Left stand
    ctx.fillStyle = "#FF5722"
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.lineTo(width * 0.4, 0)
    ctx.lineTo(width * 0.4, crowdHeight)
    ctx.lineTo(0, crowdHeight)
    ctx.closePath()
    ctx.fill()

    // Right stand
    ctx.fillStyle = "#2196F3"
    ctx.beginPath()
    ctx.moveTo(width * 0.6, 0)
    ctx.lineTo(width, 0)
    ctx.lineTo(width, crowdHeight)
    ctx.lineTo(width * 0.6, crowdHeight)
    ctx.closePath()
    ctx.fill()

    // Draw crowd dots
    ctx.fillStyle = "rgba(255, 255, 255, 0.7)"

    // Left stand crowd
    for (let i = 0; i < 200; i++) {
      const x = Math.random() * width * 0.4
      const y = Math.random() * crowdHeight
      const size = Math.random() * 3 + 1

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Right stand crowd
    for (let i = 0; i < 200; i++) {
      const x = width * 0.6 + Math.random() * width * 0.4
      const y = Math.random() * crowdHeight
      const size = Math.random() * 3 + 1

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Draw some animated crowd movement
    const time = Date.now() / 1000
    const waveFrequency = 0.2
    const waveAmplitude = 5

    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"

    for (let i = 0; i < width; i += 10) {
      const waveY = Math.sin(time + i * waveFrequency) * waveAmplitude

      if (i < width * 0.4 || i > width * 0.6) {
        ctx.beginPath()
        ctx.arc(i, crowdHeight / 2 + waveY, 3, 0, Math.PI * 2)
        ctx.fill()
      }
    }
  }

  const drawVRControls = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw semi-transparent overlay with controls
    ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
    ctx.fillRect(width * 0.1, height * 0.85, width * 0.8, height * 0.1)

    ctx.fillStyle = "#FFFFFF"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"

    // Draw control instructions
    const instructions = isFirstPerson
      ? "استخدم W,A,S,D للتحرك | اضغط V للتبديل إلى المنظور الخارجي"
      : "استخدم W,A,S,D للتحرك | اضغط V للتبديل إلى منظور الشخص الأول"

    ctx.fillText(instructions, width / 2, height * 0.9)
  }

  const drawStands = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw stands around the field

    // Top stand
    ctx.fillStyle = "#FF5722"
    ctx.fillRect(width * 0.1, height * 0.1, width * 0.8, height * 0.1)

    // Bottom stand
    ctx.fillStyle = "#9C27B0"
    ctx.fillRect(width * 0.1, height * 0.8, width * 0.8, height * 0.1)

    // Left stand
    ctx.fillStyle = "#FFEB3B"
    ctx.fillRect(width * 0.0, height * 0.2, width * 0.1, height * 0.6)

    // Right stand
    ctx.fillStyle = "#2196F3"
    ctx.fillRect(width * 0.9, height * 0.2, width * 0.1, height * 0.6)

    // Draw crowd dots in stands
    ctx.fillStyle = "rgba(255, 255, 255, 0.7)"

    // Top stand crowd
    for (let i = 0; i < 100; i++) {
      const x = width * 0.1 + Math.random() * width * 0.8
      const y = height * 0.1 + Math.random() * height * 0.1
      const size = Math.random() * 2 + 1

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Bottom stand crowd
    for (let i = 0; i < 100; i++) {
      const x = width * 0.1 + Math.random() * width * 0.8
      const y = height * 0.8 + Math.random() * height * 0.1
      const size = Math.random() * 2 + 1

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Left stand crowd
    for (let i = 0; i < 50; i++) {
      const x = Math.random() * width * 0.1
      const y = height * 0.2 + Math.random() * height * 0.6
      const size = Math.random() * 2 + 1

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Right stand crowd
    for (let i = 0; i < 50; i++) {
      const x = width * 0.9 + Math.random() * width * 0.1
      const y = height * 0.2 + Math.random() * height * 0.6
      const size = Math.random() * 2 + 1

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  const draw2DStadium = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw field
    ctx.fillStyle = "#4CAF50"
    ctx.fillRect(width * 0.25, height * 0.3, width * 0.5, height * 0.4)

    // Draw field lines
    ctx.strokeStyle = "white"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.25, height * 0.3, width * 0.5, height * 0.4)

    // Draw center circle
    ctx.beginPath()
    ctx.arc(width * 0.5, height * 0.5, 40, 0, Math.PI * 2)
    ctx.stroke()

    // Draw center line
    ctx.beginPath()
    ctx.moveTo(width * 0.5, height * 0.3)
    ctx.lineTo(width * 0.5, height * 0.7)
    ctx.stroke()

    // Draw sections
    const sectionColors = {
      A: "#FF5722",
      B: "#2196F3",
      C: "#9C27B0",
      D: "#FFEB3B",
      VIP: "#E91E63",
    }

    // Section A (Top)
    drawSection(ctx, width * 0.25, height * 0.1, width * 0.5, height * 0.15, "A", sectionColors.A)

    // Section B (Right)
    drawSection(ctx, width * 0.8, height * 0.3, width * 0.15, height * 0.4, "B", sectionColors.B)

    // Section C (Bottom)
    drawSection(ctx, width * 0.25, height * 0.75, width * 0.5, height * 0.15, "C", sectionColors.C)

    // Section D (Left)
    drawSection(ctx, width * 0.05, height * 0.3, width * 0.15, height * 0.4, "D", sectionColors.D)

    // VIP Section (Top-Right corner)
    drawSection(ctx, width * 0.8, height * 0.1, width * 0.15, height * 0.15, "VIP", sectionColors.VIP)

    // Highlight user's section
    if (selectedTicket) {
      highlightSection(ctx, selectedTicket.section, width, height)
    }

    // Draw players
    drawPlayers(ctx, width, height)

    // رسم المسار الافتراضي إذا كان مفعلاً
    if (showVirtualPath) {
      // رسم المسار في العرض ثنائي الأبعاد
      ctx.strokeStyle = "#FFEB3B"
      ctx.lineWidth = 3
      ctx.setLineDash([5, 5])

      // رسم مسار من المدخل إلى المقعد
      ctx.beginPath()
      ctx.moveTo(width * 0.5, height * 0.05) // نقطة البداية (المدخل)
      ctx.lineTo(width * 0.5, height * 0.1) // إلى القسم A

      // تحديد المسار بناءً على القسم
      if (selectedTicket) {
        switch (selectedTicket.section) {
          case "A":
            ctx.lineTo(width * 0.5, height * 0.2)
            break
          case "B":
            ctx.lineTo(width * 0.7, height * 0.1)
            ctx.lineTo(width * 0.85, height * 0.3)
            break
          case "C":
            ctx.lineTo(width * 0.5, height * 0.75)
            break
          case "D":
            ctx.lineTo(width * 0.3, height * 0.1)
            ctx.lineTo(width * 0.15, height * 0.3)
            break
          case "VIP":
            ctx.lineTo(width * 0.7, height * 0.1)
            ctx.lineTo(width * 0.85, height * 0.15)
            break
        }
      }

      ctx.stroke()
      ctx.setLineDash([])

      // رسم نقطة البداية
      ctx.fillStyle = "#4CAF50"
      ctx.beginPath()
      ctx.arc(width * 0.5, height * 0.05, 8, 0, Math.PI * 2)
      ctx.fill()

      // رسم نقطة النهاية
      ctx.fillStyle = "#FFEB3B"
      ctx.beginPath()

      // تحديد موقع نقطة النهاية بناءً على القسم
      let endX = width * 0.5,
        endY = height * 0.2
      if (selectedTicket) {
        switch (selectedTicket.section) {
          case "A":
            endX = width * 0.5
            endY = height * 0.2
            break
          case "B":
            endX = width * 0.85
            endY = height * 0.5
            break
          case "C":
            endX = width * 0.5
            endY = height * 0.8
            break
          case "D":
            endX = width * 0.15
            endY = height * 0.5
            break
          case "VIP":
            endX = width * 0.85
            endY = height * 0.15
            break
        }
      }

      ctx.arc(endX, endY, 8, 0, Math.PI * 2)
      ctx.fill()

      // رسم تعليمات المسار
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(10, 10, 250, 40)

      ctx.fillStyle = "#FFF"
      ctx.font = "14px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(`الخطوة ${currentPathStep + 1}: ${pathInstructions[currentPathStep]}`, 20, 30)
    }
  }

  const draw3DStadium = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw field (with perspective)
    ctx.fillStyle = "#4CAF50"
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.4)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.35, height * 0.6)
    ctx.closePath()
    ctx.fill()

    // Draw field lines
    ctx.strokeStyle = "white"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.4)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.35, height * 0.6)
    ctx.closePath()
    ctx.stroke()

    // Draw center circle (with perspective)
    ctx.beginPath()
    ctx.ellipse(width * 0.5, height * 0.5, 30, 15, 0, 0, Math.PI * 2)
    ctx.stroke()

    // Draw center line
    ctx.beginPath()
    ctx.moveTo(width * 0.5, height * 0.4)
    ctx.lineTo(width * 0.5, height * 0.6)
    ctx.stroke()

    // Draw stands with perspective
    const sectionColors = {
      A: "#FF5722",
      B: "#2196F3",
      C: "#9C27B0",
      D: "#FFEB3B",
      VIP: "#E91E63",
    }

    // Section A (Top)
    ctx.fillStyle = sectionColors.A
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.3)
    ctx.lineTo(width * 0.7, height * 0.3)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.lineTo(width * 0.3, height * 0.4)
    ctx.closePath()
    ctx.fill()
    ctx.strokeStyle = "#000"
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.font = "bold 12px Arial"
    ctx.fillText("A", width * 0.5, height * 0.35)

    // Section B (Right)
    ctx.fillStyle = sectionColors.B
    ctx.beginPath()
    ctx.moveTo(width * 0.7, height * 0.3)
    ctx.lineTo(width * 0.8, height * 0.35)
    ctx.lineTo(width * 0.75, height * 0.55)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.65, height * 0.4)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("B", width * 0.72, height * 0.45)

    // Section C (Bottom)
    ctx.fillStyle = sectionColors.C
    ctx.beginPath()
    ctx.moveTo(width * 0.35, height * 0.6)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.65, height * 0.7)
    ctx.lineTo(width * 0.35, height * 0.7)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("C", width * 0.5, height * 0.65)

    // Section D (Left)
    ctx.fillStyle = sectionColors.D
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.3)
    ctx.lineTo(width * 0.2, height * 0.35)
    ctx.lineTo(width * 0.25, height * 0.55)
    ctx.lineTo(width * 0.35, height * 0.6)
    ctx.lineTo(width * 0.35, height * 0.4)
    ctx.lineTo(width * 0.3, height * 0.4)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("D", width * 0.28, height * 0.45)

    // Section VIP (Top-Right corner)
    ctx.fillStyle = sectionColors.VIP
    ctx.beginPath()
    ctx.moveTo(width * 0.7, height * 0.3)
    ctx.lineTo(width * 0.8, height * 0.35)
    ctx.lineTo(width * 0.9, height * 0.25)
    ctx.lineTo(width * 0.8, height * 0.2)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("VIP", width * 0.8, height * 0.28)

    // Highlight user's section
    if (selectedTicket) {
      highlight3DSection(ctx, selectedTicket.section, width, height)
    }

    // Draw players
    drawPlayers(ctx, width, height)

    // Draw spectators
    drawSpectators(ctx, width, height)

    // رسم المسار الافتراضي إذا كان مفعلاً
    if (showVirtualPath) {
      // رسم المسار في العرض ثلاثي الأبعاد
      ctx.strokeStyle = "#FFEB3B"
      ctx.lineWidth = 3
      ctx.setLineDash([5, 5])

      // رسم مسار من المدخل إلى المقعد
      ctx.beginPath()

      // تحديد نقطة البداية والنهاية بناءً على القسم
      const startX = width * 0.5,
        startY = height * 0.2
      let endX = width * 0.5,
        endY = height * 0.35

      if (selectedTicket) {
        switch (selectedTicket.section) {
          case "A":
            endX = width * 0.5
            endY = height * 0.35
            break
          case "B":
            endX = width * 0.72
            endY = height * 0.45
            break
          case "C":
            endX = width * 0.5
            endY = height * 0.65
            break
          case "D":
            endX = width * 0.28
            endY = height * 0.45
            break
          case "VIP":
            endX = width * 0.8
            endY = height * 0.28
            break
        }
      }

      // رسم المسار
      ctx.moveTo(startX, startY)

      // إضافة نقاط وسيطة للمسار
      switch (selectedTicket?.section) {
        case "A":
          ctx.lineTo(width * 0.5, height * 0.3)
          break
        case "B":
          ctx.lineTo(width * 0.6, height * 0.3)
          ctx.lineTo(width * 0.7, height * 0.35)
          break
        case "C":
          ctx.lineTo(width * 0.5, height * 0.5)
          ctx.lineTo(width * 0.5, height * 0.6)
          break
        case "D":
          ctx.lineTo(width * 0.4, height * 0.3)
          ctx.lineTo(width * 0.3, height * 0.35)
          break
        case "VIP":
          ctx.lineTo(width * 0.6, height * 0.25)
          ctx.lineTo(width * 0.7, height * 0.25)
          break
      }

      ctx.lineTo(endX, endY)
      ctx.stroke()
      ctx.setLineDash([])

      // رسم نقطة البداية
      ctx.fillStyle = "#4CAF50"
      ctx.beginPath()
      ctx.arc(startX, startY, 8, 0, Math.PI * 2)
      ctx.fill()

      // رسم نقطة النهاية
      ctx.fillStyle = "#FFEB3B"
      ctx.beginPath()
      ctx.arc(endX, endY, 8, 0, Math.PI * 2)
      ctx.fill()

      // رسم تعليمات المسار
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(10, 10, 250, 40)

      ctx.fillStyle = "#FFF"
      ctx.font = "14px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(`الخطوة ${currentPathStep + 1}: ${pathInstructions[currentPathStep]}`, 20, 30)
    }
  }

  const drawSection = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    section: string,
    color: string,
  ) => {
    // Draw section background
    ctx.fillStyle = color
    ctx.fillRect(x, y, width, height)

    // Draw section border
    ctx.strokeStyle = "#000"
    ctx.lineWidth = 2
    ctx.strokeRect(x, y, width, height)

    // Draw section label
    ctx.fillStyle = "#fff"
    ctx.font = "bold 14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(section, x + width / 2, y + height / 2)
  }

  const highlightSection = (
    ctx: CanvasRenderingContext2D,
    section: string,
    canvasWidth: number,
    canvasHeight: number,
  ) => {
    let sectionX = 0,
      sectionY = 0,
      sectionWidth = 0,
      sectionHeight = 0

    // Define section coordinates based on section ID
    switch (section) {
      case "A":
        sectionX = canvasWidth * 0.25
        sectionY = canvasHeight * 0.1
        sectionWidth = canvasWidth * 0.5
        sectionHeight = canvasHeight * 0.15
        break
      case "B":
        sectionX = canvasWidth * 0.8
        sectionY = canvasHeight * 0.3
        sectionWidth = canvasWidth * 0.15
        sectionHeight = canvasHeight * 0.4
        break
      case "C":
        sectionX = canvasWidth * 0.25
        sectionY = canvasHeight * 0.75
        sectionWidth = canvasWidth * 0.5
        sectionHeight = canvasHeight * 0.15
        break
      case "D":
        sectionX = canvasWidth * 0.05
        sectionY = canvasHeight * 0.3
        sectionWidth = canvasWidth * 0.15
        sectionHeight = canvasHeight * 0.4
        break
      case "VIP":
        sectionX = canvasWidth * 0.8
        sectionY = canvasHeight * 0.1
        sectionWidth = canvasWidth * 0.15
        sectionHeight = canvasHeight * 0.15
        break
    }

    // Draw highlight
    ctx.strokeStyle = "#FFFF00"
    ctx.lineWidth = 4
    ctx.strokeRect(sectionX, sectionY, sectionWidth, sectionHeight)

    // Draw user's seat
    if (selectedTicket) {
      const row = Number.parseInt(selectedTicket.row)
      const seat = Number.parseInt(selectedTicket.seat)

      const rowCount = 5
      const seatCount = 10
      const seatWidth = sectionWidth / (seatCount + 1)
      const seatHeight = sectionHeight / (rowCount + 1)

      const seatX = sectionX + seat * seatWidth
      const seatY = sectionY + row * seatHeight

      // Draw seat
      ctx.fillStyle = "#FFFF00"
      ctx.beginPath()
      ctx.arc(seatX, seatY, seatWidth * 0.5, 0, Math.PI * 2)
      ctx.fill()

      // Draw seat border
      ctx.strokeStyle = "#000"
      ctx.lineWidth = 1
      ctx.stroke()

      // Add "You" label
      ctx.fillStyle = "#000"
      ctx.font = "bold 10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("أنت", seatX, seatY)
    }
  }

  const highlight3DSection = (
    ctx: CanvasRenderingContext2D,
    section: string,
    canvasWidth: number,
    canvasHeight: number,
  ) => {
    // Define section coordinates for 3D view
    let highlightPoints: [number, number][] = []

    switch (section) {
      case "A":
        highlightPoints = [
          [canvasWidth * 0.3, canvasHeight * 0.3],
          [canvasWidth * 0.7, canvasHeight * 0.3],
          [canvasWidth * 0.7, canvasHeight * 0.4],
          [canvasWidth * 0.3, canvasHeight * 0.4],
        ]
        break
      case "B":
        highlightPoints = [
          [canvasWidth * 0.7, canvasHeight * 0.3],
          [canvasWidth * 0.8, canvasHeight * 0.35],
          [canvasWidth * 0.75, canvasHeight * 0.55],
          [canvasWidth * 0.65, canvasHeight * 0.6],
          [canvasWidth * 0.65, canvasHeight * 0.4],
          [canvasWidth * 0.7, canvasHeight * 0.4],
        ]
        break
      case "C":
        highlightPoints = [
          [canvasWidth * 0.35, canvasHeight * 0.6],
          [canvasWidth * 0.65, canvasHeight * 0.6],
          [canvasWidth * 0.65, canvasHeight * 0.7],
          [canvasWidth * 0.35, canvasHeight * 0.7],
        ]
        break
      case "D":
        highlightPoints = [
          [canvasWidth * 0.3, canvasHeight * 0.3],
          [canvasWidth * 0.2, canvasHeight * 0.35],
          [canvasWidth * 0.25, canvasHeight * 0.55],
          [canvasWidth * 0.35, canvasHeight * 0.6],
          [canvasWidth * 0.35, canvasHeight * 0.4],
          [canvasWidth * 0.3, canvasHeight * 0.4],
        ]
        break
      case "VIP":
        highlightPoints = [
          [canvasWidth * 0.7, canvasHeight * 0.3],
          [canvasWidth * 0.8, canvasHeight * 0.35],
          [canvasWidth * 0.9, canvasHeight * 0.25],
          [canvasWidth * 0.8, canvasHeight * 0.2],
        ]
        break
    }

    // Draw highlight
    ctx.strokeStyle = "#FFFF00"
    ctx.lineWidth = 4
    ctx.beginPath()
    ctx.moveTo(highlightPoints[0][0], highlightPoints[0][1])

    for (let i = 1; i < highlightPoints.length; i++) {
      ctx.lineTo(highlightPoints[i][0], highlightPoints[i][1])
    }

    ctx.closePath()
    ctx.stroke()

    // Draw user's position
    if (selectedTicket) {
      let userX = 0,
        userY = 0

      // Calculate position based on section
      switch (section) {
        case "A":
          userX = canvasWidth * 0.5
          userY = canvasHeight * 0.35
          break
        case "B":
          userX = canvasWidth * 0.72
          userY = canvasHeight * 0.45
          break
        case "C":
          userX = canvasWidth * 0.5
          userY = canvasHeight * 0.65
          break
        case "D":
          userX = canvasWidth * 0.28
          userY = canvasHeight * 0.45
          break
        case "VIP":
          userX = canvasWidth * 0.8
          userY = canvasHeight * 0.28
          break
      }

      // Draw user indicator
      ctx.fillStyle = "#FFFF00"
      ctx.beginPath()
      ctx.arc(userX, userY, 10, 0, Math.PI * 2)
      ctx.fill()

      // Draw user label
      ctx.fillStyle = "#000"
      ctx.font = "bold 10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("أنت", userX, userY)
    }
  }

  const drawPlayers = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Team 1 (left side)
    const team1Color = "#FF0000"
    drawPlayer(ctx, width * 0.35, height * 0.4, team1Color) // Goalkeeper
    drawPlayer(ctx, width * 0.38, height * 0.35, team1Color)
    drawPlayer(ctx, width * 0.38, height * 0.45, team1Color)
    drawPlayer(ctx, width * 0.38, height * 0.55, team1Color)
    drawPlayer(ctx, width * 0.38, height * 0.65, team1Color)
    drawPlayer(ctx, width * 0.42, height * 0.4, team1Color)
    drawPlayer(ctx, width * 0.42, height * 0.5, team1Color)
    drawPlayer(ctx, width * 0.42, height * 0.6, team1Color)
    drawPlayer(ctx, width * 0.46, height * 0.45, team1Color)
    drawPlayer(ctx, width * 0.46, height * 0.55, team1Color)
    drawPlayer(ctx, width * 0.5, height * 0.5, team1Color)

    // Team 2 (right side)
    const team2Color = "#0000FF"
    drawPlayer(ctx, width * 0.65, height * 0.5, team2Color) // Goalkeeper
    drawPlayer(ctx, width * 0.62, height * 0.35, team2Color)
    drawPlayer(ctx, width * 0.62, height * 0.45, team2Color)
    drawPlayer(ctx, width * 0.62, height * 0.55, team2Color)
    drawPlayer(ctx, width * 0.62, height * 0.65, team2Color)
    drawPlayer(ctx, width * 0.58, height * 0.4, team2Color)
    drawPlayer(ctx, width * 0.58, height * 0.5, team2Color)
    drawPlayer(ctx, width * 0.58, height * 0.6, team2Color)
    drawPlayer(ctx, width * 0.54, height * 0.45, team2Color)
    drawPlayer(ctx, width * 0.54, height * 0.55, team2Color)
    drawPlayer(ctx, width * 0.5, height * 0.5, team2Color)

    // Ball
    ctx.fillStyle = "#FFFFFF"
    ctx.beginPath()
    ctx.arc(width * 0.52, height * 0.48, 5, 0, Math.PI * 2)
    ctx.fill()
    ctx.strokeStyle = "#000000"
    ctx.lineWidth = 1
    ctx.stroke()
  }

  const drawPlayer = (ctx: CanvasRenderingContext2D, x: number, y: number, color: string) => {
    // Draw player
    ctx.fillStyle = color
    ctx.beginPath()
    ctx.arc(x, y, 5, 0, Math.PI * 2)
    ctx.fill()
    ctx.strokeStyle = "#000000"
    ctx.lineWidth = 1
    ctx.stroke()
  }

  const drawSpectators = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw spectators as small dots in the stands
    const sections = [
      {
        name: "A",
        x: width * 0.3,
        y: height * 0.3,
        width: width * 0.4,
        height: height * 0.1,
      },
      {
        name: "B",
        x: width * 0.7,
        y: height * 0.3,
        width: width * 0.1,
        height: height * 0.3,
      },
      {
        name: "C",
        x: width * 0.35,
        y: height * 0.6,
        width: width * 0.3,
        height: height * 0.1,
      },
      {
        name: "D",
        x: width * 0.2,
        y: height * 0.35,
        width: width * 0.1,
        height: height * 0.2,
      },
      {
        name: "VIP",
        x: width * 0.8,
        y: height * 0.25,
        width: width * 0.1,
        height: height * 0.1,
      },
    ]

    // Draw spectators in each section
    sections.forEach((section) => {
      const spectatorCount = section.name === "VIP" ? 20 : 50

      for (let i = 0; i < spectatorCount; i++) {
        const x = section.x + Math.random() * section.width
        const y = section.y + Math.random() * section.height

        // Draw spectator
        ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.5 + 0.5})`
        ctx.beginPath()
        ctx.arc(x, y, 2, 0, Math.PI * 2)
        ctx.fill()
      }
    })
  }

  const analyzeChantWithAI = (chantText: string) => {
    // محاكاة تحليل الذكاء الاصطناعي
    const negativeWords = ["ضعيف", "سيء", "خسارة", "ظالم", "فاشل"]
    const positiveWords = ["رائع", "بطل", "فوز", "زعيم", "أبطال", "نجم"]

    // تحليل النص
    const hasNegativeWords = negativeWords.some((word) => chantText.includes(word))
    const hasPositiveWords = positiveWords.some((word) => chantText.includes(word))

    let sentiment: "إيجابي" | "محايد" | "سلبي" = "محايد"
    let score = 50
    let suggestions: string[] = []
    let keywords: string[] = []

    if (hasNegativeWords && !hasPositiveWords) {
      sentiment = "سلبي"
      score = Math.floor(Math.random() * 30) + 10 // 10-40

      // اقتراحات لتحسين الهتاف
      suggestions = [
        chantText.replace(/ضعيف/g, "قوي").replace(/سيء/g, "رائع").replace(/خسارة/g, "فوز"),
        "استخدم كلمات إيجابية لتشجيع الفريق",
        "ركز على دعم اللاعبين بدلاً من انتقادهم",
      ]

      // استخراج الكلمات السلبية
      keywords = negativeWords.filter((word) => chantText.includes(word))
    } else if (hasPositiveWords) {
      sentiment = "إيجابي"
      score = Math.floor(Math.random() * 30) + 70 // 70-100

      // تعزيز الهتاف الإيجابي
      suggestions = ["هتاف رائع! يمكنك مشاركته مع المشجعين الآخرين", "أضف المزيد من الحماس بإضافة اسم اللاعب المفضل"]

      // استخراج الكلمات الإيجابية
      keywords = positiveWords.filter((word) => chantText.includes(word))
    } else {
      // هتاف محايد
      suggestions = ["أضف المزيد من الحماس والتشجيع", "اذكر اسم الفريق أو اللاعبين لجعل الهتاف أكثر تأثيراً"]
    }

    return {
      sentiment,
      score,
      suggestions,
      keywords,
    }
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)

    // Simulate recording and transcription
    if (!isRecording) {
      // إنشاء كائن التعرف على الكلام إذا كان مدعوماً
      if (typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window)) {
        const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
        const recognition = new SpeechRecognition()
        recognition.lang = "ar-SA"
        recognition.continuous = false
        recognition.interimResults = false

        recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript
          setTranscribedText(transcript)

          // تحليل الهتاف باستخدام الذكاء الاصطناعي
          const analysis = analyzeChantWithAI(transcript)
          setAiChantAnalysis(analysis)

          // التحقق مما إذا كان الهتاف يحتاج إلى تحسين
          const negativeChants = Object.keys(chantSuggestions)
          if (negativeChants.some((chant) => transcript.includes(chant))) {
            const matchedChant = negativeChants.find((chant) => transcript.includes(chant))
            if (matchedChant) {
              setSuggestedChant(chantSuggestions[matchedChant as keyof typeof chantSuggestions])
              setShowChantSuggestion(true)
            }
          } else {
            setShowChantSuggestion(false)
          }

          // إضافة إلى الدردشة
          setChatMessages((prev) => [
            ...prev,
            {
              user: user?.name || "أنت",
              message: transcript,
              time: "الآن",
            },
          ])

          // إضافة نقاط للتحدي إذا كان هتافاً إيجابياً
          if (analysis.sentiment === "إيجابي" || positiveChants.includes(transcript)) {
            // تحديث تحدي الهتاف
            const updatedChallenges = [...activeChallenges]
            const chantChallengeIndex = updatedChallenges.findIndex((c) => c.id === "challenge-3")

            if (chantChallengeIndex !== -1 && !updatedChallenges[chantChallengeIndex].completed) {
              updatedChallenges[chantChallengeIndex].completed = true
              setActiveChallenges(updatedChallenges)

              // إضافة النقاط
              const points = updatedChallenges[chantChallengeIndex].points
              setUserPoints((prev) => prev + points)

              // تحديث المستوى
              calculateLevelProgress()
            }
          }

          setIsRecording(false)
        }

        recognition.onerror = (event) => {
          console.error("Speech recognition error", event.error)
          setIsRecording(false)
        }

        recognition.start()
      } else {
        // Fallback for browsers that don't support SpeechRecognition
        setTimeout(() => {
          // اختيار هتاف عشوائي أو استخدام هتاف المستخدم
          const negativeChants = Object.keys(chantSuggestions)
          const allChants = [...negativeChants, ...positiveChants]
          const randomChant = allChants[Math.floor(Math.random() * allChants.length)]

          setTranscribedText(randomChant)
          setIsRecording(false)

          // Add to chat
          setChatMessages((prev) => [
            ...prev,
            {
              user: user?.name || "أنت",
              message: randomChant,
              time: "الآن",
            },
          ])

          // تحليل الهتاف باستخدام الذكاء الاصطناعي
          const analysis = analyzeChantWithAI(randomChant)
          setAiChantAnalysis(analysis)

          // Check if chant needs improvement
          if (negativeChants.includes(randomChant)) {
            setSuggestedChant(chantSuggestions[randomChant as keyof typeof chantSuggestions])
            setShowChantSuggestion(true)
          } else {
            setShowChantSuggestion(false)
          }

          // إضافة نقاط للتحدي إذا كان هتافاً إيجابياً
          if (analysis.sentiment === "إيجابي" || positiveChants.includes(randomChant)) {
            // تحديث تحدي الهتاف
            const updatedChallenges = [...activeChallenges]
            const chantChallengeIndex = updatedChallenges.findIndex((c) => c.id === "challenge-3")

            if (chantChallengeIndex !== -1 && !updatedChallenges[chantChallengeIndex].completed) {
              updatedChallenges[chantChallengeIndex].completed = true
              setActiveChallenges(updatedChallenges)

              // إضافة النقاط
              const points = updatedChallenges[chantChallengeIndex].points
              setUserPoints((prev) => prev + points)

              // تحديث المستوى
              calculateLevelProgress()
            }
          }
        }, 2000)
      }
    }
  }

  // التقدم للخطوة التالية في المسار
  const nextPathStep = () => {
    if (currentPathStep < pathInstructions.length - 1) {
      setCurrentPathStep((prev) => prev + 1)
    } else {
      // وصلنا للمقعد
      setShowVirtualPath(false)
    }
  }

  // العودة للخطوة السابقة في المسار
  const prevPathStep = () => {
    if (currentPathStep > 0) {
      setCurrentPathStep((prev) => prev - 1)
    }
  }

  const startClapGame = () => {
    setShowClapGame(true)

    // اختيار نمط تصفيق بناءً على مستوى الصعوبة
    let pattern: number[] = []

    if (clapDifficulty === "سهل") {
      pattern = clapPatternLibrary[0] || [1, 1, 2, 1, 1]
    } else if (clapDifficulty === "متوسط") {
      pattern = clapPatternLibrary[1] || [2, 1, 2, 3, 1]
    } else {
      pattern = clapPatternLibrary[2] || [3, 1, 2, 3, 2, 1]
    }

    setClapPattern(pattern)
    setUserClaps([])
    setClapScore(0)

    // إعداد وضع المنافسة إذا كان مفعلاً
    if (clapCompetitionMode === "تنافسي") {
      setClapOpponent({
        name: `مشجع ${Math.floor(Math.random() * 100) + 1}`,
        score: Math.floor(Math.random() * 80) + 20, // 20-100
      })
    } else {
      setClapOpponent(null)
    }
  }

  // إكمال تحدي
  const completeChallenge = (challengeId: string) => {
    const updatedChallenges = [...activeChallenges]
    const challengeIndex = updatedChallenges.findIndex((c) => c.id === challengeId)

    if (challengeIndex !== -1 && !updatedChallenges[challengeIndex].completed) {
      // معالجة خاصة لكل نوع من التحديات
      if (challengeId === "challenge-1") {
        // تحدي القميص - رفع صورة
        const fileInput = document.createElement("input")
        fileInput.type = "file"
        fileInput.accept = "image/*"
        fileInput.onchange = (e) => {
          const target = e.target as HTMLInputElement
          if (target.files && target.files[0]) {
            const reader = new FileReader()
            reader.onload = (e) => {
              const result = e.target?.result as string
              setUploadedImage(result)

              // إكمال التحدي بعد رفع الصورة
              updatedChallenges[challengeIndex].completed = true
              setActiveChallenges(updatedChallenges)

              // إضافة النقاط
              const points = updatedChallenges[challengeIndex].points
              setUserPoints((prev) => prev + points)

              // تحديث المستوى
              calculateLevelProgress()

              // إضافة التحدي للتحديات المكتملة
              setCompletedChallenges((prev) => [...prev, challengeId])
            }
            reader.readAsDataURL(target.files[0])
          }
        }
        fileInput.click()
        return
      } else if (challengeId === "challenge-2") {
        // تحدي توقع النتيجة - فتح نافذة التوقعات
        // سيتم التعامل معه في واجهة المستخدم
        if (selectedPrediction || selectedPlayerPrediction) {
          updatedChallenges[challengeIndex].completed = true
        } else {
          return // لا تكمل التحدي حتى يتم اختيار توقع
        }
      } else {
        // تحديات أخرى
        updatedChallenges[challengeIndex].completed = true
      }

      setActiveChallenges(updatedChallenges)

      // إضافة النقاط
      const points = updatedChallenges[challengeIndex].points
      setUserPoints((prev) => prev + points)

      // تحديث المستوى
      calculateLevelProgress()

      // إضافة التحدي للتحديات المكتملة
      setCompletedChallenges((prev) => [...prev, challengeId])
    }
  }

  // إكمال تحدي يومي
  const completeDailyQuest = (questId: string) => {
    const updatedQuests = [...dailyQuests]
    const questIndex = updatedQuests.findIndex((q) => q.id === questId)

    if (questIndex !== -1 && !updatedQuests[questIndex].completed) {
      updatedQuests[questIndex].completed = true
      setDailyQuests(updatedQuests)

      // إضافة النقاط
      const points = updatedQuests[questIndex].points
      setUserPoints((prev) => prev + points)

      // تحديث المستوى
      calculateLevelProgress()
    }
  }

  // إضافة تصفيقة للاعب
  const addClap = () => {
    if (userClaps.length < clapPattern.length) {
      const updatedClaps = [...userClaps, 1]
      setUserClaps(updatedClaps)

      // التحقق من اكتمال النمط
      if (updatedClaps.length === clapPattern.length) {
        // حساب النتيجة
        let score = 0
        for (let i = 0; i < clapPattern.length; i++) {
          if (updatedClaps[i] === clapPattern[i]) {
            score += 20
          }
        }

        setClapScore(score)

        // إضافة نقاط إذا كانت النتيجة جيدة
        if (score >= 60) {
          setUserPoints((prev) => prev + 10)
          calculateLevelProgress()
        }
      }
    }
  }

  // التصويت
  const vote = (optionId: string) => {
    const updatedOptions = [...votingOptions]

    // التأكد من عدم التصويت مسبقاً
    const alreadyVoted = updatedOptions.some((opt) => opt.voted)

    if (!alreadyVoted) {
      const optionIndex = updatedOptions.findIndex((opt) => opt.id === optionId)

      if (optionIndex !== -1) {
        updatedOptions[optionIndex].votes += 1
        updatedOptions[optionIndex].voted = true
        setVotingOptions(updatedOptions)

        // إضافة نقاط للتصويت
        setUserPoints((prev) => prev + 5)
        calculateLevelProgress()
      }
    }
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    // Add message to chat
    setChatMessages((prev) => [
      ...prev,
      {
        user: user?.name || "أنت",
        message: newMessage,
        time: "الآن",
      },
    ])

    // Check if message needs improvement
    const negativeChants = Object.keys(chantSuggestions)
    if (negativeChants.some((chant) => newMessage.includes(chant))) {
      const matchedChant = negativeChants.find((chant) => newMessage.includes(chant))
      if (matchedChant) {
        setSuggestedChant(chantSuggestions[matchedChant as keyof typeof chantSuggestions])
        setShowChantSuggestion(true)
      }
    } else {
      setShowChantSuggestion(false)
    }

    // Clear input
    setNewMessage("")
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.log(`Error attempting to enable full-screen mode: ${err.message}`)
      })
      setIsFullscreen(true)
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
        setIsFullscreen(false)
      }
    }
  }

  const handleCrowdNoiseChange = (value: number[]) => {
    setCrowdNoise(value[0])
    if (audioRef.current) {
      audioRef.current.volume = value[0] / 100
    }
  }

  const captureScreenshot = () => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const dataUrl = canvas.toDataURL("image/png")

    // Create download link
    const a = document.createElement("a")
    a.href = dataUrl
    a.download = `virtual-stadium-${Date.now()}.png`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)

    // إضافة نقاط لالتقاط صورة
    setUserPoints((prev) => prev + 5)
    calculateLevelProgress()
  }

  // مشاركة الإنجاز
  const shareAchievement = (achievement: string) => {
    // محاكاة مشاركة الإنجاز
    alert(`تمت مشاركة إنجازك: ${achievement}`)

    // إضافة نقاط للمشاركة
    setUserPoints((prev) => prev + 5)
    calculateLevelProgress()
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  if (tickets.length === 0) {
    return (
      <div className="min-h-screen bg-black pb-20 text-white">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8 flex items-center">
            <Link href="/dashboard" className="ml-4">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-6 w-6" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">الحضور الافتراضي</h1>
          </div>

          <div className="flex flex-col items-center justify-center rounded-lg border border-gray-800 bg-gray-900 p-8 text-center">
            <Users className="mb-4 h-16 w-16 text-gray-600" />
            <h2 className="mb-2 text-xl font-semibold">لا توجد تذاكر افتراضية</h2>
            <p className="mb-6 text-gray-400">لم تقم بحجز أي تذاكر افتراضية بعد</p>
            <Link href="/dashboard/tickets/virtual-booking">
              <Button className="bg-yellow-500 text-black hover:bg-yellow-600">حجز تذكرة افتراضية الآن</Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-black pb-20 text-white ${isFullscreen ? "fullscreen-mode" : ""}`}>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        {showControls && (
          <div className="mb-8 flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/dashboard" className="ml-4">
                <Button variant="ghost" size="icon">
                  <ChevronLeft className="h-6 w-6" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold">الحضور الافتراضي</h1>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={toggleFullscreen}>
                <Maximize className="mr-2 h-4 w-4" />
                {isFullscreen ? "إلغاء ملء الشاشة" : "ملء الشاشة"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowControls(!showControls)}>
                {showControls ? "إخفاء التحكم" : "إظهار التحكم"}
              </Button>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Stadium View */}
          <div className="lg:col-span-2">
            <Card className="border-gray-800 bg-gray-900">
              <CardContent className="p-4">
                {showControls && (
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="font-medium">
                      {selectedTicket?.homeTeam} ضد {selectedTicket?.awayTeam}
                    </h3>
                    <div className="flex items-center gap-2">
                      <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "2d" | "3d" | "vr")}>
                        <TabsList>
                          <TabsTrigger value="2d">2D</TabsTrigger>
                          <TabsTrigger value="3d">3D</TabsTrigger>
                          <TabsTrigger value="vr">VR</TabsTrigger>
                        </TabsList>
                      </Tabs>
                      <Button variant="outline" size="icon" onClick={captureScreenshot}>
                        <Camera className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}

                {showControls && viewMode === "vr" && (
                  <div className="mb-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>منظور الرؤية</Label>
                      <Toggle
                        pressed={isFirstPerson}
                        onPressedChange={setIsFirstPerson}
                        aria-label="تبديل منظور الرؤية"
                      >
                        {isFirstPerson ? "منظور الشخص الأول" : "منظور خارجي"}
                      </Toggle>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>إظهار المسار الافتراضي</Label>
                      <Toggle
                        pressed={showVirtualPath}
                        onPressedChange={setShowVirtualPath}
                        aria-label="إظهار المسار الافتراضي"
                      >
                        {showVirtualPath ? "إخفاء" : "إظهار"}
                      </Toggle>
                    </div>

                    {showVirtualPath && (
                      <div className="flex items-center justify-between">
                        <Button variant="outline" size="sm" onClick={prevPathStep} disabled={currentPathStep === 0}>
                          <ArrowRight className="mr-2 h-4 w-4" />
                          الخطوة السابقة
                        </Button>

                        <span className="text-sm">
                          {currentPathStep + 1} / {pathInstructions.length}
                        </span>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={nextPathStep}
                          disabled={currentPathStep === pathInstructions.length - 1}
                        >
                          الخطوة التالية
                          <ArrowLeft className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <Label>إظهار تعليمات التحكم</Label>
                      <Toggle
                        pressed={showVRControls}
                        onPressedChange={setShowVRControls}
                        aria-label="إظهار تعليمات التحكم"
                      >
                        {showVRControls ? "إخفاء" : "إظهار"}
                      </Toggle>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>سرعة الحركة</Label>
                        <span className="text-sm text-gray-400">{vrMovementSpeed}</span>
                      </div>
                      <Slider
                        value={[vrMovementSpeed]}
                        min={1}
                        max={10}
                        step={1}
                        onValueChange={(value) => setVrMovementSpeed(value[0])}
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>سرعة الدوران</Label>
                        <span className="text-sm text-gray-400">{vrRotationSpeed}</span>
                      </div>
                      <Slider
                        value={[vrRotationSpeed]}
                        min={1}
                        max={10}
                        step={1}
                        onValueChange={(value) => setVrRotationSpeed(value[0])}
                      />
                    </div>
                  </div>
                )}

                {showControls && viewMode !== "vr" && (
                  <div className="mb-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>تكبير/تصغير</Label>
                      <span className="text-sm text-gray-400">{Math.round(zoomLevel * 100)}%</span>
                    </div>
                    <Slider
                      value={[zoomLevel]}
                      min={0.5}
                      max={2}
                      step={0.1}
                      onValueChange={(value) => setZoomLevel(value[0])}
                    />

                    <div className="flex items-center justify-between mt-2">
                      <Label>إظهار المسار الافتراضي</Label>
                      <Toggle
                        pressed={showVirtualPath}
                        onPressedChange={setShowVirtualPath}
                        aria-label="إظهار المسار الافتراضي"
                      >
                        {showVirtualPath ? "إخفاء" : "إظهار"}
                      </Toggle>
                    </div>

                    {showVirtualPath && (
                      <div className="flex items-center justify-between mt-2">
                        <Button variant="outline" size="sm" onClick={prevPathStep} disabled={currentPathStep === 0}>
                          <ArrowRight className="mr-2 h-4 w-4" />
                          الخطوة السابقة
                        </Button>

                        <span className="text-sm">
                          {currentPathStep + 1} / {pathInstructions.length}
                        </span>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={nextPathStep}
                          disabled={currentPathStep === pathInstructions.length - 1}
                        >
                          الخطوة التالية
                          <ArrowLeft className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                <div className="relative aspect-video overflow-hidden rounded bg-gray-700">
                  <canvas ref={canvasRef} width={800} height={600} className="h-full w-full" />

                  <audio ref={audioRef} loop>
                    <source src="/placeholder.svg" type="audio/mpeg" />
                  </audio>

                  {viewMode === "vr" && (
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between rounded bg-black/70 p-2">
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={() => setIsFirstPerson(!isFirstPerson)}>
                          {isFirstPerson ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                          {isFirstPerson ? "منظور خارجي" : "منظور الشخص الأول"}
                        </Button>

                        <Button variant="outline" size="sm" onClick={() => setShowVRControls(!showVRControls)}>
                          <Move className="mr-2 h-4 w-4" />
                          {showVRControls ? "إخفاء التعليمات" : "إظهار التعليمات"}
                        </Button>
                      </div>

                      <div className="text-sm text-gray-300">استخدم W,A,S,D للتحرك | V للتبديل بين المناظير</div>
                    </div>
                  )}

                  {showControls && viewMode !== "vr" && (
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between rounded bg-black/70 p-2">
                      <div className="flex items-center gap-2">
                        <Button
                          variant={isRecording ? "destructive" : "outline"}
                          size="sm"
                          onClick={toggleRecording}
                          className={isRecording ? "animate-pulse" : ""}
                        >
                          {isRecording ? <MicOff className="mr-2 h-4 w-4" /> : <Mic className="mr-2 h-4 w-4" />}
                          {isRecording ? "إيقاف التسجيل" : "تسجيل هتاف"}
                        </Button>

                        <div className="flex items-center gap-1">
                          <Volume2 className="h-4 w-4 text-gray-400" />
                          <Slider
                            value={[crowdNoise]}
                            min={0}
                            max={100}
                            step={5}
                            onValueChange={handleCrowdNoiseChange}
                            className="w-24"
                          />
                        </div>
                      </div>

                      <Badge className="bg-yellow-500 text-black">
                        {selectedTicket?.section} - {selectedTicket?.row} - {selectedTicket?.seat}
                      </Badge>
                    </div>
                  )}
                </div>

                {transcribedText && (
                  <div className="mt-3 rounded bg-gray-800 p-2">
                    <div className="flex items-center">
                      <Volume2 className="mr-2 h-4 w-4 text-yellow-500" />
                      <span>{transcribedText}</span>
                    </div>

                    {showChantSuggestion && (
                      <div className="mt-2 rounded bg-yellow-500/20 p-2 text-sm">
                        <p className="font-medium text-yellow-500">اقتراح أفضل:</p>
                        <p>{suggestedChant}</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* تحديات المشاركة الاجتماعية */}
            <Card className="border-gray-800 bg-gray-900 mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="mr-2 h-5 w-5 text-yellow-500" />
                  تحديات المشاركة الاجتماعية
                </CardTitle>
                <CardDescription>أكمل التحديات واحصل على نقاط ومكافآت</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeChallenges.map((challenge) => (
                    <div
                      key={challenge.id}
                      className={`rounded-lg border ${
                        challenge.completed ? "border-green-500 bg-green-500/10" : "border-gray-800"
                      } p-4`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {challenge.completed ? (
                            <div className="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-green-500/20 text-green-500">
                              <CheckIcon className="h-6 w-6" />
                            </div>
                          ) : (
                            <div className="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-yellow-500/20 text-yellow-500">
                              <Star className="h-6 w-6" />
                            </div>
                          )}
                          <div>
                            <div className="flex items-center">
                              <h4 className="font-medium">{challenge.title}</h4>
                              <Badge className="ml-2 bg-blue-500">{challenge.hashtag}</Badge>
                            </div>
                            <p className="text-sm text-gray-400">{challenge.description}</p>
                            <div className="mt-1 flex items-center text-xs text-gray-500">
                              <Users className="mr-1 h-3 w-3" /> {challenge.participants} مشارك
                              <span className="mx-2">•</span>
                              <Trophy className="mr-1 h-3 w-3" /> {challenge.reward}
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <Badge className="mb-2 bg-yellow-500 text-black">{challenge.points} نقطة</Badge>
                          {!challenge.completed ? (
                            <Button variant="outline" size="sm" onClick={() => completeChallenge(challenge.id)}>
                              أكمل التحدي
                            </Button>
                          ) : (
                            <Button variant="outline" size="sm" onClick={() => shareAchievement(challenge.title)}>
                              <Share className="mr-2 h-4 w-4" />
                              مشاركة
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* محتوى إضافي لكل تحدي */}
                      {challenge.id === "challenge-1" && (
                        <div className="mt-3">
                          {uploadedImage ? (
                            <div className="mt-2 text-center">
                              <img
                                src={uploadedImage || "/placeholder.svg"}
                                alt="صورة المشجع"
                                className="mx-auto mb-2 h-40 rounded-lg object-cover"
                              />
                              <p className="text-sm text-green-500">تم رفع الصورة بنجاح! ستظهر في قاعة المشجعين</p>
                            </div>
                          ) : (
                            <Button
                              variant="outline"
                              className="mt-2 w-full"
                              onClick={() => completeChallenge(challenge.id)}
                            >
                              <Camera className="mr-2 h-4 w-4" />
                              رفع صورة مع منتجات الفريق
                            </Button>
                          )}
                        </div>
                      )}

                      {challenge.id === "challenge-2" && (
                        <div className="mt-3 space-y-3">
                          <div>
                            <h5 className="mb-2 text-sm font-medium">توقع نتيجة المباراة:</h5>
                            <div className="grid grid-cols-2 gap-2">
                              {challenge.options?.map((option) => (
                                <div
                                  key={option.id}
                                  className={`cursor-pointer rounded-lg border p-2 text-center text-sm ${
                                    selectedPrediction === option.id
                                      ? "border-yellow-500 bg-yellow-500/10"
                                      : "border-gray-700 hover:border-gray-600"
                                  }`}
                                  onClick={() => setSelectedPrediction(option.id)}
                                >
                                  <p>{option.text}</p>
                                  <div className="mt-1 text-xs text-gray-500">{option.votes} صوت</div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h5 className="mb-2 text-sm font-medium">توقعات أحداث المباراة:</h5>
                            <div className="space-y-2">
                              {challenge.playerPredictions?.map((prediction) => (
                                <div
                                  key={prediction.id}
                                  className={`cursor-pointer rounded-lg border p-2 ${
                                    selectedPlayerPrediction === prediction.id
                                      ? "border-yellow-500 bg-yellow-500/10"
                                      : "border-gray-700 hover:border-gray-600"
                                  }`}
                                  onClick={() => setSelectedPlayerPrediction(prediction.id)}
                                >
                                  <div className="flex items-center justify-between">
                                    <p className="text-sm">{prediction.text}</p>
                                    <Badge variant="outline">{prediction.votes} صوت</Badge>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {(selectedPrediction || selectedPlayerPrediction) && !challenge.completed && (
                            <Button className="w-full" onClick={() => completeChallenge(challenge.id)}>
                              تأكيد التوقعات
                            </Button>
                          )}
                        </div>
                      )}

                      {challenge.id === "challenge-3" && (
                        <div className="mt-3">
                          <h5 className="mb-2 text-sm font-medium">أفضل الهتافات:</h5>
                          <div className="space-y-2">
                            {challenge.topChants?.map((chant, idx) => (
                              <div key={idx} className="rounded-lg border border-gray-700 p-2">
                                <div className="flex items-center justify-between">
                                  <p className="text-sm">"{chant.text}"</p>
                                  <div className="flex items-center">
                                    <span className="text-yellow-500">{chant.rating} ★</span>
                                    <span className="ml-2 text-xs text-gray-500">- {chant.author}</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Button
                            variant={isRecording ? "destructive" : "outline"}
                            size="sm"
                            onClick={toggleRecording}
                            className={`mt-3 w-full ${isRecording ? "animate-pulse" : ""}`}
                          >
                            {isRecording ? <MicOff className="mr-2 h-4 w-4" /> : <Mic className="mr-2 h-4 w-4" />}
                            {isRecording ? "إيقاف التسجيل" : "تسجيل هتاف جديد"}
                          </Button>

                          {transcribedText && aiChantAnalysis && (
                            <div className="mt-3 rounded-lg border border-gray-700 p-3">
                              <div className="mb-2 flex items-center justify-between">
                                <div className="flex items-center">
                                  <Volume2 className="mr-2 h-4 w-4 text-yellow-500" />
                                  <span>"{transcribedText}"</span>
                                </div>
                                <Badge
                                  className={
                                    aiChantAnalysis.sentiment === "إيجابي"
                                      ? "bg-green-500"
                                      : aiChantAnalysis.sentiment === "سلبي"
                                        ? "bg-red-500"
                                        : "bg-yellow-500 text-black"
                                  }
                                >
                                  {aiChantAnalysis.sentiment}
                                </Badge>
                              </div>

                              <div className="mb-2 space-y-1">
                                <div className="flex items-center justify-between text-xs">
                                  <span>جودة الهتاف:</span>
                                  <span>{aiChantAnalysis.score}%</span>
                                </div>
                                <div className="h-1 overflow-hidden rounded-full bg-gray-700">
                                  <div
                                    className={`h-full ${
                                      aiChantAnalysis.sentiment === "إيجابي"
                                        ? "bg-green-500"
                                        : aiChantAnalysis.sentiment === "سلبي"
                                          ? "bg-red-500"
                                          : "bg-yellow-500"
                                    }`}
                                    style={{ width: `${aiChantAnalysis.score}%` }}
                                  />
                                </div>
                              </div>

                              {aiChantAnalysis.keywords.length > 0 && (
                                <div className="mb-2">
                                  <p className="mb-1 text-xs text-gray-400">الكلمات المؤثرة:</p>
                                  <div className="flex flex-wrap gap-1">
                                    {aiChantAnalysis.keywords.map((keyword, idx) => (
                                      <Badge key={idx} variant="outline">
                                        {keyword}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {aiChantAnalysis.suggestions.length > 0 && (
                                <div>
                                  <p className="mb-1 text-xs text-gray-400">اقتراحات التحسين:</p>
                                  <ul className="space-y-1 text-xs text-gray-300">
                                    {aiChantAnalysis.suggestions.map((suggestion, idx) => (
                                      <li key={idx}>• {suggestion}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* الألعاب التفاعلية */}
            <Card className="border-gray-800 bg-gray-900 mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Gamepad2 className="mr-2 h-5 w-5 text-purple-500" />
                  الألعاب التفاعلية
                </CardTitle>
                <CardDescription>العب وتفاعل مع المشجعين الآخرين</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="clap">
                  <TabsList className="mb-4">
                    <TabsTrigger value="clap">سباق التصفيق</TabsTrigger>
                    <TabsTrigger value="vote">التحكيم الافتراضي</TabsTrigger>
                  </TabsList>

                  <TabsContent value="clap">
                    <div className="rounded-lg border border-gray-800 p-4">
                      <div className="mb-4 flex items-center justify-between">
                        <h3 className="text-lg font-medium">سباق التصفيق</h3>
                        <div className="flex gap-2">
                          <Select
                            value={clapDifficulty}
                            onValueChange={(value) => setClapDifficulty(value as "سهل" | "متوسط" | "متقدم")}
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue placeholder="الصعوبة" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="سهل">سهل</SelectItem>
                              <SelectItem value="متوسط">متوسط</SelectItem>
                              <SelectItem value="متقدم">متقدم</SelectItem>
                            </SelectContent>
                          </Select>

                          <Select
                            value={clapCompetitionMode}
                            onValueChange={(value) => setClapCompetitionMode(value as "فردي" | "جماعي" | "تنافسي")}
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue placeholder="الوضع" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="فردي">فردي</SelectItem>
                              <SelectItem value="جماعي">جماعي</SelectItem>
                              <SelectItem value="تنافسي">تنافسي</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {!showClapGame ? (
                        <div className="text-center py-8">
                          <Clap className="mx-auto mb-4 h-16 w-16 text-yellow-500" />
                          <h3 className="mb-2 text-xl font-medium">سباق التصفيق</h3>
                          <p className="mb-6 text-gray-400">
                            صفق بنفس النمط المعروض للحصول على نقاط وتنافس مع المشجعين الآخرين
                          </p>

                          <div className="mb-4 text-sm text-gray-400">
                            <p>
                              الصعوبة: <span className="text-white">{clapDifficulty}</span>
                            </p>
                            <p>
                              الوضع: <span className="text-white">{clapCompetitionMode}</span>
                            </p>
                            {clapCompetitionMode === "جماعي" && (
                              <p className="mt-2">
                                <Users className="inline-block mr-1 h-4 w-4" />
                                <span className="text-green-500">24 مشجع</span> يشاركون في التصفيق الجماعي الآن
                              </p>
                            )}
                          </div>

                          <Button
                            onClick={startClapGame}
                            size="lg"
                            className="bg-yellow-500 text-black hover:bg-yellow-600"
                          >
                            ابدأ اللعبة
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="text-center">
                            <h3 className="mb-4 text-lg font-medium">
                              {clapCompetitionMode === "تنافسي"
                                ? `منافسة ضد ${clapOpponent?.name}`
                                : clapCompetitionMode === "جماعي"
                                  ? "تصفيق جماعي"
                                  : "اتبع النمط"}
                            </h3>

                            <div className="mb-6 flex justify-center space-x-4 space-x-reverse">
                              {clapPattern.map((claps, index) => (
                                <div
                                  key={index}
                                  className={`flex h-12 w-12 items-center justify-center rounded-full text-lg font-bold ${
                                    index < userClaps.length
                                      ? userClaps[index] === claps
                                        ? "bg-green-500/20 text-green-500"
                                        : "bg-red-500/20 text-red-500"
                                      : "bg-gray-700"
                                  }`}
                                >
                                  {claps}
                                </div>
                              ))}
                            </div>

                            {clapCompetitionMode === "تنافسي" && clapOpponent && (
                              <div className="mb-4 rounded-lg bg-gray-800 p-3">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center">
                                    <Avatar className="mr-2 h-8 w-8">
                                      <AvatarFallback>{clapOpponent.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <span>{clapOpponent.name}</span>
                                  </div>
                                  <Progress value={clapOpponent.score} className="w-24 h-2" />
                                </div>
                              </div>
                            )}

                            {clapCompetitionMode === "جماعي" && (
                              <div className="mb-4 rounded-lg bg-gray-800 p-3">
                                <h4 className="mb-2 text-sm font-medium">مؤشر حماس الجمهور</h4>
                                <Progress value={userClaps.length * 10 + 30} className="h-3" />
                                <p className="mt-2 text-sm text-gray-400">
                                  <Users className="inline-block mr-1 h-4 w-4" />
                                  <span className="text-green-500">24 مشجع</span> يشاركون معك الآن
                                </p>
                              </div>
                            )}

                            <Button
                              size="lg"
                              onClick={addClap}
                              disabled={userClaps.length >= clapPattern.length}
                              className={`bg-yellow-500 text-black hover:bg-yellow-600 ${
                                userClaps.length < clapPattern.length ? "animate-pulse" : ""
                              }`}
                            >
                              <Clap className="mr-2 h-5 w-5" />
                              صفق!
                            </Button>

                            {userClaps.length === clapPattern.length && (
                              <div className="mt-6">
                                <div className="mb-4 rounded-lg bg-gray-800 p-4 text-center">
                                  <h3 className="mb-2 text-2xl font-bold">النتيجة: {clapScore}%</h3>
                                  {clapScore >= 80 ? (
                                    <p className="text-green-500">ممتاز! أنت متزامن تماماً مع الإيقاع</p>
                                  ) : clapScore >= 50 ? (
                                    <p className="text-yellow-500">جيد! استمر في التدريب</p>
                                  ) : (
                                    <p className="text-red-500">حاول مرة أخرى للحصول على نتيجة أفضل</p>
                                  )}

                                  {clapCompetitionMode === "تنافسي" && clapOpponent && (
                                    <p className="mt-2">
                                      {clapScore > clapOpponent.score ? (
                                        <span className="text-green-500">لقد فزت على {clapOpponent.name}!</span>
                                      ) : (
                                        <span className="text-red-500">لقد فاز عليك {clapOpponent.name}</span>
                                      )}
                                    </p>
                                  )}

                                  {clapScore >= 60 && (
                                    <div className="mt-2">
                                      <Badge className="bg-yellow-500 text-black">+10 نقاط</Badge>
                                    </div>
                                  )}
                                </div>

                                <div className="flex gap-2">
                                  <Button variant="outline" onClick={startClapGame} className="flex-1">
                                    إعادة المحاولة
                                  </Button>
                                  <Button onClick={() => setShowClapGame(false)} className="flex-1">
                                    العودة
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="vote">
                    <div className="rounded-lg border border-gray-800 p-4">
                      <h3 className="mb-4 text-center text-lg font-medium">التحكيم الافتراضي</h3>

                      <Tabs defaultValue="players">
                        <TabsList className="mb-4 w-full">
                          <TabsTrigger value="players" className="flex-1">
                            أفضل لاعب
                          </TabsTrigger>
                          <TabsTrigger value="moments" className="flex-1">
                            أفضل لحظة
                          </TabsTrigger>
                          <TabsTrigger value="referee" className="flex-1">
                            قرارات الحكم
                          </TabsTrigger>
                        </TabsList>

                        <TabsContent value="players">
                          <div className="space-y-3">
                            {votingOptions.map((option) => (
                              <div
                                key={option.id}
                                className={`rounded-lg border p-3 ${
                                  option.voted ? "border-yellow-500 bg-yellow-500/10" : "border-gray-700"
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center">
                                    <Avatar className="mr-3 h-12 w-12">
                                      <AvatarFallback>{option.title.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <p className="font-medium">{option.title}</p>
                                      <div className="mt-1 flex items-center">
                                        <Progress value={(option.votes / 600) * 100} className="h-2 w-24" />
                                        <span className="ml-2 text-sm text-gray-400">{option.votes} صوت</span>
                                      </div>
                                    </div>
                                  </div>
                                  <Button
                                    variant={option.voted ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => vote(option.id)}
                                    disabled={votingOptions.some((opt) => opt.voted) && !option.voted}
                                  >
                                    {option.voted ? (
                                      <>
                                        <ThumbsUp className="mr-2 h-4 w-4" />
                                        تم التصويت
                                      </>
                                    ) : (
                                      "تصويت"
                                    )}
                                  </Button>
                                </div>

                                {option.stats && (
                                  <div className="mt-3 grid grid-cols-3 gap-2 rounded-lg bg-gray-800 p-2 text-center text-sm">
                                    <div>
                                      <p className="text-gray-400">أهداف</p>
                                      <p className="font-medium">{option.stats.goals}</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-400">تمريرات حاسمة</p>
                                      <p className="font-medium">{option.stats.assists}</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-400">التقييم</p>
                                      <p className="font-medium text-yellow-500">{option.stats.rating}</p>
                                    </div>
                                  </div>
                                )}

                                {option.voted && (
                                  <div className="mt-3">
                                    <p className="text-sm text-gray-400">مقارنة مع آراء الخبراء:</p>
                                    <div className="mt-1 flex items-center">
                                      <span className="text-sm">الجمهور:</span>
                                      <Progress value={(option.votes / 600) * 100} className="mx-2 h-2 flex-1" />
                                      <span className="text-sm">{Math.round((option.votes / 600) * 100)}%</span>
                                    </div>
                                    <div className="mt-1 flex items-center">
                                      <span className="text-sm">الخبراء:</span>
                                      <Progress value={75} className="mx-2 h-2 flex-1 bg-gray-700">
                                        <div className="h-full bg-blue-500" style={{ width: "75%" }} />
                                      </Progress>
                                      <span className="text-sm">75%</span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </TabsContent>

                        <TabsContent value="moments">
                          <div className="space-y-3">
                            <div className="rounded-lg border border-gray-700 p-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">هدف رونالدو في الدقيقة 78</p>
                                  <div className="mt-1 flex items-center">
                                    <Progress value={85} className="h-2 w-24" />
                                    <span className="ml-2 text-sm text-gray-400">312 صوت</span>
                                  </div>
                                </div>
                                <Button variant="outline" size="sm">
                                  تصويت
                                </Button>
                              </div>
                            </div>

                            <div className="rounded-lg border border-gray-700 p-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">تصدي الحارس في الدقيقة 54</p>
                                  <div className="mt-1 flex items-center">
                                    <Progress value={65} className="h-2 w-24" />
                                    <span className="ml-2 text-sm text-gray-400">243 صوت</span>
                                  </div>
                                </div>
                                <Button variant="outline" size="sm">
                                  تصويت
                                </Button>
                              </div>
                            </div>

                            <div className="rounded-lg border border-gray-700 p-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">مراوغة بنزيما في الدقيقة 32</p>
                                  <div className="mt-1 flex items-center">
                                    <Progress value={45} className="h-2 w-24" />
                                    <span className="ml-2 text-sm text-gray-400">168 صوت</span>
                                  </div>
                                </div>
                                <Button variant="outline" size="sm">
                                  تصويت
                                </Button>
                              </div>
                            </div>
                          </div>
                        </TabsContent>

                        <TabsContent value="referee">
                          <div className="space-y-3">
                            <div className="rounded-lg border border-gray-700 p-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">ركلة الجزاء في الدقيقة 65</p>
                                  <div className="mt-1 flex items-center">
                                    <Progress value={35} className="h-2 w-24" />
                                    <span className="ml-2 text-sm text-gray-400">130 صوت</span>
                                  </div>
                                </div>
                                <div className="flex gap-2">
                                  <Button variant="outline" size="sm" className="bg-green-500/20 hover:bg-green-500/30">
                                    صحيح
                                  </Button>
                                  <Button variant="outline" size="sm" className="bg-red-500/20 hover:bg-red-500/30">
                                    خاطئ
                                  </Button>
                                </div>
                              </div>

                              <div className="mt-3">
                                <p className="text-sm text-gray-400">مقارنة مع آراء الخبراء:</p>
                                <div className="mt-1 grid grid-cols-2 gap-2 text-center">
                                  <div className="rounded bg-green-500/20 p-1">
                                    <p className="text-sm">صحيح: 35%</p>
                                  </div>
                                  <div className="rounded bg-red-500/20 p-1">
                                    <p className="text-sm">خاطئ: 65%</p>
                                  </div>
                                </div>
                                <div className="mt-2 rounded bg-blue-500/20 p-1 text-center">
                                  <p className="text-sm">رأي الخبراء: خاطئ (80%)</p>
                                </div>
                              </div>
                            </div>

                            <div className="rounded-lg border border-gray-700 p-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">البطاقة الحمراء في الدقيقة 42</p>
                                  <div className="mt-1 flex items-center">
                                    <Progress value={75} className="h-2 w-24" />
                                    <span className="ml-2 text-sm text-gray-400">278 صوت</span>
                                  </div>
                                </div>
                                <div className="flex gap-2">
                                  <Button variant="outline" size="sm" className="bg-green-500/20 hover:bg-green-500/30">
                                    صحيح
                                  </Button>
                                  <Button variant="outline" size="sm" className="bg-red-500/20 hover:bg-red-500/30">
                                    خاطئ
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </TabsContent>
                      </Tabs>

                      <div className="mt-4 rounded-lg bg-gray-800 p-3">
                        <h4 className="mb-2 text-sm font-medium">إحصائيات التصويت</h4>
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div>
                            <p className="text-2xl font-bold text-yellow-500">1,245</p>
                            <p className="text-xs text-gray-400">إجمالي الأصوات</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-yellow-500">78%</p>
                            <p className="text-xs text-gray-400">نسبة المشاركة</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-yellow-500">24</p>
                            <p className="text-xs text-gray-400">دقيقة متبقية</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* معلومات المستخدم والمستوى */}
            <Card className="border-gray-800 bg-gray-900">
              <CardContent className="p-4">
                <div className="mb-4 flex items-center">
                  <Avatar className="mr-3 h-12 w-12">
                    <AvatarFallback>{user?.name?.charAt(0) || "م"}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">{user?.name || "المستخدم"}</h3>
                    <div className="flex items-center">
                      <Badge className="mr-2 bg-gradient-to-r from-yellow-500 to-amber-600 text-black">
                        {userLevel}
                      </Badge>
                      <span className="text-sm text-gray-400">{userPoints} نقطة</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">المستوى التالي: {nextLevelPoints} نقطة</span>
                    <span className="text-sm text-gray-400">{Math.round(levelProgress)}%</span>
                  </div>
                  <Progress value={levelProgress} className="h-2" />
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-gray-800 p-2">
                    <Trophy className="mx-auto mb-1 h-5 w-5 text-yellow-500" />
                    <span className="text-xs">3 تحديات</span>
                  </div>
                  <div className="rounded-lg bg-gray-800 p-2">
                    <Medal className="mx-auto mb-1 h-5 w-5 text-yellow-500" />
                    <span className="text-xs">{completedChallenges.length} إنجازات</span>
                  </div>
                  <div className="rounded-lg bg-gray-800 p-2">
                    <Crown className="mx-auto mb-1 h-5 w-5 text-yellow-500" />
                    <span className="text-xs">المركز 42</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* التحدي اليومي */}
            <Card className="border-gray-800 bg-gray-900">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-base">
                  <Calendar className="mr-2 h-5 w-5 text-blue-500" />
                  التحدي اليومي
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <ScrollArea className="h-48 pr-4">
                  <div className="space-y-3">
                    {dailyQuests.map((quest) => (
                      <div
                        key={quest.id}
                        className={`rounded-lg border p-3 ${
                          quest.completed ? "border-green-500 bg-green-500/10" : "border-gray-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <Badge
                              className="mr-2"
                              variant={
                                quest.difficulty === "سهل"
                                  ? "outline"
                                  : quest.difficulty === "متوسط"
                                    ? "secondary"
                                    : "destructive"
                              }
                            >
                              {quest.difficulty}
                            </Badge>
                            <span className="font-medium">{quest.title}</span>
                          </div>
                          <Badge className="bg-yellow-500 text-black">{quest.points}</Badge>
                        </div>
                        <p className="mt-1 text-sm text-gray-400">{quest.description}</p>
                        {!quest.completed && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2 w-full"
                            onClick={() => completeDailyQuest(quest.id)}
                          >
                            أكمل التحدي
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Chat */}
            <Card className="border-gray-800 bg-gray-900">
              <CardContent className="p-4">
                <h3 className="mb-3 font-medium">دردشة المشجعين</h3>

                <div className="mb-3 h-60 overflow-y-auto rounded bg-gray-800 p-2">
                  {chatMessages.map((message, index) => (
                    <div key={index} className="mb-2">
                      <div className="flex items-start">
                        <span className="font-medium text-yellow-500">{message.user}:</span>
                        <span className="mr-2">{message.message}</span>
                      </div>
                      <div className="text-right text-xs text-gray-500">{message.time}</div>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="اكتب رسالة..."
                    className="border-gray-700 bg-gray-800"
                  />
                  <Button type="submit" className="bg-yellow-500 text-black hover:bg-yellow-600">
                    إرسال
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Attendees */}
            <Card className="border-gray-800 bg-gray-900">
              <CardContent className="p-4">
                <h3 className="mb-3 font-medium">المشجعون الحاضرون ({attendees.length + 1})</h3>

                <div className="h-40 overflow-y-auto">
                  <div className="mb-2 flex items-center justify-between rounded bg-yellow-500/20 p-2">
                    <div className="flex items-center">
                      <Users className="mr-2 h-4 w-4 text-yellow-500" />
                      <span>{user?.name || "أنت"}</span>
                    </div>
                    <Badge className="bg-yellow-500 text-black">
                      {selectedTicket?.section} - {selectedTicket?.row} - {selectedTicket?.seat}
                    </Badge>
                  </div>

                  {attendees.map((attendee) => (
                    <div
                      key={attendee.id}
                      className="mb-2 flex items-center justify-between rounded p-2 hover:bg-gray-800"
                    >
                      <div className="flex items-center">
                        <Users className="mr-2 h-4 w-4 text-gray-400" />
                        <span>{attendee.name}</span>
                      </div>
                      <Badge variant="outline">
                        {attendee.section} - {attendee.seat}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Share */}
            <Card className="border-gray-800 bg-gray-900">
              <CardContent className="p-4">
                <h3 className="mb-3 font-medium">مشاركة التجربة</h3>

                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={captureScreenshot}>
                    <Camera className="mr-2 h-4 w-4" />
                    التقاط صورة
                  </Button>

                  <Button variant="outline" size="sm" onClick={() => shareAchievement("الحضور الافتراضي")}>
                    <Share2 className="mr-2 h-4 w-4" />
                    مشاركة
                  </Button>

                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    تنزيل التذكرة
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Dialog for sharing achievements */}
      <Dialog>
        <DialogTrigger asChild>
          <Button className="fixed bottom-4 right-4 rounded-full bg-yellow-500 text-black hover:bg-yellow-600">
            <Sparkles className="mr-2 h-5 w-5" />
            مشاركة إنجازاتك
          </Button>
        </DialogTrigger>
        <DialogContent className="border-gray-800 bg-gray-900 text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle>مشاركة إنجازاتك</DialogTitle>
            <DialogDescription>شارك إنجازاتك مع أصدقائك على وسائل التواصل الاجتماعي</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="rounded-lg border border-gray-800 bg-black p-4 text-center">
              <Trophy className="mx-auto mb-2 h-12 w-12 text-yellow-500" />
              <h3 className="mb-1 text-lg font-bold">حصلت على 🥇 في تحدي الهتاف!</h3>
              <p className="mb-4 text-sm text-gray-400">شاركني التشجيع في المباراة القادمة!</p>
              <div className="flex justify-center space-x-2 space-x-reverse">
                <Badge className="bg-blue-500">تويتر</Badge>
                <Badge className="bg-green-500">واتساب</Badge>
                <Badge className="bg-purple-500">انستغرام</Badge>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" className="bg-yellow-500 text-black hover:bg-yellow-600">
              مشاركة الآن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stadium Chatbot */}
      <StadiumChatbot />
    </div>
  )
}

// Icon component for checkmark
function CheckIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  )
}
