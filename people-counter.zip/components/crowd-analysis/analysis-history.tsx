"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { getResultsBySession, type CrowdAnalysisResult } from "@/lib/crowd-analysis-service"
import { useCrowdAnalysis } from "../context/crowd-analysis-context"
import { format } from "date-fns"
import { ar } from "date-fns/locale"
import { Download, RefreshCw } from "lucide-react"

const AnalysisHistory = () => {
  const { currentSession, sessions, loadSessions } = useCrowdAnalysis()

  const [selectedSessionId, setSelectedSessionId] = useState<string>("")
  const [results, setResults] = useState<CrowdAnalysisResult[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [activeTab, setActiveTab] = useState<string>("table")

  // تحميل الجلسات عند تحميل المكون
  useEffect(() => {
    if (currentSession && !selectedSessionId) {
      setSelectedSessionId(currentSession.id)
    }
  }, [currentSession])

  // تحميل النتائج عند تغيير الجلسة المحددة
  useEffect(() => {
    if (selectedSessionId) {
      loadResultsForSession(selectedSessionId)
    }
  }, [selectedSessionId])

  // تحميل نتائج الجلسة المحددة
  const loadResultsForSession = async (sessionId: string) => {
    setIsLoading(true)
    try {
      const sessionResults = await getResultsBySession(sessionId)
      setResults(sessionResults)
    } catch (error) {
      console.error("Error loading results:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // تحديث البيانات
  const handleRefresh = async () => {
    await loadSessions()
    if (selectedSessionId) {
      await loadResultsForSession(selectedSessionId)
    }
  }

  // تنزيل البيانات كملف JSON
  const handleDownloadData = () => {
    if (results.length === 0) return

    const dataStr = JSON.stringify(results, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)

    const a = document.createElement("a")
    a.href = url
    a.download = `crowd-analysis-${selectedSessionId}.json`
    document.body.appendChild(a)
    a.click()

    setTimeout(() => {
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }, 100)
  }

  // تحويل النتائج إلى تنسيق مناسب للرسوم البيانية
  const getChartData = () => {
    return results
      .map((result) => ({
        time: format(new Date(result.created_at), "HH:mm", { locale: ar }),
        count: result.people_count,
        confidence: result.confidence_threshold,
        processingTime: result.processing_time || 0,
      }))
      .reverse()
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>سجل تحليل الحشود</CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={handleDownloadData} disabled={results.length === 0}>
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="w-full sm:w-64">
              <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر جلسة" />
                </SelectTrigger>
                <SelectContent>
                  {sessions.map((session) => (
                    <SelectItem key={session.id} value={session.id}>
                      {session.session_name || "جلسة بدون اسم"}
                      {session.location && ` - ${session.location}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-muted-foreground">
              {results.length > 0 ? <span>عدد النتائج: {results.length}</span> : <span>لا توجد نتائج</span>}
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="table">جدول</TabsTrigger>
              <TabsTrigger value="chart">رسم بياني</TabsTrigger>
            </TabsList>

            <TabsContent value="table" className="pt-4">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الوقت</TableHead>
                      <TableHead>عدد الأشخاص</TableHead>
                      <TableHead>عتبة الثقة</TableHead>
                      <TableHead>وقت المعالجة (مللي ثانية)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center">
                          جاري التحميل...
                        </TableCell>
                      </TableRow>
                    ) : results.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center">
                          لا توجد نتائج
                        </TableCell>
                      </TableRow>
                    ) : (
                      results.map((result) => (
                        <TableRow key={result.id}>
                          <TableCell>
                            {format(new Date(result.created_at), "yyyy-MM-dd HH:mm:ss", { locale: ar })}
                          </TableCell>
                          <TableCell>{result.people_count}</TableCell>
                          <TableCell>{result.confidence_threshold.toFixed(2)}</TableCell>
                          <TableCell>{result.processing_time?.toFixed(2) || "-"}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="chart" className="pt-4">
              <div className="h-80">
                {results.length === 0 ? (
                  <div className="h-full flex items-center justify-center border rounded-md">
                    <p className="text-muted-foreground">لا توجد بيانات للعرض</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={getChartData()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="count" name="عدد الأشخاص" stroke="#8884d8" activeDot={{ r: 8 }} />
                      <Line type="monotone" dataKey="processingTime" name="وقت المعالجة" stroke="#82ca9d" />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  )
}

export default AnalysisHistory
