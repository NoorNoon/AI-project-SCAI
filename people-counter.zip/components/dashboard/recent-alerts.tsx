import type React from "react"
import { AlertCircle, ThermometerSun, Users, Volume2 } from "lucide-react"

const RecentAlerts: React.FC = () => {
  // بيانات تمثيلية للتنبيهات الأخيرة
  const alerts = [
    {
      id: 1,
      type: "crowd",
      message: "ازدحام متوسط في المنطقة الشرقية",
      time: "17:05",
      severity: "warning",
      icon: <Users className="h-4 w-4" />,
    },
    {
      id: 2,
      type: "temperature",
      message: "ارتفاع درجة الحرارة في المنطقة الجنوبية",
      time: "16:42",
      severity: "warning",
      icon: <ThermometerSun className="h-4 w-4" />,
    },
    {
      id: 3,
      type: "noise",
      message: "مستوى صوت مرتفع في المنطقة الشمالية",
      time: "16:15",
      severity: "info",
      icon: <Volume2 className="h-4 w-4" />,
    },
    {
      id: 4,
      type: "crowd",
      message: "ازدحام شديد عند المدخل الرئيسي",
      time: "15:30",
      severity: "error",
      icon: <AlertCircle className="h-4 w-4" />,
    },
  ]

  // تحديد لون التنبيه بناءً على مستوى الخطورة
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "error":
        return "text-red-500 bg-red-50 border-red-200"
      case "warning":
        return "text-amber-500 bg-amber-50 border-amber-200"
      case "info":
        return "text-blue-500 bg-blue-50 border-blue-200"
      default:
        return "text-gray-500 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="space-y-3">
      {alerts.map((alert) => (
        <div key={alert.id} className={`p-3 rounded-md border flex items-start ${getSeverityColor(alert.severity)}`}>
          <div className="mr-2 mt-0.5">{alert.icon}</div>
          <div className="flex-1">
            <div className="font-medium">{alert.message}</div>
            <div className="text-xs opacity-70">{alert.time}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

export default RecentAlerts
