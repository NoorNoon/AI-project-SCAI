"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getCurrentUser, type User } from "@/lib/auth-service"

interface AuthContextType {
  user: User | null
  isLoading: boolean
  error: string | null
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  error: null,
})

export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    const checkAuth = async () => {
      setIsLoading(true)
      try {
        const { user, error } = await getCurrentUser()

        if (error) {
          setError(error)
          setUser(null)
        } else {
          setUser(user)
          setError(null)
        }
      } catch (err) {
        console.error("Auth check error:", err)
        setUser(null)
        setError("حدث خطأ أثناء التحقق من المصادقة")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [router])

  return <AuthContext.Provider value={{ user, isLoading, error }}>{children}</AuthContext.Provider>
}
