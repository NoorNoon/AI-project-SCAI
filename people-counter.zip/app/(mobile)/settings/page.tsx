import SessionManagerMobile from "@/components/crowd-analysis/session-manager-mobile"
import { CrowdAnalysisProvider } from "@/components/context/crowd-analysis-context"

export default function SettingsPage() {
  return (
    <CrowdAnalysisProvider>
      <SessionManagerMobile />
    </CrowdAnalysisProvider>
  )
}
