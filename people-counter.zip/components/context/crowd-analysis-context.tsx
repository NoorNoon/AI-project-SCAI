"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Detection } from "../people-counter/yolo-model"
import {
  createSession,
  saveAnalysisResult,
  getAllSessions,
  getLatestResults,
  type CrowdAnalysisSession,
  type CrowdAnalysisResult,
} from "@/lib/crowd-analysis-service"

interface CrowdAnalysisContextType {
  peopleCount: number
  setPeopleCount: (count: number) => void
  detections: Detection[]
  setDetections: (detections: Detection[]) => void
  crowdDensity: string
  processingTime: number
  setProcessingTime: (time: number) => void
  isProcessing: boolean
  setIsProcessing: (isProcessing: boolean) => void
  lastUpdated: Date
  crowdHistory: Array<{ time: string; count: number }>
  addHistoryEntry: (count: number) => void
  alertLevel: "low" | "medium" | "high" | "critical"

  // إضافة وظائف قاعدة البيانات
  currentSession: CrowdAnalysisSession | null
  sessions: CrowdAnalysisSession[]
  latestResults: CrowdAnalysisResult[]
  createNewSession: (name: string, location?: string) => Promise<void>
  saveCurrentResult: (imageUrl?: string) => Promise<void>
  loadSessions: () => Promise<void>
  loadLatestResults: () => Promise<void>
  confidenceThreshold: number
  setConfidenceThreshold: (threshold: number) => void
}

const CrowdAnalysisContext = createContext<CrowdAnalysisContextType | undefined>(undefined)

export function useCrowdAnalysis() {
  const context = useContext(CrowdAnalysisContext)
  if (context === undefined) {
    throw new Error("useCrowdAnalysis must be used within a CrowdAnalysisProvider")
  }
  return context
}

interface CrowdAnalysisProviderProps {
  children: ReactNode
}

export function CrowdAnalysisProvider({ children }: CrowdAnalysisProviderProps) {
  const [peopleCount, setPeopleCount] = useState<number>(0)
  const [detections, setDetections] = useState<Detection[]>([])
  const [processingTime, setProcessingTime] = useState<number>(0)
  const [isProcessing, setIsProcessing] = useState<boolean>(false)
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [crowdHistory, setCrowdHistory] = useState<Array<{ time: string; count: number }>>([])
  const [alertLevel, setAlertLevel] = useState<"low" | "medium" | "high" | "critical">("low")
  const [confidenceThreshold, setConfidenceThreshold] = useState<number>(0.5)

  // إضافة حالة قاعدة البيانات
  const [currentSession, setCurrentSession] = useState<CrowdAnalysisSession | null>(null)
  const [sessions, setSessions] = useState<CrowdAnalysisSession[]>([])
  const [latestResults, setLatestResults] = useState<CrowdAnalysisResult[]>([])

  // تحديد كثافة الحشود بناءً على عدد الأشخاص
  const getCrowdDensity = (count: number): string => {
    if (count === 0) return "منخفضة جدًا"
    if (count <= 5) return "منخفضة"
    if (count <= 15) return "متوسطة"
    if (count <= 30) return "عالية"
    return "عالية جدًا"
  }

  // تحديث مستوى التنبيه بناءً على عدد الأشخاص
  useEffect(() => {
    if (peopleCount === 0) {
      setAlertLevel("low")
    } else if (peopleCount <= 5) {
      setAlertLevel("low")
    } else if (peopleCount <= 15) {
      setAlertLevel("medium")
    } else if (peopleCount <= 30) {
      setAlertLevel("high")
    } else {
      setAlertLevel("critical")
    }

    setLastUpdated(new Date())
  }, [peopleCount])

  // إضافة إدخال جديد إلى سجل الحشود
  const addHistoryEntry = (count: number) => {
    const now = new Date()
    const timeString = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

    setCrowdHistory((prev) => {
      // الاحتفاظ بآخر 24 إدخال فقط
      const newHistory = [...prev, { time: timeString, count }]
      if (newHistory.length > 24) {
        return newHistory.slice(newHistory.length - 24)
      }
      return newHistory
    })

    return timeString
  }

  // إنشاء جلسة جديدة
  const createNewSession = async (name: string, location?: string) => {
    const session = await createSession(name, location)
    if (session) {
      setCurrentSession(session)
      await loadSessions()
    }
  }

  // حفظ النتيجة الحالية
  const saveCurrentResult = async (imageUrl?: string) => {
    if (!currentSession || peopleCount === 0) return

    const result = await saveAnalysisResult(
      currentSession.id,
      peopleCount,
      confidenceThreshold,
      processingTime,
      detections,
      imageUrl,
    )

    if (result) {
      await loadLatestResults()
    }
  }

  // تحميل جميع الجلسات
  const loadSessions = async () => {
    const allSessions = await getAllSessions()
    setSessions(allSessions)

    // إذا لم تكن هناك جلسة حالية، استخدم أحدث جلسة
    if (!currentSession && allSessions.length > 0) {
      setCurrentSession(allSessions[0])
    }
  }

  // تحميل أحدث النتائج
  const loadLatestResults = async () => {
    const results = await getLatestResults(10)
    setLatestResults(results)
  }

  // تحميل البيانات عند بدء التشغيل
  useEffect(() => {
    loadSessions()
    loadLatestResults()
  }, [])

  const value = {
    peopleCount,
    setPeopleCount,
    detections,
    setDetections,
    crowdDensity: getCrowdDensity(peopleCount),
    processingTime,
    setProcessingTime,
    isProcessing,
    setIsProcessing,
    lastUpdated,
    crowdHistory,
    addHistoryEntry,
    alertLevel,

    // إضافة وظائف قاعدة البيانات
    currentSession,
    sessions,
    latestResults,
    createNewSession,
    saveCurrentResult,
    loadSessions,
    loadLatestResults,
    confidenceThreshold,
    setConfidenceThreshold,
  }

  return <CrowdAnalysisContext.Provider value={value}>{children}</CrowdAnalysisContext.Provider>
}
