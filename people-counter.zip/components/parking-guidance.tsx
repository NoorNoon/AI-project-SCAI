"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Car, MapPin, Navigation, Clock, RefreshCw } from "lucide-react"
import Link from "next/link"

export function ParkingGuidance() {
  const [parkingLots, setParkingLots] = useState([
    {
      id: "north",
      name: "موقف السيارات الشمالي",
      capacity: 500,
      available: 120,
      distance: 350,
      estimatedTime: 5,
      coordinates: { lat: 24.7136, lng: 46.6753 },
    },
    {
      id: "south",
      name: "موقف السيارات الجنوبي",
      capacity: 800,
      available: 320,
      distance: 450,
      estimatedTime: 7,
      coordinates: { lat: 24.71, lng: 46.6753 },
    },
    {
      id: "east",
      name: "موقف السيارات الشرقي",
      capacity: 300,
      available: 30,
      distance: 200,
      estimatedTime: 3,
      coordinates: { lat: 24.7136, lng: 46.68 },
    },
    {
      id: "west",
      name: "موقف السيارات الغربي",
      capacity: 400,
      available: 150,
      distance: 280,
      estimatedTime: 4,
      coordinates: { lat: 24.7136, lng: 46.67 },
    },
    {
      id: "vip",
      name: "موقف كبار الشخصيات",
      capacity: 100,
      available: 25,
      distance: 100,
      estimatedTime: 2,
      coordinates: { lat: 24.7136, lng: 46.6753 },
    },
  ])
  const [userLocation, setUserLocation] = useState({ lat: 24.715, lng: 46.678 })
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [selectedLot, setSelectedLot] = useState<string | null>(null)

  // Simulate real-time parking updates
  useEffect(() => {
    const interval = setInterval(() => {
      setParkingLots((prev) =>
        prev.map((lot) => {
          // Random change in available spots
          const change = Math.floor(Math.random() * 10) - 5 // -5 to +5
          const newAvailable = Math.max(0, Math.min(lot.capacity, lot.available + change))

          return {
            ...lot,
            available: newAvailable,
          }
        }),
      )
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  // Calculate distance from user to parking lot
  const calculateDistance = (userLoc: { lat: number; lng: number }, lotLoc: { lat: number; lng: number }) => {
    // Simple Euclidean distance for demonstration
    const latDiff = userLoc.lat - lotLoc.lat
    const lngDiff = userLoc.lng - lotLoc.lng
    return Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111000 // Rough conversion to meters
  }

  // Update distances based on user location
  useEffect(() => {
    setParkingLots((prev) =>
      prev.map((lot) => {
        const distance = Math.round(calculateDistance(userLocation, lot.coordinates))
        const estimatedTime = Math.round(distance / 80) // Assuming 80 meters per minute walking speed

        return {
          ...lot,
          distance,
          estimatedTime,
        }
      }),
    )
  }, [userLocation])

  // Simulate user movement
  useEffect(() => {
    const interval = setInterval(() => {
      setUserLocation((prev) => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.0001,
        lng: prev.lng + (Math.random() - 0.5) * 0.0001,
      }))
    }, 15000)

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = () => {
    setIsRefreshing(true)

    // Simulate data refresh
    setTimeout(() => {
      setParkingLots((prev) =>
        prev.map((lot) => {
          const change = Math.floor(Math.random() * 20) - 10 // -10 to +10
          const newAvailable = Math.max(0, Math.min(lot.capacity, lot.available + change))

          return {
            ...lot,
            available: newAvailable,
          }
        }),
      )

      setIsRefreshing(false)
    }, 1500)
  }

  const getAvailabilityColor = (lot: (typeof parkingLots)[0]) => {
    const percentage = (lot.available / lot.capacity) * 100
    if (percentage < 10) return "bg-red-500"
    if (percentage < 30) return "bg-yellow-500 text-black"
    return "bg-green-500"
  }

  const getAvailabilityText = (lot: (typeof parkingLots)[0]) => {
    const percentage = (lot.available / lot.capacity) * 100
    if (percentage < 10) return "ممتلئ تقريبًا"
    if (percentage < 30) return "متوفر محدود"
    return "متوفر"
  }

  const handleSelectLot = (id: string) => {
    setSelectedLot(id === selectedLot ? null : id)
  }

  return (
    <Card className="border-gray-800 bg-gray-900">
      <CardContent className="p-4">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold">توجيه مواقف السيارات</h3>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            {isRefreshing ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </Button>
        </div>

        <div className="mb-4 rounded-lg bg-gray-800 p-3">
          <div className="flex items-center">
            <MapPin className="mr-2 h-5 w-5 text-blue-500" />
            <div>
              <h4 className="font-medium">موقعك الحالي</h4>
              <p className="text-sm text-gray-400">
                {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {parkingLots.map((lot) => (
            <div
              key={lot.id}
              className={`cursor-pointer rounded-lg border p-3 transition-colors ${
                selectedLot === lot.id
                  ? "border-yellow-500 bg-yellow-500/10"
                  : "border-gray-800 bg-gray-800 hover:border-gray-700"
              }`}
              onClick={() => handleSelectLot(lot.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Car className="mr-2 h-5 w-5 text-gray-400" />
                  <div>
                    <h4 className="font-medium">{lot.name}</h4>
                    <div className="flex items-center text-sm text-gray-400">
                      <Navigation className="mr-1 h-3 w-3" />
                      <span>{lot.distance}م</span>
                      <Clock className="mr-1 ml-2 h-3 w-3" />
                      <span>{lot.estimatedTime} دقائق</span>
                    </div>
                  </div>
                </div>
                <Badge className={getAvailabilityColor(lot)}>{getAvailabilityText(lot)}</Badge>
              </div>

              <div className="mt-2">
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span>
                    المتاح: {lot.available} من {lot.capacity}
                  </span>
                  <span>{Math.round((lot.available / lot.capacity) * 100)}%</span>
                </div>
                <Progress value={(lot.available / lot.capacity) * 100} className="h-1 bg-gray-700">
                  <div
                    className={`h-full ${getAvailabilityColor(lot).replace("text-black", "")}`}
                    style={{ width: `${(lot.available / lot.capacity) * 100}%` }}
                  />
                </Progress>
              </div>

              {selectedLot === lot.id && (
                <div className="mt-3 flex justify-end">
                  <Link
                    href={`https://maps.google.com/?q=${lot.coordinates.lat},${lot.coordinates.lng}`}
                    target="_blank"
                  >
                    <Button size="sm" className="bg-yellow-500 text-black hover:bg-yellow-600">
                      <Navigation className="mr-1 h-4 w-4" />
                      توجيه
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-4 text-center text-xs text-gray-400">يتم تحديث بيانات مواقف السيارات كل 10 دقائق</div>
      </CardContent>
    </Card>
  )
}
