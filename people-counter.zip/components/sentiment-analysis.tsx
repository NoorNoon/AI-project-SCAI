"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Smile, Frown, Meh, Volume2, VolumeX, AlertTriangle, Share2, Award, BarChart2, Settings } from "lucide-react"
import * as tf from "@tensorflow/tfjs"

export function SentimentAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [sentiment, setSentiment] = useState<"positive" | "neutral" | "negative">("neutral")
  const [sentimentScore, setSentimentScore] = useState(50)
  const [audioAnalysisActive, setAudioAnalysisActive] = useState(false)
  const [detectedChants, setDetectedChants] = useState<string[]>([])
  const [warningMessage, setWarningMessage] = useState("")
  const [crowdMood, setCrowdMood] = useState("متحمس")
  const [motivationalMessage, setMotivationalMessage] = useState("استمتع بالمباراة!")
  const [improvedChants, setImprovedChants] = useState<{ original: string; improved: string }[]>([])
  const [chantRatings, setChantRatings] = useState<{ chant: string; rating: number; shares: number }[]>([])
  const [userPoints, setUserPoints] = useState(0)
  const [isRecording, setIsRecording] = useState(false)
  const [transcribedText, setTranscribedText] = useState("")
  const [dialectMode, setDialectMode] = useState<"فصحى" | "عامية">("عامية")
  const [popularChants, setPopularChants] = useState<{ text: string; count: number }[]>([])
  const [showStats, setShowStats] = useState(false)
  const [aiChantAnalysis, setAiChantAnalysis] = useState<{
    sentiment: "إيجابي" | "محايد" | "سلبي"
    score: number
    suggestions: string[]
    keywords: string[]
  }>({ sentiment: "محايد", score: 50, suggestions: [], keywords: [] })
  const [suggestedChant, setSuggestedChant] = useState<string | null>(null)
  const [showChantSuggestion, setShowChantSuggestion] = useState(false)
  const [chatMessages, setChatMessages] = useState<{ user: string; message: string; time: string }[]>([])
  const [activeChallenges, setActiveChallenges] = useState<any[]>([])
  const [userLevel, setUserLevel] = useState(1)
  const [levelProgress, setLevelProgress] = useState(0)
  const [user, setUser] = useState<{ name: string } | null>(null)

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const [model, setModel] = useState<tf.LayersModel | null>(null)
  const [nlpModel, setNlpModel] = useState<tf.LayersModel | null>(null)
  const [loadingModel, setLoadingModel] = useState(true)

  // Simulated chants and their sentiment scores
  const chants = [
    { text: "يا هلال", sentiment: "positive", intensity: 0.8 },
    { text: "فوز فوز", sentiment: "positive", intensity: 0.9 },
    { text: "الله الله يا نصر", sentiment: "positive", intensity: 0.85 },
    { text: "لا لا لا", sentiment: "negative", intensity: 0.7 },
    { text: "الحكم ظالم", sentiment: "negative", intensity: 0.75 },
    { text: "فريقنا فريقنا", sentiment: "positive", intensity: 0.95 },
  ]

  // Motivational messages based on sentiment
  const motivationalMessages = {
    positive: ["أداء رائع من الجماهير!", "استمروا في التشجيع!", "صوتكم يصنع الفارق!", "الحماس يملأ الملعب!"],
    neutral: ["استمتع بالمباراة!", "شجع فريقك المفضل!", "كن جزءًا من الأجواء!", "المباراة أجمل مع حماسك!"],
    negative: ["Calm Down", "تذكر أن الرياضة للمتعة", "دعنا نحافظ على الروح الرياضية", "شجع بإيجابية"],
  }

  // Improved chant suggestions
  const chantImprovements = {
    "لا لا لا": "نعم نعم نعم للروح الرياضية",
    "الحكم ظالم": "نحترم قرارات الحكم ونركز على اللعب",
    "فريق ضعيف": "فريق يحتاج للدعم والتشجيع",
    "خسارة مستحقة": "فرصة للتعلم والتحسن في المباريات القادمة",
    "لاعب سيء": "لاعب يحتاج للدعم والتشجيع من الجماهير",
  }

  const positiveChants = ["يا هلال", "فوز فوز", "الله الله يا نصر", "فريقنا فريقنا"]

  const chantSuggestions = {
    "الحكم ظالم": "نحترم قرارات الحكم ونركز على اللعب",
    "فريق ضعيف": "فريق يحتاج للدعم والتشجيع",
    "خسارة مستحقة": "فرصة للتعلم والتحسن في المباريات القادمة",
    "لاعب سيء": "لاعب يحتاج للدعم والتشجيع من الجماهير",
  }

  // Load TensorFlow models
  useEffect(() => {
    async function loadModels() {
      try {
        setLoadingModel(true)
        await tf.ready()

        // Create a simple sentiment analysis model
        const sentimentModel = tf.sequential()
        sentimentModel.add(tf.layers.dense({ units: 10, inputShape: [5], activation: "relu" }))
        sentimentModel.add(tf.layers.dense({ units: 3, activation: "softmax" }))
        sentimentModel.compile({ optimizer: "adam", loss: "categoricalCrossentropy", metrics: ["accuracy"] })

        // Simulate training
        const xs = tf.randomNormal([100, 5])
        const ys = tf.oneHot(tf.randomUniform([100], 0, 3, "int32"), 3)
        await sentimentModel.fit(xs, ys, { epochs: 5, verbose: 0 })

        // Create NLP model for text analysis
        const nlpModel = tf.sequential()
        nlpModel.add(tf.layers.dense({ units: 16, inputShape: [10], activation: "relu" }))
        nlpModel.add(tf.layers.dense({ units: 8, activation: "relu" }))
        nlpModel.add(tf.layers.dense({ units: 4, activation: "softmax" }))
        nlpModel.compile({ optimizer: "adam", loss: "categoricalCrossentropy", metrics: ["accuracy"] })

        // Simulate training NLP model
        const nlpXs = tf.randomNormal([100, 10])
        const nlpYs = tf.oneHot(tf.randomUniform([100], 0, 4, "int32"), 4)
        await nlpModel.fit(nlpXs, nlpYs, { epochs: 5, verbose: 0 })

        setModel(sentimentModel)
        setNlpModel(nlpModel)
        setLoadingModel(false)

        // Initialize popular chants
        setPopularChants([
          { text: "يا هلال", count: 245 },
          { text: "فوز فوز", count: 189 },
          { text: "الله الله يا نصر", count: 167 },
          { text: "فريقنا فريقنا", count: 132 },
        ])

        // Initialize chant ratings
        setChantRatings([
          { chant: "يا هلال", rating: 4.8, shares: 78 },
          { chant: "فوز فوز", rating: 4.5, shares: 62 },
          { chant: "الله الله يا نصر", rating: 4.7, shares: 55 },
        ])

        // Clean up tensors
        xs.dispose()
        ys.dispose()
        nlpXs.dispose()
        nlpYs.dispose()
      } catch (error) {
        console.error("Error loading sentiment analysis model:", error)
        setLoadingModel(false)
      }
    }

    loadModels()

    return () => {
      if (model) {
        model.dispose()
      }
      if (nlpModel) {
        nlpModel.dispose()
      }
    }
  }, [])

  // Initialize audio analysis with speech-to-text simulation
  useEffect(() => {
    if (audioAnalysisActive && !audioContextRef.current) {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
        const analyser = audioContext.createAnalyser()
        analyser.fftSize = 2048

        // Simulate microphone input
        const oscillator = audioContext.createOscillator()
        oscillator.type = "sine"
        oscillator.frequency.setValueAtTime(440, audioContext.currentTime)
        oscillator.connect(analyser)
        oscillator.start()

        audioContextRef.current = audioContext
        analyserRef.current = analyser

        // Simulate speech-to-text and chant detection
        const chantDetectionInterval = setInterval(() => {
          if (Math.random() > 0.7) {
            const randomChant = chants[Math.floor(Math.random() * chants.length)]
            setDetectedChants((prev) => [randomChant.text, ...prev].slice(0, 3))

            // Simulate speech-to-text transcription
            setTranscribedText(randomChant.text)

            // Check if chant needs improvement
            if (
              randomChant.sentiment === "negative" &&
              chantImprovements[randomChant.text as keyof typeof chantImprovements]
            ) {
              const improved = chantImprovements[randomChant.text as keyof typeof chantImprovements]
              setImprovedChants((prev) => [{ original: randomChant.text, improved }, ...prev].slice(0, 2))
            }

            // Update sentiment based on detected chant
            if (randomChant.sentiment === "positive") {
              setSentiment("positive")
              setSentimentScore(Math.min(100, sentimentScore + randomChant.intensity * 10))
              setCrowdMood("متحمس")
              setWarningMessage("")

              // Add points for positive chants
              setUserPoints((prev) => prev + Math.floor(randomChant.intensity * 5))
            } else if (randomChant.sentiment === "negative") {
              setSentiment("negative")
              setSentimentScore(Math.max(0, sentimentScore - randomChant.intensity * 10))
              setCrowdMood("متوتر")

              // Show warning message for negative chants
              if (Math.random() > 0.5) {
                setWarningMessage("Calm Down")
                setTimeout(() => setWarningMessage(""), 3000)
              }
            }

            // Update motivational message
            const messages = motivationalMessages[sentiment]
            setMotivationalMessage(messages[Math.floor(Math.random() * messages.length)])

            // Update chant popularity
            if (Math.random() > 0.8) {
              setPopularChants((prev) => {
                const existingIndex = prev.findIndex((item) => item.text === randomChant.text)
                if (existingIndex >= 0) {
                  const updated = [...prev]
                  updated[existingIndex] = {
                    ...updated[existingIndex],
                    count: updated[existingIndex].count + Math.floor(Math.random() * 5) + 1,
                  }
                  return updated.sort((a, b) => b.count - a.count)
                } else {
                  return [...prev, { text: randomChant.text, count: Math.floor(Math.random() * 20) + 1 }]
                    .sort((a, b) => b.count - a.count)
                    .slice(0, 5)
                }
              })
            }
          }
        }, 3000)

        return () => {
          clearInterval(chantDetectionInterval)
          if (audioContextRef.current) {
            oscillator.stop()
            audioContextRef.current.close()
            audioContextRef.current = null
            analyserRef.current = null
          }
        }
      } catch (error) {
        console.error("Error initializing audio analysis:", error)
        setAudioAnalysisActive(false)
      }
    }
  }, [audioAnalysisActive, sentiment, sentimentScore])

  // Simulate crowd sentiment analysis
  useEffect(() => {
    if (isAnalyzing) {
      const interval = setInterval(() => {
        if (!canvasRef.current) return

        const ctx = canvasRef.current.getContext("2d")
        if (!ctx) return

        // Draw a simulated crowd scene
        ctx.fillStyle = "#333"
        ctx.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height)

        // Draw random dots to simulate people with different colors based on sentiment
        const numPeople = 200
        let positiveCount = 0
        let negativeCount = 0
        let neutralCount = 0

        for (let i = 0; i < numPeople; i++) {
          const x = Math.random() * canvasRef.current.width
          const y = Math.random() * canvasRef.current.height
          const size = Math.random() * 3 + 1

          // Randomly assign sentiment to each "person"
          const personSentiment = Math.random()

          if (personSentiment > 0.7) {
            ctx.fillStyle = "rgba(0, 255, 0, 0.7)" // Green for positive
            positiveCount++
          } else if (personSentiment < 0.3) {
            ctx.fillStyle = "rgba(255, 0, 0, 0.7)" // Red for negative
            negativeCount++
          } else {
            ctx.fillStyle = "rgba(255, 255, 0, 0.7)" // Yellow for neutral
            neutralCount++
          }

          ctx.beginPath()
          ctx.arc(x, y, size, 0, Math.PI * 2)
          ctx.fill()
        }

        // Update overall sentiment based on the counts
        if (positiveCount > negativeCount && positiveCount > neutralCount) {
          setSentiment("positive")
          setSentimentScore(Math.min(100, 50 + (positiveCount / numPeople) * 100))
          setCrowdMood("متحمس")
        } else if (negativeCount > positiveCount && negativeCount > neutralCount) {
          setSentiment("negative")
          setSentimentScore(Math.max(0, 50 - (negativeCount / numPeople) * 100))
          setCrowdMood("متوتر")
        } else {
          setSentiment("neutral")
          setSentimentScore(50)
          setCrowdMood("هادئ")
        }

        // Update motivational message
        if (Math.random() > 0.8) {
          const messages = motivationalMessages[sentiment]
          setMotivationalMessage(messages[Math.floor(Math.random() * messages.length)])
        }

        // Simulate AI analysis with the model
        if (model && !loadingModel && Math.random() > 0.9) {
          try {
            // Create a random input tensor for demonstration
            const input = tf.tensor2d([
              [
                positiveCount / numPeople,
                negativeCount / numPeople,
                neutralCount / numPeople,
                Math.random(), // Simulated noise level
                Math.random(), // Simulated movement level
              ],
            ])

            // Get prediction
            const prediction = model.predict(input) as tf.Tensor
            const sentimentPrediction = prediction.argMax(-1).dataSync()[0]

            // Map prediction to sentiment
            if (sentimentPrediction === 0) {
              setSentiment("negative")
              setSentimentScore(Math.max(0, sentimentScore - 5))
            } else if (sentimentPrediction === 2) {
              setSentiment("positive")
              setSentimentScore(Math.min(100, sentimentScore + 5))
            } else {
              setSentiment("neutral")
              setSentimentScore(50)
            }

            // Clean up tensors
            input.dispose()
            prediction.dispose()
          } catch (error) {
            console.error("Error during sentiment prediction:", error)
          }
        }
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [isAnalyzing, model, loadingModel, sentimentScore])

  const toggleSentimentAnalysis = () => {
    setIsAnalyzing(!isAnalyzing)
  }

  const toggleAudioAnalysis = () => {
    setAudioAnalysisActive(!audioAnalysisActive)
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)

    // Simulate recording and transcription
    if (!isRecording) {
      // إنشاء كائن التعرف على الكلام إذا كان مدعوماً
      if (typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window)) {
        const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
        const recognition = new SpeechRecognition()
        recognition.lang = "ar-SA"
        recognition.continuous = false
        recognition.interimResults = false

        recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript
          setTranscribedText(transcript)

          // تحليل الهتاف باستخدام الذكاء الاصطناعي
          const analysis = analyzeChantWithAI(transcript)
          setAiChantAnalysis(analysis)

          // التحقق مما إذا كان الهتاف يحتاج إلى تحسين
          const negativeChants = Object.keys(chantSuggestions)
          if (negativeChants.some((chant) => transcript.includes(chant))) {
            const matchedChant = negativeChants.find((chant) => transcript.includes(chant))
            if (matchedChant) {
              setSuggestedChant(chantSuggestions[matchedChant as keyof typeof chantSuggestions])
              setShowChantSuggestion(true)
            }
          } else {
            setShowChantSuggestion(false)
          }

          // إضافة إلى الدردشة
          setChatMessages((prev) => [
            ...prev,
            {
              user: user?.name || "أنت",
              message: transcript,
              time: "الآن",
            },
          ])

          // إضافة نقاط للتحدي إذا كان هتافاً إيجابياً
          if (analysis.sentiment === "إيجابي" || positiveChants.includes(transcript)) {
            // تحديث تحدي الهتاف
            const updatedChallenges = [...activeChallenges]
            const chantChallengeIndex = updatedChallenges.findIndex((c) => c.id === "challenge-3")

            if (chantChallengeIndex !== -1 && !updatedChallenges[chantChallengeIndex].completed) {
              updatedChallenges[chantChallengeIndex].completed = true
              setActiveChallenges(updatedChallenges)

              // إضافة النقاط
              const points = updatedChallenges[chantChallengeIndex].points
              setUserPoints((prev) => prev + points)

              // تحديث المستوى
              calculateLevelProgress()
            }
          }

          setIsRecording(false)
        }

        recognition.onerror = (event) => {
          console.error("Speech recognition error", event.error)
          setIsRecording(false)
        }

        recognition.start()
      } else {
        // Fallback for browsers that don't support SpeechRecognition
        setTimeout(() => {
          // اختيار هتاف عشوائي أو استخدام هتاف المستخدم
          const negativeChants = Object.keys(chantSuggestions)
          const allChants = [...negativeChants, ...positiveChants]
          const randomChant = allChants[Math.floor(Math.random() * allChants.length)]

          setTranscribedText(randomChant)
          setIsRecording(false)

          // Add to chat
          setChatMessages((prev) => [
            ...prev,
            {
              user: user?.name || "أنت",
              message: randomChant,
              time: "الآن",
            },
          ])

          // تحليل الهتاف باستخدام الذكاء الاصطناعي
          const analysis = analyzeChantWithAI(randomChant)
          setAiChantAnalysis(analysis)

          // Check if chant needs improvement
          if (negativeChants.includes(randomChant)) {
            setSuggestedChant(chantSuggestions[randomChant as keyof typeof chantSuggestions])
            setShowChantSuggestion(true)
          } else {
            setShowChantSuggestion(false)
          }

          // إضافة نقاط للتحدي إذا كان هتافاً إيجابياً
          if (analysis.sentiment === "إيجابي" || positiveChants.includes(randomChant)) {
            // تحديث تحدي الهتاف
            const updatedChallenges = [...activeChallenges]
            const chantChallengeIndex = updatedChallenges.findIndex((c) => c.id === "challenge-3")

            if (chantChallengeIndex !== -1 && !updatedChallenges[chantChallengeIndex].completed) {
              updatedChallenges[chantChallengeIndex].completed = true
              setActiveChallenges(updatedChallenges)

              // إضافة النقاط
              const points = updatedChallenges[chantChallengeIndex].points
              setUserPoints((prev) => prev + points)

              // تحديث المستوى
              calculateLevelProgress()
            }
          }
        }, 2000)
      }
    }
  }

  const toggleDialect = () => {
    setDialectMode(dialectMode === "فصحى" ? "عامية" : "فصحى")
  }

  const shareChant = (chant: string) => {
    // Simulate sharing
    setChantRatings((prev) => {
      const existingIndex = prev.findIndex((item) => item.chant === chant)
      if (existingIndex >= 0) {
        const updated = [...prev]
        updated[existingIndex] = {
          ...updated[existingIndex],
          shares: updated[existingIndex].shares + 1,
        }
        return updated
      } else {
        return [...prev, { chant, rating: 4.0, shares: 1 }]
      }
    })

    // Add points for sharing
    setUserPoints((prev) => prev + 5)

    alert(`تم مشاركة الهتاف "${chant}" بنجاح!`)
  }

  const rateChant = (chant: string, rating: number) => {
    // Simulate rating
    setChantRatings((prev) => {
      const existingIndex = prev.findIndex((item) => item.chant === chant)
      if (existingIndex >= 0) {
        const updated = [...prev]
        updated[existingIndex] = {
          ...updated[existingIndex],
          rating: (updated[existingIndex].rating + rating) / 2,
        }
        return updated
      } else {
        return [...prev, { chant, rating, shares: 0 }]
      }
    })

    // Add points for rating
    setUserPoints((prev) => prev + 1)
  }

  const toggleStats = () => {
    setShowStats(!showStats)
  }

  const analyzeChantWithAI = (chantText: string) => {
    // محاكاة تحليل الذكاء الاصطناعي
    const negativeWords = ["ضعيف", "سيء", "خسارة", "ظالم", "فاشل", "غبي", "حكم ظالم", "لاعب سيء", "فريق ضعيف"]
    const positiveWords = ["رائع", "بطل", "فوز", "زعيم", "أبطال", "نجم", "ممتاز", "قوي", "عظيم", "ذهبي"]
    const neutralWords = ["يالله", "هيا", "تعال", "اسمع", "انظر"]

    // تحليل النص
    const hasNegativeWords = negativeWords.some((word) => chantText.toLowerCase().includes(word))
    const hasPositiveWords = positiveWords.some((word) => chantText.toLowerCase().includes(word))
    const hasNeutralWords = neutralWords.some((word) => chantText.toLowerCase().includes(word))

    let sentiment: "إيجابي" | "محايد" | "سلبي" = "محايد"
    let score = 50
    let suggestions: string[] = []
    let keywords: string[] = []

    // تحليل أكثر تفصيلاً للنص
    const negativeCount = negativeWords.filter((word) => chantText.toLowerCase().includes(word)).length
    const positiveCount = positiveWords.filter((word) => chantText.toLowerCase().includes(word)).length

    // حساب النتيجة بناءً على عدد الكلمات الإيجابية والسلبية
    if (negativeCount > positiveCount) {
      sentiment = "سلبي"
      score = Math.max(10, 50 - negativeCount * 10)
    } else if (positiveCount > negativeCount) {
      sentiment = "إيجابي"
      score = Math.min(100, 50 + positiveCount * 10)
    } else if (hasNeutralWords && !hasNegativeWords && !hasPositiveWords) {
      sentiment = "محايد"
      score = 50
    } else {
      // إذا لم يكن هناك كلمات معروفة، نحلل طول النص وما إذا كان يحتوي على علامات تعجب
      if (chantText.includes("!")) {
        sentiment = "إيجابي"
        score = 65
      }
    }

    if (sentiment === "سلبي") {
      // اقتراحات لتحسين الهتاف
      let improvedChant = chantText

      // استبدال الكلمات السلبية بكلمات إيجابية
      negativeWords.forEach((word, index) => {
        if (chantText.toLowerCase().includes(word)) {
          const positiveReplacement = positiveWords[index % positiveWords.length]
          improvedChant = improvedChant.replace(new RegExp(word, "gi"), positiveReplacement)
        }
      })

      suggestions = [
        improvedChant !== chantText ? improvedChant : "استخدم كلمات إيجابية لتشجيع الفريق",
        "ركز على دعم اللاعبين بدلاً من انتقادهم",
        "استخدم هتافات تحفيزية لرفع معنويات الفريق",
      ]

      // استخراج الكلمات السلبية
      keywords = negativeWords.filter((word) => chantText.toLowerCase().includes(word))
    } else if (sentiment === "إيجابي") {
      // تعزيز الهتاف الإيجابي
      suggestions = [
        "هتاف رائع! يمكنك مشاركته مع المشجعين الآخرين",
        "أضف المزيد من الحماس بإضافة اسم اللاعب المفضل",
        "استمر في هذا النوع من الهتافات الإيجابية!",
      ]

      // استخراج الكلمات الإيجابية
      keywords = positiveWords.filter((word) => chantText.toLowerCase().includes(word))
    } else {
      // هتاف محايد
      suggestions = [
        "أضف المزيد من الحماس والتشجيع",
        "اذكر اسم الفريق أو اللاعبين لجعل الهتاف أكثر تأثيراً",
        "استخدم كلمات مثل 'رائع' أو 'بطل' لتعزيز الهتاف",
      ]

      // استخراج الكلمات المحايدة
      keywords = neutralWords.filter((word) => chantText.toLowerCase().includes(word))
    }

    return {
      sentiment,
      score,
      suggestions,
      keywords,
    }
  }

  const calculateLevelProgress = () => {
    const pointsNeeded = userLevel * 100
    const progress = Math.min(100, (userPoints / pointsNeeded) * 100)
    setLevelProgress(progress)
  }

  return (
    <Card className="border-gray-800 bg-gray-900">
      <CardContent className="p-4">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold">تحليل مشاعر الجماهير</h3>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={toggleStats}>
              <BarChart2 className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {loadingModel ? (
          <div className="flex flex-col items-center justify-center py-4">
            <div className="mb-2 h-6 w-6 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
            <p className="text-sm text-gray-400">جاري تحميل نموذج تحليل المشاعر...</p>
          </div>
        ) : (
          <>
            <div className="mb-4 flex flex-wrap gap-2">
              <Button
                variant={isAnalyzing ? "destructive" : "default"}
                className={isAnalyzing ? "" : "bg-yellow-500 text-black hover:bg-yellow-600"}
                onClick={toggleSentimentAnalysis}
                size="sm"
              >
                {isAnalyzing ? "إيقاف تحليل المشاعر" : "تشغيل تحليل المشاعر"}
              </Button>

              <Button variant={audioAnalysisActive ? "destructive" : "outline"} onClick={toggleAudioAnalysis} size="sm">
                {audioAnalysisActive ? <VolumeX className="mr-1 h-4 w-4" /> : <Volume2 className="mr-1 h-4 w-4" />}
                {audioAnalysisActive ? "إيقاف تحليل الهتافات" : "تشغيل تحليل الهتافات"}
              </Button>

              <Button variant={dialectMode === "فصحى" ? "default" : "outline"} onClick={toggleDialect} size="sm">
                {dialectMode}
              </Button>
            </div>

            {/* Sentiment Visualization */}
            <div className="mb-4 rounded-lg bg-gray-800 p-2">
              <canvas ref={canvasRef} width={320} height={180} className="mx-auto rounded" />
            </div>

            {/* Warning Message */}
            {warningMessage && (
              <div className="mb-4 flex items-center justify-center rounded-lg bg-red-900/50 p-3 text-center text-lg font-bold text-white">
                <AlertTriangle className="mr-2 h-5 w-5" />
                {warningMessage}
              </div>
            )}

            {/* Motivational Message */}
            <div className="mb-4 rounded-lg bg-gray-800 p-3 text-center">
              <p className="text-lg font-medium text-yellow-500">{motivationalMessage}</p>
            </div>

            {/* Sentiment Meter */}
            <div className="mb-4">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-sm">مزاج الجماهير: {crowdMood}</span>
                <Badge
                  className={
                    sentiment === "positive"
                      ? "bg-green-500"
                      : sentiment === "negative"
                        ? "bg-red-500"
                        : "bg-yellow-500 text-black"
                  }
                >
                  {sentiment === "positive" ? "إيجابي" : sentiment === "negative" ? "سلبي" : "محايد"}
                </Badge>
              </div>
              <div className="relative h-2 overflow-hidden rounded-full bg-gray-700">
                <div
                  className={`absolute inset-0 h-full ${
                    sentiment === "positive"
                      ? "bg-green-500"
                      : sentiment === "negative"
                        ? "bg-red-500"
                        : "bg-yellow-500"
                  }`}
                  style={{ width: `${sentimentScore}%`, transition: "width 0.5s ease-in-out" }}
                />
              </div>
              <div className="mt-1 flex justify-between text-xs text-gray-400">
                <div className="flex items-center">
                  <Frown className="mr-1 h-3 w-3" />
                  <span>سلبي</span>
                </div>
                <div className="flex items-center">
                  <Meh className="mr-1 h-3 w-3" />
                  <span>محايد</span>
                </div>
                <div className="flex items-center">
                  <Smile className="mr-1 h-3 w-3" />
                  <span>إيجابي</span>
                </div>
              </div>
            </div>

            {/* Voice to Text */}
            <div className="mb-4 rounded-lg bg-gray-800 p-3">
              <div className="mb-2 flex items-center justify-between">
                <h4 className="font-medium">تسجيل هتاف جديد:</h4>
                <Button
                  variant={isRecording ? "destructive" : "outline"}
                  size="sm"
                  onClick={toggleRecording}
                  className={isRecording ? "animate-pulse" : ""}
                >
                  {isRecording ? "جاري التسجيل..." : "تسجيل صوتي"}
                </Button>
              </div>

              {transcribedText && (
                <div className="mt-2">
                  <div className="rounded bg-gray-700 p-2 text-sm">
                    <p className="mb-1 font-medium">النص المكتشف:</p>
                    <p className="text-yellow-400">{transcribedText}</p>

                    <div className="mt-2 flex justify-end gap-2">
                      <Button size="sm" variant="outline" onClick={() => shareChant(transcribedText)}>
                        <Share2 className="mr-1 h-3 w-3" /> مشاركة
                      </Button>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            className="text-yellow-400 hover:text-yellow-300"
                            onClick={() => rateChant(transcribedText, star)}
                          >
                            ★
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Improved Chants Suggestions */}
            {improvedChants.length > 0 && (
              <div className="mb-4 space-y-2">
                <h4 className="font-medium">اقتراحات لتحسين الهتافات:</h4>
                {improvedChants.map((item, index) => (
                  <div key={index} className="rounded bg-gray-800 p-2 text-sm">
                    <p className="text-red-400 line-through">{item.original}</p>
                    <p className="text-green-400">→ {item.improved}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Detected Chants */}
            {audioAnalysisActive && (
              <div className="mb-4 space-y-2">
                <h4 className="font-medium">الهتافات المكتشفة:</h4>
                {detectedChants.length > 0 ? (
                  <ul className="space-y-1">
                    {detectedChants.map((chant, index) => (
                      <li key={index} className="flex items-center justify-between rounded bg-gray-800 p-2 text-sm">
                        <div>
                          <Volume2 className="mr-1 inline-block h-3 w-3 text-gray-400" /> {chant}
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => shareChant(chant)}>
                          <Share2 className="h-3 w-3" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-gray-400">لم يتم اكتشاف هتافات بعد...</p>
                )}
              </div>
            )}

            {/* User Points and Rewards */}
            <div className="mb-4 rounded-lg bg-gray-800 p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Award className="mr-2 h-5 w-5 text-yellow-500" />
                  <span className="font-medium">نقاطك: </span>
                </div>
                <span className="text-lg font-bold text-yellow-500">{userPoints}</span>
              </div>
              {userPoints >= 50 && <p className="mt-1 text-xs text-green-400">يمكنك استبدال نقاطك بتذكرة مباراة!</p>}
            </div>

            {/* Stats and Analytics */}
            {showStats && (
              <div className="mb-4 space-y-3 rounded-lg bg-gray-800 p-3">
                <h4 className="font-medium">إحصائيات الهتافات:</h4>

                <div>
                  <h5 className="mb-1 text-sm font-medium text-gray-400">الهتافات الأكثر شعبية:</h5>
                  <ul className="space-y-1">
                    {popularChants.map((item, index) => (
                      <li key={index} className="flex items-center justify-between text-sm">
                        <span>{item.text}</span>
                        <Badge variant="outline">{item.count}</Badge>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h5 className="mb-1 text-sm font-medium text-gray-400">أعلى التقييمات:</h5>
                  <ul className="space-y-1">
                    {chantRatings
                      .sort((a, b) => b.rating - a.rating)
                      .slice(0, 3)
                      .map((item, index) => (
                        <li key={index} className="flex items-center justify-between text-sm">
                          <span>{item.chant}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-yellow-400">{item.rating.toFixed(1)} ★</span>
                            <span className="text-xs text-gray-400">({item.shares} مشاركة)</span>
                          </div>
                        </li>
                      ))}
                  </ul>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
