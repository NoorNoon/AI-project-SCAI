"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ChevronLeft, CreditCard, Mic, MicOff, Volume2, Users } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"

export default function VirtualBookingPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedMatch, setSelectedMatch] = useState("match1")
  const [selectedSection, setSelectedSection] = useState("")
  const [selectedRow, setSelectedRow] = useState("")
  const [selectedSeat, setSelectedSeat] = useState("")
  const [ticketType, setTicketType] = useState("standard")
  const [isBooking, setIsBooking] = useState(false)
  const [step, setStep] = useState(1)
  const [viewMode, setViewMode] = useState<"2d" | "3d">("2d")
  const [zoomLevel, setZoomLevel] = useState(1)
  const [selectedSeats, setSelectedSeats] = useState<Array<{ section: string; row: string; seat: string }>>([])
  const [hoveredSeat, setHoveredSeat] = useState<{ section: string; row: string; seat: string } | null>(null)
  const [isRecording, setIsRecording] = useState(false)
  const [transcribedText, setTranscribedText] = useState("")
  const [showChantSuggestion, setShowChantSuggestion] = useState(false)
  const [suggestedChant, setSuggestedChant] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Simulated data
  const matches = [
    {
      id: "match1",
      homeTeam: "الهلال",
      awayTeam: "النصر",
      date: "الجمعة، 15 نوفمبر",
      time: "9:00 م",
      stadium: "استاد الملك فهد الدولي",
      price: 150,
      virtualPrice: 50,
    },
    {
      id: "match2",
      homeTeam: "الاتحاد",
      awayTeam: "الأهلي",
      date: "السبت، 16 نوفمبر",
      time: "8:30 م",
      stadium: "استاد الجوهرة",
      price: 120,
      virtualPrice: 40,
    },
    {
      id: "match3",
      homeTeam: "الاتفاق",
      awayTeam: "التعاون",
      date: "الأحد، 17 نوفمبر",
      time: "7:00 م",
      stadium: "استاد الأمير محمد بن فهد",
      price: 100,
      virtualPrice: 30,
    },
  ]

  const sections = ["A", "B", "C", "D", "VIP"]
  const rows = Array.from({ length: 20 }, (_, i) => (i + 1).toString())
  const seats = Array.from({ length: 30 }, (_, i) => (i + 1).toString())

  // AI-based crowd density simulation
  const [crowdDensity, setCrowdDensity] = useState<Record<string, number>>({
    A: 85,
    B: 65,
    C: 45,
    D: 75,
    VIP: 30,
  })

  // Chant suggestions
  const chantSuggestions = {
    "الحكم ظالم": "نحترم قرارات الحكم ونركز على اللعب",
    "فريق ضعيف": "فريق يحتاج للدعم والتشجيع",
    "خسارة مستحقة": "فرصة للتعلم والتحسن في المباريات القادمة",
    "لاعب سيء": "لاعب يحتاج للدعم والتشجيع من الجماهير",
  }

  // Positive chants
  const positiveChants = ["يا هلال", "فوز فوز", "الله الله يا نصر", "فريقنا فريقنا", "نحن معك يا بطل", "لا يهزنا أحد"]

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))
    setLoading(false)

    // Simulate AI crowd analysis
    const interval = setInterval(() => {
      setCrowdDensity((prev) => {
        const updated = { ...prev }
        const keys = Object.keys(updated)
        const randomKey = keys[Math.floor(Math.random() * keys.length)]
        const change = Math.floor(Math.random() * 10) - 5 // -5 to +5
        updated[randomKey] = Math.max(10, Math.min(95, updated[randomKey] + change))
        return updated
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [router])

  // Separate useEffect for canvas drawing
  useEffect(() => {
    if (canvasRef.current) {
      drawStadium()
    }
  }, [viewMode, zoomLevel, selectedSeats, hoveredSeat, selectedSection])

  const drawStadium = () => {
    if (!canvasRef.current) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set scale based on zoom level
    ctx.save()
    ctx.scale(zoomLevel, zoomLevel)

    if (viewMode === "2d") {
      // Draw 2D stadium
      draw2DStadium(ctx, canvas.width / zoomLevel, canvas.height / zoomLevel)
    } else {
      // Draw 3D stadium
      draw3DStadium(ctx, canvas.width / zoomLevel, canvas.height / zoomLevel)
    }

    ctx.restore()
  }

  const draw2DStadium = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw field
    ctx.fillStyle = "#4CAF50"
    ctx.fillRect(width * 0.25, height * 0.3, width * 0.5, height * 0.4)

    // Draw field lines
    ctx.strokeStyle = "white"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.25, height * 0.3, width * 0.5, height * 0.4)

    // Draw center circle
    ctx.beginPath()
    ctx.arc(width * 0.5, height * 0.5, 40, 0, Math.PI * 2)
    ctx.stroke()

    // Draw center line
    ctx.beginPath()
    ctx.moveTo(width * 0.5, height * 0.3)
    ctx.lineTo(width * 0.5, height * 0.7)
    ctx.stroke()

    // Draw sections
    const sectionColors = {
      A: "#FF5722",
      B: "#2196F3",
      C: "#9C27B0",
      D: "#FFEB3B",
      VIP: "#E91E63",
    }

    // Section A (Top)
    drawSection(ctx, width * 0.25, height * 0.1, width * 0.5, height * 0.15, "A", sectionColors.A)

    // Section B (Right)
    drawSection(ctx, width * 0.8, height * 0.3, width * 0.15, height * 0.4, "B", sectionColors.B)

    // Section C (Bottom)
    drawSection(ctx, width * 0.25, height * 0.75, width * 0.5, height * 0.15, "C", sectionColors.C)

    // Section D (Left)
    drawSection(ctx, width * 0.05, height * 0.3, width * 0.15, height * 0.4, "D", sectionColors.D)

    // VIP Section (Top-Right corner)
    drawSection(ctx, width * 0.8, height * 0.1, width * 0.15, height * 0.15, "VIP", sectionColors.VIP)

    // Draw seats in selected section
    if (selectedSection) {
      drawSeatsForSection(ctx, selectedSection, width, height)
    }
  }

  const draw3DStadium = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Draw field (with perspective)
    ctx.fillStyle = "#4CAF50"
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.4)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.35, height * 0.6)
    ctx.closePath()
    ctx.fill()

    // Draw field lines
    ctx.strokeStyle = "white"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.4)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.35, height * 0.6)
    ctx.closePath()
    ctx.stroke()

    // Draw center circle (with perspective)
    ctx.beginPath()
    ctx.ellipse(width * 0.5, height * 0.5, 30, 15, 0, 0, Math.PI * 2)
    ctx.stroke()

    // Draw center line
    ctx.beginPath()
    ctx.moveTo(width * 0.5, height * 0.4)
    ctx.lineTo(width * 0.5, height * 0.6)
    ctx.stroke()

    // Draw stands with perspective
    const sectionColors = {
      A: "#FF5722",
      B: "#2196F3",
      C: "#9C27B0",
      D: "#FFEB3B",
      VIP: "#E91E63",
    }

    // Section A (Top)
    ctx.fillStyle = sectionColors.A
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.3)
    ctx.lineTo(width * 0.7, height * 0.3)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.lineTo(width * 0.3, height * 0.4)
    ctx.closePath()
    ctx.fill()
    ctx.strokeStyle = "#000"
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.font = "bold 12px Arial"
    ctx.fillText("A", width * 0.5, height * 0.35)

    // Section B (Right)
    ctx.fillStyle = sectionColors.B
    ctx.beginPath()
    ctx.moveTo(width * 0.7, height * 0.3)
    ctx.lineTo(width * 0.8, height * 0.35)
    ctx.lineTo(width * 0.75, height * 0.55)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.65, height * 0.4)
    ctx.lineTo(width * 0.7, height * 0.4)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("B", width * 0.72, height * 0.45)

    // Section C (Bottom)
    ctx.fillStyle = sectionColors.C
    ctx.beginPath()
    ctx.moveTo(width * 0.35, height * 0.6)
    ctx.lineTo(width * 0.65, height * 0.6)
    ctx.lineTo(width * 0.65, height * 0.7)
    ctx.lineTo(width * 0.35, height * 0.7)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("C", width * 0.5, height * 0.65)

    // Section D (Left)
    ctx.fillStyle = sectionColors.D
    ctx.beginPath()
    ctx.moveTo(width * 0.3, height * 0.3)
    ctx.lineTo(width * 0.2, height * 0.35)
    ctx.lineTo(width * 0.25, height * 0.55)
    ctx.lineTo(width * 0.35, height * 0.6)
    ctx.lineTo(width * 0.35, height * 0.4)
    ctx.lineTo(width * 0.3, height * 0.4)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("D", width * 0.28, height * 0.45)

    // VIP Section (Top-Right corner)
    ctx.fillStyle = sectionColors.VIP
    ctx.beginPath()
    ctx.moveTo(width * 0.7, height * 0.3)
    ctx.lineTo(width * 0.8, height * 0.35)
    ctx.lineTo(width * 0.9, height * 0.25)
    ctx.lineTo(width * 0.8, height * 0.2)
    ctx.closePath()
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = "#fff"
    ctx.fillText("VIP", width * 0.8, height * 0.28)

    // Draw seats in selected section if in 3D mode
    if (selectedSection) {
      draw3DSeatsForSection(ctx, selectedSection, width, height)
    }
  }

  const drawSection = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    section: string,
    color: string,
  ) => {
    // Draw section background
    ctx.fillStyle = color
    ctx.fillRect(x, y, width, height)

    // Draw section border
    ctx.strokeStyle = "#000"
    ctx.lineWidth = 2
    ctx.strokeRect(x, y, width, height)

    // Draw section label
    ctx.fillStyle = "#fff"
    ctx.font = "bold 14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(section, x + width / 2, y + height / 2)

    // Draw occupancy indicator
    const density = crowdDensity[section]
    const indicatorWidth = width * 0.8
    ctx.fillStyle = "#333"
    ctx.fillRect(x + width * 0.1, y + height * 0.8, indicatorWidth, height * 0.1)

    ctx.fillStyle = density > 80 ? "#FF0000" : density > 60 ? "#FFFF00" : "#00FF00"
    ctx.fillRect(x + width * 0.1, y + height * 0.8, indicatorWidth * (density / 100), height * 0.1)
  }

  const drawSeatsForSection = (
    ctx: CanvasRenderingContext2D,
    section: string,
    canvasWidth: number,
    canvasHeight: number,
  ) => {
    let sectionX = 0,
      sectionY = 0,
      sectionWidth = 0,
      sectionHeight = 0

    // Define section coordinates based on section ID
    switch (section) {
      case "A":
        sectionX = canvasWidth * 0.25
        sectionY = canvasHeight * 0.1
        sectionWidth = canvasWidth * 0.5
        sectionHeight = canvasHeight * 0.15
        break
      case "B":
        sectionX = canvasWidth * 0.8
        sectionY = canvasHeight * 0.3
        sectionWidth = canvasWidth * 0.15
        sectionHeight = canvasHeight * 0.4
        break
      case "C":
        sectionX = canvasWidth * 0.25
        sectionY = canvasHeight * 0.75
        sectionWidth = canvasWidth * 0.5
        sectionHeight = canvasHeight * 0.15
        break
      case "D":
        sectionX = canvasWidth * 0.05
        sectionY = canvasHeight * 0.3
        sectionWidth = canvasWidth * 0.15
        sectionHeight = canvasHeight * 0.4
        break
      case "VIP":
        sectionX = canvasWidth * 0.8
        sectionY = canvasHeight * 0.1
        sectionWidth = canvasWidth * 0.15
        sectionHeight = canvasHeight * 0.15
        break
    }

    // Draw seats grid
    const rowCount = 5
    const seatCount = 10
    const seatWidth = sectionWidth / (seatCount + 1)
    const seatHeight = sectionHeight / (rowCount + 1)

    for (let row = 1; row <= rowCount; row++) {
      for (let seat = 1; seat <= seatCount; seat++) {
        const seatX = sectionX + seat * seatWidth
        const seatY = sectionY + row * seatHeight

        // Check if seat is selected
        const isSelected = selectedSeats.some(
          (s) => s.section === section && s.row === row.toString() && s.seat === seat.toString(),
        )

        // Check if seat is hovered
        const isHovered =
          hoveredSeat &&
          hoveredSeat.section === section &&
          hoveredSeat.row === row.toString() &&
          hoveredSeat.seat === seat.toString()

        // Draw seat
        ctx.fillStyle = isSelected ? "#FF5722" : isHovered ? "#FFC107" : "#BBBBBB"
        ctx.beginPath()
        ctx.arc(seatX, seatY, seatWidth * 0.4, 0, Math.PI * 2)
        ctx.fill()

        // Draw seat border
        ctx.strokeStyle = "#000"
        ctx.lineWidth = 1
        ctx.stroke()

        // Add seat number for larger seats
        if (seatWidth > 15) {
          ctx.fillStyle = "#000"
          ctx.font = "8px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(`${row}-${seat}`, seatX, seatY)
        }
      }
    }
  }

  const draw3DSeatsForSection = (
    ctx: CanvasRenderingContext2D,
    section: string,
    canvasWidth: number,
    canvasHeight: number,
  ) => {
    // Define section coordinates based on section ID for 3D view
    let startX = 0,
      startY = 0,
      endX = 0,
      endY = 0,
      rows = 5,
      seatsPerRow = 10

    switch (section) {
      case "A":
        startX = canvasWidth * 0.35
        startY = canvasHeight * 0.32
        endX = canvasWidth * 0.65
        endY = canvasHeight * 0.38
        break
      case "B":
        startX = canvasWidth * 0.68
        startY = canvasHeight * 0.38
        endX = canvasWidth * 0.74
        endY = canvasHeight * 0.55
        rows = 8
        seatsPerRow = 5
        break
      case "C":
        startX = canvasWidth * 0.38
        startY = canvasHeight * 0.62
        endX = canvasWidth * 0.62
        endY = canvasHeight * 0.68
        break
      case "D":
        startX = canvasWidth * 0.26
        startY = canvasHeight * 0.38
        endX = canvasWidth * 0.32
        endY = canvasHeight * 0.55
        rows = 8
        seatsPerRow = 5
        break
      case "VIP":
        startX = canvasWidth * 0.75
        startY = canvasHeight * 0.25
        endX = canvasWidth * 0.85
        endY = canvasHeight * 0.32
        rows = 3
        seatsPerRow = 5
        break
    }

    // Calculate seat dimensions
    const width = (endX - startX) / seatsPerRow
    const height = (endY - startY) / rows

    // Draw seats with 3D effect
    for (let row = 0; row < rows; row++) {
      for (let seat = 0; seat < seatsPerRow; seat++) {
        const x = startX + seat * width
        const y = startY + row * height

        // Check if seat is selected
        const isSelected = selectedSeats.some(
          (s) => s.section === section && s.row === (row + 1).toString() && s.seat === (seat + 1).toString(),
        )

        // Check if seat is hovered
        const isHovered =
          hoveredSeat &&
          hoveredSeat.section === section &&
          hoveredSeat.row === (row + 1).toString() &&
          hoveredSeat.seat === (seat + 1).toString()

        // Draw 3D seat (cuboid)
        const depth = height * 0.3

        // Seat color
        ctx.fillStyle = isSelected ? "#FF5722" : isHovered ? "#FFC107" : "#BBBBBB"

        // Front face
        ctx.beginPath()
        ctx.rect(x, y, width * 0.8, height * 0.7)
        ctx.fill()
        ctx.stroke()

        // Top face
        ctx.beginPath()
        ctx.moveTo(x, y)
        ctx.lineTo(x + width * 0.2, y - depth)
        ctx.lineTo(x + width, y - depth)
        ctx.lineTo(x + width * 0.8, y)
        ctx.closePath()
        ctx.fill()
        ctx.stroke()

        // Right face
        ctx.beginPath()
        ctx.moveTo(x + width * 0.8, y)
        ctx.lineTo(x + width, y - depth)
        ctx.lineTo(x + width, y + height * 0.7 - depth)
        ctx.lineTo(x + width * 0.8, y + height * 0.7)
        ctx.closePath()
        ctx.fill()
        ctx.stroke()

        // Add seat number for larger seats
        if (width > 15) {
          ctx.fillStyle = "#000"
          ctx.font = "8px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(`${row + 1}-${seat + 1}`, x + width * 0.4, y + height * 0.35)
        }
      }
    }
  }

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !selectedSection) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = ((e.clientX - rect.left) * (canvas.width / rect.width)) / zoomLevel
    const y = ((e.clientY - rect.top) * (canvas.height / rect.height)) / zoomLevel

    // Determine which seat was clicked based on coordinates
    const seatInfo = getSeatFromCoordinates(x, y, selectedSection)

    if (seatInfo) {
      // Toggle seat selection
      const seatIndex = selectedSeats.findIndex(
        (s) => s.section === seatInfo.section && s.row === seatInfo.row && s.seat === seatInfo.seat,
      )

      if (seatIndex >= 0) {
        // Remove seat if already selected
        const newSelectedSeats = [...selectedSeats]
        newSelectedSeats.splice(seatIndex, 1)
        setSelectedSeats(newSelectedSeats)
      } else {
        // Add seat if not already selected
        setSelectedSeats([...selectedSeats, seatInfo])

        // Update form fields
        setSelectedRow(seatInfo.row)
        setSelectedSeat(seatInfo.seat)
      }

      // No need to call drawStadium() here as it will be triggered by the useEffect
    }
  }

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !selectedSection) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = ((e.clientX - rect.left) * (canvas.width / rect.width)) / zoomLevel
    const y = ((e.clientY - rect.top) * (canvas.height / rect.height)) / zoomLevel

    // Determine which seat is being hovered
    const seatInfo = getSeatFromCoordinates(x, y, selectedSection)

    // Only update state if the hovered seat has changed
    if (!hoveredSeat && seatInfo) {
      setHoveredSeat(seatInfo)
    } else if (hoveredSeat && !seatInfo) {
      setHoveredSeat(null)
    } else if (
      hoveredSeat &&
      seatInfo &&
      (hoveredSeat.section !== seatInfo.section ||
        hoveredSeat.row !== seatInfo.row ||
        hoveredSeat.seat !== seatInfo.seat)
    ) {
      setHoveredSeat(seatInfo)
    }

    // No need to call drawStadium() here as it will be triggered by the useEffect
  }

  const getSeatFromCoordinates = (x: number, y: number, section: string) => {
    const canvas = canvasRef.current
    if (!canvas) return null

    const canvasWidth = canvas.width / zoomLevel
    const canvasHeight = canvas.height / zoomLevel

    let sectionX = 0,
      sectionY = 0,
      sectionWidth = 0,
      sectionHeight = 0

    // Define section coordinates based on section ID and view mode
    if (viewMode === "2d") {
      switch (section) {
        case "A":
          sectionX = canvasWidth * 0.25
          sectionY = canvasHeight * 0.1
          sectionWidth = canvasWidth * 0.5
          sectionHeight = canvasHeight * 0.15
          break
        case "B":
          sectionX = canvasWidth * 0.8
          sectionY = canvasHeight * 0.3
          sectionWidth = canvasWidth * 0.15
          sectionHeight = canvasHeight * 0.4
          break
        case "C":
          sectionX = canvasWidth * 0.25
          sectionY = canvasHeight * 0.75
          sectionWidth = canvasWidth * 0.5
          sectionHeight = canvasHeight * 0.15
          break
        case "D":
          sectionX = canvasWidth * 0.05
          sectionY = canvasHeight * 0.3
          sectionWidth = canvasWidth * 0.15
          sectionHeight = canvasHeight * 0.4
          break
        case "VIP":
          sectionX = canvasWidth * 0.8
          sectionY = canvasHeight * 0.1
          sectionWidth = canvasWidth * 0.15
          sectionHeight = canvasHeight * 0.15
          break
      }

      // Check if coordinates are within section
      if (x < sectionX || x > sectionX + sectionWidth || y < sectionY || y > sectionY + sectionHeight) {
        return null
      }

      // Calculate row and seat
      const rowCount = 5
      const seatCount = 10
      const seatWidth = sectionWidth / (seatCount + 1)
      const seatHeight = sectionHeight / (rowCount + 1)

      // Find closest row and seat
      let closestRow = 0
      let closestSeat = 0
      let minDistance = Number.MAX_VALUE

      for (let row = 1; row <= rowCount; row++) {
        for (let seat = 1; seat <= seatCount; seat++) {
          const seatX = sectionX + seat * seatWidth
          const seatY = sectionY + row * seatHeight

          const distance = Math.sqrt(Math.pow(x - seatX, 2) + Math.pow(y - seatY, 2))

          if (distance < minDistance && distance < seatWidth * 0.5) {
            minDistance = distance
            closestRow = row
            closestSeat = seat
          }
        }
      }

      if (closestRow > 0 && closestSeat > 0) {
        return {
          section,
          row: closestRow.toString(),
          seat: closestSeat.toString(),
        }
      }
    } else {
      // 3D mode seat detection
      let startX = 0,
        startY = 0,
        endX = 0,
        endY = 0,
        rows = 5,
        seatsPerRow = 10

      switch (section) {
        case "A":
          startX = canvasWidth * 0.35
          startY = canvasHeight * 0.32
          endX = canvasWidth * 0.65
          endY = canvasHeight * 0.38
          break
        case "B":
          startX = canvasWidth * 0.68
          startY = canvasHeight * 0.38
          endX = canvasWidth * 0.74
          endY = canvasHeight * 0.55
          rows = 8
          seatsPerRow = 5
          break
        case "C":
          startX = canvasWidth * 0.38
          startY = canvasHeight * 0.62
          endX = canvasWidth * 0.62
          endY = canvasHeight * 0.68
          break
        case "D":
          startX = canvasWidth * 0.26
          startY = canvasHeight * 0.38
          endX = canvasWidth * 0.32
          endY = canvasHeight * 0.55
          rows = 8
          seatsPerRow = 5
          break
        case "VIP":
          startX = canvasWidth * 0.75
          startY = canvasHeight * 0.25
          endX = canvasWidth * 0.85
          endY = canvasHeight * 0.32
          rows = 3
          seatsPerRow = 5
          break
      }

      // Check if coordinates are within section
      if (x < startX || x > endX || y < startY - canvasHeight * 0.05 || y > endY) {
        return null
      }

      // Calculate width and height of each seat
      const width = (endX - startX) / seatsPerRow
      const height = (endY - startY) / rows

      // Calculate row and seat
      const row = Math.floor((y - startY) / height) + 1
      const seat = Math.floor((x - startX) / width) + 1

      if (row > 0 && row <= rows && seat > 0 && seat <= seatsPerRow) {
        return {
          section,
          row: row.toString(),
          seat: seat.toString(),
        }
      }
    }

    return null
  }

  const handleSectionChange = (value: string) => {
    setSelectedSection(value)
    setSelectedRow("")
    setSelectedSeat("")
    drawStadium()
  }

  const handleBookTicket = async () => {
    if (selectedSeats.length === 0) {
      alert("الرجاء اختيار مقعد واحد على الأقل")
      return
    }

    setIsBooking(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Get existing tickets or initialize empty array
      const existingTickets = JSON.parse(localStorage.getItem("tickets") || "[]")

      // Add new tickets
      const selectedMatchData = matches.find((match) => match.id === selectedMatch)

      const newTickets = selectedSeats.map((seat) => ({
        id: Date.now().toString() + Math.random().toString(36).substring(2, 8),
        matchId: selectedMatch,
        homeTeam: selectedMatchData?.homeTeam,
        awayTeam: selectedMatchData?.awayTeam,
        date: selectedMatchData?.date,
        time: selectedMatchData?.time,
        stadium: selectedMatchData?.stadium,
        section: seat.section,
        row: seat.row,
        seat: seat.seat,
        type: ticketType,
        price: ticketType === "vip" ? (selectedMatchData?.virtualPrice || 0) * 2 : selectedMatchData?.virtualPrice,
        purchaseDate: new Date().toLocaleDateString("ar-SA"),
        isVirtual: true,
      }))

      localStorage.setItem("tickets", JSON.stringify([...existingTickets, ...newTickets]))

      // Redirect to tickets page
      router.push("/dashboard/tickets/virtual-attendance")
    } catch (error) {
      console.error("Error booking ticket:", error)
    } finally {
      setIsBooking(false)
    }
  }

  const getTicketPrice = () => {
    const basePrice = matches.find((match) => match.id === selectedMatch)?.virtualPrice || 0
    return ticketType === "vip" ? basePrice * 2 : basePrice
  }

  const getTotalPrice = () => {
    return getTicketPrice() * selectedSeats.length
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)

    // Simulate recording and transcription
    if (!isRecording) {
      setTimeout(() => {
        // Randomly select a chant
        const negativeChants = Object.keys(chantSuggestions)
        const allChants = [...negativeChants, ...positiveChants]
        const randomChant = allChants[Math.floor(Math.random() * allChants.length)]

        setTranscribedText(randomChant)
        setIsRecording(false)

        // Check if chant needs improvement
        if (negativeChants.includes(randomChant)) {
          setSuggestedChant(chantSuggestions[randomChant as keyof typeof chantSuggestions])
          setShowChantSuggestion(true)
        } else {
          setShowChantSuggestion(false)
        }
      }, 2000)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black pb-20 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center">
          <Link href="/dashboard" className="ml-4">
            <Button variant="ghost" size="icon">
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">حجز تذكرة افتراضية</h1>
        </div>

        {/* Booking Steps */}
        <div className="mb-8">
          <div className="mb-2 flex justify-between">
            <span className={step >= 1 ? "text-yellow-500" : "text-gray-500"}>اختيار المباراة</span>
            <span className={step >= 2 ? "text-yellow-500" : "text-gray-500"}>اختيار المقعد</span>
            <span className={step >= 3 ? "text-yellow-500" : "text-gray-500"}>الدفع</span>
          </div>
          <Progress value={(step / 3) * 100} className="h-2 bg-gray-700">
            <div className="h-full bg-yellow-500" style={{ width: `${(step / 3) * 100}%` }} />
          </Progress>
        </div>

        {step === 1 && (
          <Card className="border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <h2 className="mb-4 text-xl font-semibold">اختر المباراة</h2>

              <div className="space-y-4">
                {matches.map((match) => (
                  <div
                    key={match.id}
                    className={`cursor-pointer rounded-lg border p-4 transition-colors ${
                      selectedMatch === match.id
                        ? "border-yellow-500 bg-yellow-500/10"
                        : "border-gray-700 bg-gray-800 hover:border-gray-600"
                    }`}
                    onClick={() => setSelectedMatch(match.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">
                          {match.homeTeam} ضد {match.awayTeam}
                        </div>
                        <div className="mt-1 text-sm text-gray-400">
                          {match.date} - {match.time}
                        </div>
                        <div className="mt-1 text-sm text-gray-400">{match.stadium}</div>
                        <div className="mt-2">
                          <Badge className="bg-purple-500">حضور افتراضي</Badge>
                        </div>
                      </div>
                      <div className="text-lg font-bold text-yellow-500">{match.virtualPrice} ريال</div>
                    </div>
                  </div>
                ))}
              </div>

              <Button className="mt-6 w-full bg-yellow-500 text-black hover:bg-yellow-600" onClick={() => setStep(2)}>
                التالي
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card className="border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <h2 className="mb-4 text-xl font-semibold">اختر المقعد</h2>

              <div className="mb-6 space-y-4">
                <div className="space-y-2">
                  <Label>القسم</Label>
                  <Select value={selectedSection} onValueChange={handleSectionChange}>
                    <SelectTrigger className="border-gray-700 bg-gray-800">
                      <SelectValue placeholder="اختر القسم" />
                    </SelectTrigger>
                    <SelectContent>
                      {sections.map((section) => (
                        <SelectItem key={section} value={section}>
                          <div className="flex items-center justify-between">
                            <span>القسم {section}</span>
                            <Badge
                              className={
                                crowdDensity[section] > 80
                                  ? "bg-red-500"
                                  : crowdDensity[section] > 60
                                    ? "bg-yellow-500 text-black"
                                    : "bg-green-500"
                              }
                            >
                              {crowdDensity[section] > 80 ? "مزدحم" : crowdDensity[section] > 60 ? "متوسط" : "متاح"}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>نوع التذكرة</Label>
                  <RadioGroup value={ticketType} onValueChange={setTicketType}>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="standard" id="standard" />
                      <Label htmlFor="standard">قياسية</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="vip" id="vip" />
                      <Label htmlFor="vip">VIP (ضعف السعر)</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              {/* Stadium Visualization */}
              <div className="mb-6 space-y-4 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">الملعب الافتراضي</h3>
                  <div className="flex items-center gap-2">
                    <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "2d" | "3d")}>
                      <TabsList>
                        <TabsTrigger value="2d">2D</TabsTrigger>
                        <TabsTrigger value="3d">3D</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>تكبير/تصغير</Label>
                  <Slider
                    value={[zoomLevel]}
                    min={0.5}
                    max={2}
                    step={0.1}
                    onValueChange={(value) => setZoomLevel(value[0])}
                  />
                </div>

                <div className="relative aspect-video overflow-hidden rounded bg-gray-700">
                  <canvas
                    ref={canvasRef}
                    width={800}
                    height={600}
                    className="h-full w-full"
                    onClick={handleCanvasClick}
                    onMouseMove={handleCanvasMouseMove}
                  />

                  {!selectedSection && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                      <p className="text-center text-white">الرجاء اختيار قسم لعرض المقاعد</p>
                    </div>
                  )}
                </div>

                <div className="mt-2 text-sm text-gray-400">
                  <span className="ml-2 inline-block h-3 w-3 rounded-full bg-green-500"></span> متاح
                  <span className="mx-2 inline-block h-3 w-3 rounded-full bg-yellow-500"></span> متوسط
                  <span className="mx-2 inline-block h-3 w-3 rounded-full bg-red-500"></span> مزدحم
                  <span className="mx-2 inline-block h-3 w-3 rounded-full bg-orange-500"></span> مقعد محدد
                </div>
              </div>

              {/* Selected Seats */}
              {selectedSeats.length > 0 && (
                <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                  <h3 className="mb-2 font-medium">المقاعد المحددة</h3>
                  <div className="space-y-2">
                    {selectedSeats.map((seat, index) => (
                      <div key={index} className="flex items-center justify-between rounded bg-gray-700 p-2">
                        <span>
                          القسم {seat.section} - الصف {seat.row} - المقعد {seat.seat}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const newSelectedSeats = [...selectedSeats]
                            newSelectedSeats.splice(index, 1)
                            setSelectedSeats(newSelectedSeats)
                          }}
                        >
                          ✕
                        </Button>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 text-right text-sm">
                    <span className="text-gray-400">المجموع:</span>{" "}
                    <span className="font-bold text-yellow-500">{getTotalPrice()} ريال</span>
                  </div>
                </div>
              )}

              {/* Voice Interaction Preview */}
              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="font-medium">تجربة التفاعل الصوتي</h3>
                  <Button
                    variant={isRecording ? "destructive" : "outline"}
                    size="sm"
                    onClick={toggleRecording}
                    className={isRecording ? "animate-pulse" : ""}
                  >
                    {isRecording ? <MicOff className="mr-2 h-4 w-4" /> : <Mic className="mr-2 h-4 w-4" />}
                    {isRecording ? "إيقاف التسجيل" : "تجربة التسجيل"}
                  </Button>
                </div>

                <p className="text-sm text-gray-400">
                  يمكنك تجربة ميزة التفاعل الصوتي التي ستكون متاحة أثناء الحضور الافتراضي
                </p>

                {transcribedText && (
                  <div className="mt-3 rounded bg-gray-700 p-2">
                    <div className="flex items-center">
                      <Volume2 className="mr-2 h-4 w-4 text-yellow-500" />
                      <span>{transcribedText}</span>
                    </div>

                    {showChantSuggestion && (
                      <div className="mt-2 rounded bg-yellow-500/20 p-2 text-sm">
                        <p className="font-medium text-yellow-500">اقتراح أفضل:</p>
                        <p>{suggestedChant}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  السابق
                </Button>
                <Button
                  className="bg-yellow-500 text-black hover:bg-yellow-600"
                  onClick={() => setStep(3)}
                  disabled={selectedSeats.length === 0}
                >
                  التالي
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card className="border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <h2 className="mb-4 text-xl font-semibold">تأكيد الحجز والدفع</h2>

              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <h3 className="mb-3 font-medium">تفاصيل التذكرة الافتراضية</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">المباراة:</span>
                    <span>
                      {matches.find((match) => match.id === selectedMatch)?.homeTeam} ضد{" "}
                      {matches.find((match) => match.id === selectedMatch)?.awayTeam}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">التاريخ والوقت:</span>
                    <span>
                      {matches.find((match) => match.id === selectedMatch)?.date} -{" "}
                      {matches.find((match) => match.id === selectedMatch)?.time}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">الملعب:</span>
                    <span>{matches.find((match) => match.id === selectedMatch)?.stadium}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">نوع التذكرة:</span>
                    <span>{ticketType === "vip" ? "VIP افتراضية" : "قياسية افتراضية"}</span>
                  </div>

                  <div className="pt-2">
                    <h4 className="mb-2 font-medium">المقاعد المحددة:</h4>
                    <div className="space-y-1">
                      {selectedSeats.map((seat, index) => (
                        <div key={index} className="rounded bg-gray-700 p-2 text-sm">
                          القسم {seat.section} - الصف {seat.row} - المقعد {seat.seat}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-between border-t border-gray-700 pt-2 font-bold">
                    <span>السعر الإجمالي:</span>
                    <span className="text-yellow-500">{getTotalPrice()} ريال</span>
                  </div>
                </div>
              </div>

              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <h3 className="mb-3 font-medium">مميزات الحضور الافتراضي</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <Users className="mr-2 mt-0.5 h-4 w-4 text-yellow-500" />
                    <span>مشاهدة المباراة من المقعد الذي اخترته في الملعب الافتراضي</span>
                  </li>
                  <li className="flex items-start">
                    <Volume2 className="mr-2 mt-0.5 h-4 w-4 text-yellow-500" />
                    <span>المشاركة في الهتافات والتشجيع باستخدام الميكروفون</span>
                  </li>
                  <li className="flex items-start">
                    <Users className="mr-2 mt-0.5 h-4 w-4 text-yellow-500" />
                    <span>التفاعل مع المشجعين الآخرين في الملعب الافتراضي</span>
                  </li>
                </ul>
              </div>

              <div className="mb-6 rounded-lg border border-gray-700 bg-gray-800 p-4">
                <h3 className="mb-3 font-medium">طريقة الدفع</h3>
                <div className="flex items-center space-x-2 space-x-reverse rounded-lg border border-gray-700 bg-gray-900 p-3">
                  <CreditCard className="h-5 w-5 text-yellow-500" />
                  <span>بطاقة ائتمان / مدى</span>
                </div>
                <p className="mt-2 text-sm text-gray-400">ملاحظة: هذا نموذج تجريبي، لن يتم خصم أي مبالغ حقيقية.</p>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  السابق
                </Button>
                <Button
                  className="bg-yellow-500 text-black hover:bg-yellow-600"
                  onClick={handleBookTicket}
                  disabled={isBooking}
                >
                  {isBooking ? "جاري الحجز..." : "تأكيد الحجز"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
