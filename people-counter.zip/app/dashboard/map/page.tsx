"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { ChevronLeft, MapPin, Mic, User, Users, Move3dIcon as Play3d } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import * as tf from "@tensorflow/tfjs"
import VirtualSimulation from "@/components/virtual-simulation/virtual-simulation"

export default function StadiumMapPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [loadingAI, setLoadingAI] = useState(true)
  const [isListening, setIsListening] = useState(false)
  const [speechText, setSpeechText] = useState("")
  const [destination, setDestination] = useState("")
  const [distance, setDistance] = useState(0)
  const [showSimulation, setShowSimulation] = useState(false)
  const [crowdCount, setCrowdCount] = useState<Record<string, number>>({
    "المدخل الشمالي": 245,
    "المدخل الجنوبي": 187,
    "المدرجات الشرقية": 1250,
    "المدرجات الغربية": 980,
    "منطقة المطاعم": 320,
  })
  const [crowdDensity, setCrowdDensity] = useState<Record<string, number>>({
    "المدخل الشمالي": 75,
    "المدخل الجنوبي": 45,
    "المدرجات الشرقية": 90,
    "المدرجات الغربية": 60,
    "منطقة المطاعم": 85,
  })
  const [userLocation, setUserLocation] = useState({ x: 50, y: 50 })
  const [zoomLevel, setZoomLevel] = useState(1)
  const mapRef = useRef<HTMLDivElement>(null)
  const [model, setModel] = useState<tf.LayersModel | null>(null)

  // Simulated destinations
  const destinations = [
    { id: "gate-north", name: "المدخل الشمالي", x: 20, y: 10 },
    { id: "gate-south", name: "المدخل الجنوبي", x: 80, y: 90 },
    { id: "east-stands", name: "المدرجات الشرقية", x: 90, y: 50 },
    { id: "west-stands", name: "المدرجات الغربية", x: 10, y: 50 },
    { id: "food-area", name: "منطقة المطاعم", x: 50, y: 20 },
    { id: "toilets", name: "دورات المياه", x: 50, y: 80 },
    { id: "section-a", name: "القسم A", x: 70, y: 30 },
    { id: "section-b", name: "القسم B", x: 30, y: 30 },
    { id: "section-c", name: "القسم C", x: 70, y: 70 },
    { id: "section-d", name: "القسم D", x: 30, y: 70 },
  ]

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))
    setLoading(false)

    // Load TensorFlow.js model
    async function loadModel() {
      try {
        setLoadingAI(true)
        // Create a simple model for demonstration
        const model = tf.sequential()
        model.add(tf.layers.dense({ units: 10, inputShape: [4], activation: "relu" }))
        model.add(tf.layers.dense({ units: 1, activation: "linear" }))
        model.compile({ optimizer: "adam", loss: "meanSquaredError" })

        // Simulate model training
        const xs = tf.randomNormal([100, 4])
        const ys = tf.randomNormal([100, 1])
        await model.fit(xs, ys, { epochs: 5, verbose: 0 })

        setModel(model)
        setLoadingAI(false)
      } catch (error) {
        console.error("Error loading AI model:", error)
        setLoadingAI(false)
      }
    }

    loadModel()

    // Simulate crowd movement
    const crowdInterval = setInterval(() => {
      setCrowdCount((prev) => {
        const updated = { ...prev }
        const keys = Object.keys(updated)
        const randomKey = keys[Math.floor(Math.random() * keys.length)]
        const change = Math.floor(Math.random() * 20) - 10 // -10 to +10
        updated[randomKey] = Math.max(50, updated[randomKey] + change)
        return updated
      })

      setCrowdDensity((prev) => {
        const updated = { ...prev }
        const keys = Object.keys(updated)
        const randomKey = keys[Math.floor(Math.random() * keys.length)]
        const change = Math.floor(Math.random() * 10) - 5 // -5 to +5
        updated[randomKey] = Math.max(10, Math.min(95, updated[randomKey] + change))
        return updated
      })
    }, 3000)

    // Simulate user movement (GPS)
    const movementInterval = setInterval(() => {
      if (destination) {
        const dest = destinations.find((d) => d.id === destination)
        if (dest) {
          setUserLocation((prev) => {
            // Move towards destination
            const newX = prev.x + (dest.x > prev.x ? 1 : dest.x < prev.x ? -1 : 0)
            const newY = prev.y + (dest.y > prev.y ? 1 : dest.y < prev.y ? -1 : 0)

            // Calculate distance
            const distance = Math.sqrt(Math.pow(dest.x - newX, 2) + Math.pow(dest.y - newY, 2))
            setDistance(Math.round(distance))

            // If we've reached the destination
            if (Math.abs(dest.x - newX) < 2 && Math.abs(dest.y - newY) < 2) {
              setDestination("")
              return { x: dest.x, y: dest.y }
            }

            return { x: newX, y: newY }
          })
        }
      }
    }, 500)

    return () => {
      clearInterval(crowdInterval)
      clearInterval(movementInterval)
    }
  }, [router, destination])

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mapRef.current) return

    const rect = mapRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100

    // Find if clicked on a destination
    const clickedDest = destinations.find((dest) => Math.abs(dest.x - x) < 10 && Math.abs(dest.y - y) < 10)

    if (clickedDest) {
      setDestination(clickedDest.id)
      setSpeechText(`توجيه إلى ${clickedDest.name}`)
    }
  }

  const handleMicClick = () => {
    if (!isListening) {
      setIsListening(true)
      // Simulate speech recognition
      setTimeout(() => {
        const randomDestIndex = Math.floor(Math.random() * destinations.length)
        const randomDest = destinations[randomDestIndex]
        setSpeechText(`توجيه إلى ${randomDest.name}`)
        setDestination(randomDest.id)
        setIsListening(false)
      }, 2000)
    } else {
      setIsListening(false)
      setSpeechText("")
    }
  }

  const analyzeCrowdWithAI = () => {
    if (!model || loadingAI) return

    try {
      // Simulate AI analysis with random data
      const input = tf.tensor2d([[Math.random(), Math.random(), Math.random(), Math.random()]])
      const prediction = model.predict(input) as tf.Tensor

      // Update crowd density based on "AI" prediction
      const predictionValue = prediction.dataSync()[0]

      setCrowdDensity((prev) => {
        const updated = { ...prev }
        const keys = Object.keys(updated)
        keys.forEach((key) => {
          // Add some randomness to make it look like AI is doing something
          updated[key] = Math.max(10, Math.min(95, updated[key] + (predictionValue * 10 - 5)))
        })
        return updated
      })

      // Clean up tensors
      input.dispose()
      prediction.dispose()
    } catch (error) {
      console.error("Error analyzing crowd with AI:", error)
    }
  }

  const toggleSimulation = () => {
    setShowSimulation(!showSimulation)
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black pb-20 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/dashboard" className="ml-4">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-6 w-6" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">خريطة الملعب</h1>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-yellow-500 text-yellow-500"
              onClick={analyzeCrowdWithAI}
              disabled={loadingAI}
            >
              {loadingAI ? "جاري تحميل الذكاء الاصطناعي..." : "تحليل الحشود بالذكاء الاصطناعي"}
            </Button>
            <Button
              variant="default"
              size="sm"
              className="bg-yellow-500 text-black hover:bg-yellow-600"
              onClick={toggleSimulation}
            >
              <Play3d className="h-4 w-4 ml-2" />
              المحاكاة الافتراضية
            </Button>
          </div>
        </div>

        {/* Voice Navigation */}
        <Card className="mb-4 border-gray-800 bg-gray-900">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Button
                  variant={isListening ? "default" : "outline"}
                  size="icon"
                  className={`mr-3 ${isListening ? "bg-yellow-500 text-black" : ""}`}
                  onClick={handleMicClick}
                >
                  <Mic className="h-5 w-5" />
                </Button>
                <div>
                  <p className={isListening ? "text-yellow-500" : "text-gray-400"}>
                    {isListening ? "جاري الاستماع..." : speechText || "انقر على الميكروفون للتوجيه الصوتي"}
                  </p>
                </div>
              </div>
              {destination && <Badge className="bg-yellow-500 text-black">{distance} متر متبقي</Badge>}
            </div>
          </CardContent>
        </Card>

        {/* Map */}
        <Card className="mb-4 border-gray-800 bg-gray-900">
          <CardContent className="p-0">
            <div
              ref={mapRef}
              className="relative aspect-[4/3] overflow-hidden rounded-lg bg-gray-800"
              onClick={handleMapClick}
              style={{ transform: `scale(${zoomLevel})`, transformOrigin: "center" }}
            >
              {/* Stadium Map Background */}
              <img
                src="/placeholder.svg?height=600&width=800&text=Stadium+Map"
                alt="خريطة الملعب"
                className="h-full w-full object-cover"
              />

              {/* Destinations */}
              {destinations.map((dest) => (
                <div
                  key={dest.id}
                  className={`absolute flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full ${
                    destination === dest.id ? "bg-yellow-500" : "bg-gray-700"
                  }`}
                  style={{ left: `${dest.x}%`, top: `${dest.y}%` }}
                  title={dest.name}
                >
                  <MapPin className={`h-5 w-5 ${destination === dest.id ? "text-black" : "text-white"}`} />
                </div>
              ))}

              {/* User Location */}
              <div
                className="absolute flex h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-blue-500 ring-4 ring-blue-300"
                style={{ left: `${userLocation.x}%`, top: `${userLocation.y}%` }}
              >
                <User className="h-6 w-6 text-white" />
              </div>

              {/* Navigation Path */}
              {destination && (
                <svg className="absolute inset-0 h-full w-full" style={{ pointerEvents: "none" }}>
                  <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                      <polygon points="0 0, 10 3.5, 0 7" fill="#EAB308" />
                    </marker>
                  </defs>
                  <path
                    d={`M ${userLocation.x} ${userLocation.y} L ${
                      destinations.find((d) => d.id === destination)?.x || 0
                    } ${destinations.find((d) => d.id === destination)?.y || 0}`}
                    stroke="#EAB308"
                    strokeWidth="3"
                    strokeDasharray="5,5"
                    fill="none"
                    markerEnd="url(#arrowhead)"
                    style={{ transformOrigin: "0 0", transform: "scale(1%)" }}
                  />
                </svg>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Zoom Controls */}
        <div className="mb-6 flex items-center justify-between">
          <span className="text-sm text-gray-400">تكبير/تصغير</span>
          <div className="w-2/3">
            <Slider
              value={[zoomLevel]}
              min={0.5}
              max={2}
              step={0.1}
              onValueChange={(value) => setZoomLevel(value[0])}
            />
          </div>
          <span className="text-sm text-gray-400">{Math.round(zoomLevel * 100)}%</span>
        </div>

        {/* Crowd Density */}
        <h2 className="mb-3 text-xl font-bold">كثافة الحشود</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(crowdDensity).map(([area, density]) => (
            <Card key={area} className="border-gray-800 bg-gray-900">
              <CardContent className="p-4">
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="font-medium">{area}</h3>
                  <Badge
                    className={density > 80 ? "bg-red-500" : density > 60 ? "bg-yellow-500 text-black" : "bg-green-500"}
                  >
                    {density > 80 ? "مزدحم" : density > 60 ? "متوسط" : "متاح"}
                  </Badge>
                </div>
                <Progress value={density} className="h-2 bg-gray-700">
                  <div
                    className={`h-full ${
                      density > 80 ? "bg-red-500" : density > 60 ? "bg-yellow-500" : "bg-green-500"
                    }`}
                    style={{ width: `${density}%` }}
                  />
                </Progress>
                <div className="mt-2 flex items-center justify-between text-sm">
                  <span className="text-gray-400">عدد الأشخاص</span>
                  <div className="flex items-center">
                    <Users className="mr-1 h-4 w-4 text-gray-400" />
                    <span>{crowdCount[area]}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Virtual Simulation Modal */}
        {showSimulation && <VirtualSimulation onClose={toggleSimulation} />}
      </div>
    </div>
  )
}
