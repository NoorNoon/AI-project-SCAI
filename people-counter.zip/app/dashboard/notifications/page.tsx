"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { ChevronLeft, Bell, Ticket, MapPin, ChevronsUp, Car, Calendar } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"

export default function NotificationsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [notifications, setNotifications] = useState<any[]>([])
  const [settings, setSettings] = useState({
    matches: true,
    tickets: true,
    offers: true,
    parking: true,
    crowd: true,
  })

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))

    // Generate sample notifications
    const sampleNotifications = [
      {
        id: 1,
        type: "match",
        title: "تذكير بالمباراة",
        message: "مباراة الهلال ضد النصر تبدأ بعد ساعتين",
        time: "قبل 10 دقائق",
        read: false,
      },
      {
        id: 2,
        type: "ticket",
        title: "تأكيد حجز التذكرة",
        message: "تم تأكيد حجز تذكرتك لمباراة الهلال ضد النصر",
        time: "قبل 2 ساعة",
        read: true,
      },
      {
        id: 3,
        type: "offer",
        title: "عرض خاص",
        message: "خصم 20% على المشروبات في منطقة المطاعم",
        time: "قبل 5 ساعات",
        read: false,
      },
      {
        id: 4,
        type: "parking",
        title: "تنبيه مواقف السيارات",
        message: "موقف السيارات الشمالي ممتلئ، يرجى استخدام الموقف الجنوبي",
        time: "قبل 1 يوم",
        read: true,
      },
      {
        id: 5,
        type: "crowd",
        title: "تنبيه ازدحام",
        message: "المدخل الشرقي مزدحم، يرجى استخدام المدخل الغربي",
        time: "قبل 2 يوم",
        read: true,
      },
    ]

    setNotifications(sampleNotifications)
    setLoading(false)
  }, [router])

  const markAsRead = (id: number) => {
    setNotifications((prev) =>
      prev.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }

  const deleteNotification = (id: number) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notification) => ({ ...notification, read: true })))
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "match":
        return <Calendar className="h-5 w-5 text-blue-500" />
      case "ticket":
        return <Ticket className="h-5 w-5 text-green-500" />
      case "offer":
        return <ChevronsUp className="h-5 w-5 text-purple-500" />
      case "parking":
        return <Car className="h-5 w-5 text-orange-500" />
      case "crowd":
        return <MapPin className="h-5 w-5 text-red-500" />
      default:
        return <Bell className="h-5 w-5 text-yellow-500" />
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black pb-20 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/dashboard" className="ml-4">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-6 w-6" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">التنبيهات</h1>
          </div>
          <Button variant="outline" size="sm" onClick={markAllAsRead}>
            تعيين الكل كمقروء
          </Button>
        </div>

        {/* Notifications */}
        <div className="mb-8 space-y-4">
          <h2 className="text-xl font-semibold">التنبيهات الحديثة</h2>

          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-lg border border-gray-800 bg-gray-900 p-8 text-center">
              <Bell className="mb-4 h-16 w-16 text-gray-600" />
              <h2 className="mb-2 text-xl font-semibold">لا توجد تنبيهات</h2>
              <p className="text-gray-400">ستظهر التنبيهات الجديدة هنا</p>
            </div>
          ) : (
            <div className="space-y-3">
              {notifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`border-gray-800 ${notification.read ? "bg-gray-900" : "bg-gray-800"}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start">
                        <div className="mr-3 rounded-full bg-gray-700 p-2">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div>
                          <div className="flex items-center">
                            <h3 className="font-medium">{notification.title}</h3>
                            {!notification.read && <Badge className="mr-2 bg-yellow-500 text-black">جديد</Badge>}
                          </div>
                          <p className="mt-1 text-gray-400">{notification.message}</p>
                          <p className="mt-1 text-xs text-gray-500">{notification.time}</p>
                        </div>
                      </div>
                      <div className="flex">
                        {!notification.read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-xs text-gray-400"
                            onClick={() => markAsRead(notification.id)}
                          >
                            تعيين كمقروء
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 text-xs text-gray-400"
                          onClick={() => deleteNotification(notification.id)}
                        >
                          حذف
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Notification Settings */}
        <Card className="border-gray-800 bg-gray-900">
          <CardContent className="p-6">
            <h2 className="mb-4 text-xl font-semibold">إعدادات التنبيهات</h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calendar className="mr-3 h-5 w-5 text-blue-500" />
                  <div>
                    <h3 className="font-medium">تنبيهات المباريات</h3>
                    <p className="text-sm text-gray-400">تذكيرات بالمباريات القادمة والأحداث</p>
                  </div>
                </div>
                <Switch
                  checked={settings.matches}
                  onCheckedChange={(checked) => setSettings({ ...settings, matches: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Ticket className="mr-3 h-5 w-5 text-green-500" />
                  <div>
                    <h3 className="font-medium">تنبيهات التذاكر</h3>
                    <p className="text-sm text-gray-400">تأكيدات الحجز وتذكيرات بالمباريات</p>
                  </div>
                </div>
                <Switch
                  checked={settings.tickets}
                  onCheckedChange={(checked) => setSettings({ ...settings, tickets: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <ChevronsUp className="mr-3 h-5 w-5 text-purple-500" />
                  <div>
                    <h3 className="font-medium">تنبيهات العروض</h3>
                    <p className="text-sm text-gray-400">عروض وخصومات خاصة</p>
                  </div>
                </div>
                <Switch
                  checked={settings.offers}
                  onCheckedChange={(checked) => setSettings({ ...settings, offers: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Car className="mr-3 h-5 w-5 text-orange-500" />
                  <div>
                    <h3 className="font-medium">تنبيهات مواقف السيارات</h3>
                    <p className="text-sm text-gray-400">معلومات عن توفر مواقف السيارات</p>
                  </div>
                </div>
                <Switch
                  checked={settings.parking}
                  onCheckedChange={(checked) => setSettings({ ...settings, parking: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <MapPin className="mr-3 h-5 w-5 text-red-500" />
                  <div>
                    <h3 className="font-medium">تنبيهات الازدحام</h3>
                    <p className="text-sm text-gray-400">تنبيهات عن الازدحام والمناطق المزدحمة</p>
                  </div>
                </div>
                <Switch
                  checked={settings.crowd}
                  onCheckedChange={(checked) => setSettings({ ...settings, crowd: checked })}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
