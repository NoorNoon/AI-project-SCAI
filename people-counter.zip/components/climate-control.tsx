"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Thermometer, Wind, Droplets, Users, RefreshCw, Power } from "lucide-react"

export function ClimateControl() {
  const [temperature, setTemperature] = useState(24)
  const [humidity, setHumidity] = useState(45)
  const [fanSpeed, setFanSpeed] = useState(50)
  const [isAutoMode, setIsAutoMode] = useState(true)
  const [crowdDensity, setCrowdDensity] = useState<Record<string, number>>({
    "المدرجات الشمالية": 75,
    "المدرجات الجنوبية": 60,
    "المدرجات الشرقية": 85,
    "المدرجات الغربية": 70,
    "المنطقة المركزية": 90,
  })
  const [systemStatus, setSystemStatus] = useState<Record<string, boolean>>({
    "المدرجات الشمالية": true,
    "المدرجات الجنوبية": true,
    "المدرجات الشرقية": true,
    "المدرجات الغربية": true,
    "المنطقة المركزية": true,
  })
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Simulate climate control based on crowd density
  useEffect(() => {
    if (isAutoMode) {
      // Calculate average crowd density
      const totalDensity = Object.values(crowdDensity).reduce((sum, density) => sum + density, 0)
      const avgDensity = totalDensity / Object.values(crowdDensity).length

      // Adjust temperature based on crowd density
      // Higher density = lower temperature (more cooling)
      const calculatedTemp = 26 - (avgDensity / 100) * 4
      setTemperature(Math.round(calculatedTemp * 10) / 10)

      // Adjust humidity based on crowd density
      // Higher density = lower humidity
      const calculatedHumidity = 50 - (avgDensity / 100) * 10
      setHumidity(Math.round(calculatedHumidity))

      // Adjust fan speed based on crowd density
      // Higher density = higher fan speed
      const calculatedFanSpeed = 30 + (avgDensity / 100) * 70
      setFanSpeed(Math.round(calculatedFanSpeed))
    }
  }, [crowdDensity, isAutoMode])

  // Simulate crowd density changes
  useEffect(() => {
    const interval = setInterval(() => {
      setCrowdDensity((prev) => {
        const updated = { ...prev }
        const keys = Object.keys(updated)
        const randomKey = keys[Math.floor(Math.random() * keys.length)]
        const change = Math.floor(Math.random() * 10) - 5 // -5 to +5
        updated[randomKey] = Math.max(10, Math.min(95, updated[randomKey] + change))
        return updated
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = () => {
    setIsRefreshing(true)

    // Simulate data refresh
    setTimeout(() => {
      setCrowdDensity((prev) => {
        const updated = { ...prev }
        Object.keys(updated).forEach((key) => {
          const change = Math.floor(Math.random() * 20) - 10 // -10 to +10
          updated[key] = Math.max(10, Math.min(95, updated[key] + change))
        })
        return updated
      })

      setIsRefreshing(false)
    }, 1500)
  }

  const toggleSystemStatus = (zone: string) => {
    setSystemStatus((prev) => ({
      ...prev,
      [zone]: !prev[zone],
    }))
  }

  const getTemperatureColor = (temp: number) => {
    if (temp < 20) return "text-blue-500"
    if (temp > 26) return "text-red-500"
    return "text-green-500"
  }

  const getHumidityColor = (hum: number) => {
    if (hum < 30) return "text-yellow-500"
    if (hum > 60) return "text-blue-500"
    return "text-green-500"
  }

  return (
    <Card className="border-gray-800 bg-gray-900">
      <CardContent className="p-4">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold">التحكم في مناخ الملعب</h3>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            {isRefreshing ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Auto Mode Toggle */}
        <div className="mb-4 flex items-center justify-between rounded-lg bg-gray-800 p-3">
          <div>
            <h4 className="font-medium">الوضع التلقائي</h4>
            <p className="text-sm text-gray-400">ضبط المناخ تلقائيًا بناءً على كثافة الجماهير</p>
          </div>
          <Switch checked={isAutoMode} onCheckedChange={setIsAutoMode} />
        </div>

        {/* Current Climate Stats */}
        <div className="mb-4 grid grid-cols-3 gap-3">
          <div className="rounded-lg bg-gray-800 p-3 text-center">
            <Thermometer className="mx-auto mb-1 h-5 w-5 text-red-500" />
            <div className={`text-lg font-bold ${getTemperatureColor(temperature)}`}>{temperature}°C</div>
            <div className="text-xs text-gray-400">درجة الحرارة</div>
          </div>

          <div className="rounded-lg bg-gray-800 p-3 text-center">
            <Droplets className="mx-auto mb-1 h-5 w-5 text-blue-500" />
            <div className={`text-lg font-bold ${getHumidityColor(humidity)}`}>{humidity}%</div>
            <div className="text-xs text-gray-400">الرطوبة</div>
          </div>

          <div className="rounded-lg bg-gray-800 p-3 text-center">
            <Wind className="mx-auto mb-1 h-5 w-5 text-green-500" />
            <div className="text-lg font-bold text-green-500">{fanSpeed}%</div>
            <div className="text-xs text-gray-400">سرعة المراوح</div>
          </div>
        </div>

        {/* Manual Controls (disabled in auto mode) */}
        {!isAutoMode && (
          <div className="mb-4 space-y-4 rounded-lg border border-gray-800 bg-gray-800 p-3">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>درجة الحرارة</Label>
                <span className={`font-medium ${getTemperatureColor(temperature)}`}>{temperature}°C</span>
              </div>
              <Slider
                value={[temperature]}
                min={18}
                max={30}
                step={0.5}
                onValueChange={(value) => setTemperature(value[0])}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>الرطوبة</Label>
                <span className={`font-medium ${getHumidityColor(humidity)}`}>{humidity}%</span>
              </div>
              <Slider value={[humidity]} min={20} max={70} step={1} onValueChange={(value) => setHumidity(value[0])} />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>سرعة المراوح</Label>
                <span className="font-medium text-green-500">{fanSpeed}%</span>
              </div>
              <Slider value={[fanSpeed]} min={0} max={100} step={5} onValueChange={(value) => setFanSpeed(value[0])} />
            </div>
          </div>
        )}

        {/* Crowd Density by Zone */}
        <h4 className="mb-2 font-medium">كثافة الجماهير حسب المنطقة</h4>
        <div className="space-y-3">
          {Object.entries(crowdDensity).map(([zone, density]) => (
            <div key={zone} className="space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Users className="mr-1 h-4 w-4 text-gray-400" />
                  <span className="text-sm">{zone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    className={density > 80 ? "bg-red-500" : density > 60 ? "bg-yellow-500 text-black" : "bg-green-500"}
                  >
                    {density}%
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => toggleSystemStatus(zone)}>
                    <Power className={`h-4 w-4 ${systemStatus[zone] ? "text-green-500" : "text-gray-500"}`} />
                  </Button>
                </div>
              </div>
              <Progress value={density} className="h-1 bg-gray-700">
                <div
                  className={`h-full ${density > 80 ? "bg-red-500" : density > 60 ? "bg-yellow-500" : "bg-green-500"}`}
                  style={{ width: `${density}%` }}
                />
              </Progress>
            </div>
          ))}
        </div>

        <div className="mt-4 text-center text-xs text-gray-400">
          {isAutoMode
            ? "النظام يعمل في الوضع التلقائي ويضبط المناخ بناءً على كثافة الجماهير"
            : "النظام يعمل في الوضع اليدوي، يمكنك ضبط الإعدادات يدويًا"}
        </div>
      </CardContent>
    </Card>
  )
}
