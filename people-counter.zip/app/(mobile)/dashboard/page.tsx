import DashboardMobile from "@/components/dashboard/dashboard-mobile"

export default function DashboardPage() {
  return <DashboardMobile />
}
