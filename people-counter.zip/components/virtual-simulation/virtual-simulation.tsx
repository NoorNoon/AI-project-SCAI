"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, CheckCircle, Play, Pause, RotateCcw, Users, Clock, Shield, Activity } from "lucide-react"
import { SimulationEngine } from "./simulation-engine"
import SimulationCanvas from "./simulation-canvas"

interface VirtualSimulationProps {
  onClose: () => void
}

const VirtualSimulation: React.FC<VirtualSimulationProps> = ({ onClose }) => {
  const [engine] = useState(() => new SimulationEngine())
  const [isRunning, setIsRunning] = useState(false)
  const [stats, setStats] = useState({
    people: 0,
    evacuationProgress: 0,
    casualties: 0,
    safetyScore: 100,
    emergencies: 0,
  })
  const [elapsedTime, setElapsedTime] = useState(0)
  const [startTime, setStartTime] = useState(0)

  useEffect(() => {
    const handleStateChanged = (state: any) => {
      setStats({
        people: state.people.length,
        evacuationProgress: state.evacuationProgress,
        casualties: state.casualties,
        safetyScore: state.safetyScore,
        emergencies: state.emergencies.length,
      })
    }

    const handleSimulationStarted = () => {
      setIsRunning(true)
      setStartTime(Date.now())
    }

    const handleSimulationStopped = () => {
      setIsRunning(false)
    }

    engine.on("stateChanged", handleStateChanged)
    engine.on("simulationStarted", handleSimulationStarted)
    engine.on("simulationStopped", handleSimulationStopped)

    // تحديث الوقت المنقضي
    const timer = setInterval(() => {
      if (isRunning) {
        setElapsedTime(Math.floor((Date.now() - startTime) / 1000))
      }
    }, 1000)

    return () => {
      engine.off("stateChanged", handleStateChanged)
      engine.off("simulationStarted", handleSimulationStarted)
      engine.off("simulationStopped", handleSimulationStopped)
      clearInterval(timer)
      engine.stop()
    }
  }, [engine, isRunning, startTime])

  const handleStart = () => {
    engine.start()
  }

  const handleStop = () => {
    engine.stop()
  }

  const handleReset = () => {
    engine.stop()
    engine.reset()
    setElapsedTime(0)
  }

  const handleAddPeople = (count: number) => {
    engine.addPeople(count)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-6xl bg-gray-900 border-gray-800 text-white">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl">المحاكاة الافتراضية للاستاد</CardTitle>
              <CardDescription className="text-gray-400">محاكاة حالات الطوارئ وإدارة الحشود</CardDescription>
            </div>
            <Button variant="ghost" onClick={onClose}>
              إغلاق
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-blue-400" />
                    <span>الأشخاص</span>
                  </div>
                  <span className="text-xl font-bold">{stats.people}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-yellow-400" />
                    <span>الوقت المنقضي</span>
                  </div>
                  <span className="text-xl font-bold">{formatTime(elapsedTime)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 mr-2 text-green-400" />
                    <span>درجة الأمان</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-xl font-bold">{Math.round(stats.safetyScore)}</span>
                    <span className="text-sm text-gray-400 mr-1">/ 100</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Activity className="h-5 w-5 mr-2 text-red-400" />
                    <span>حالات الطوارئ</span>
                  </div>
                  <Badge className={stats.emergencies > 0 ? "bg-red-500" : "bg-green-500"}>{stats.emergencies}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-4">
            <div className="lg:col-span-3">
              <SimulationCanvas width={800} height={600} engine={engine} />
            </div>

            <div className="space-y-4">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">التحكم بالمحاكاة</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col space-y-2">
                    {!isRunning ? (
                      <Button onClick={handleStart} className="w-full bg-green-600 hover:bg-green-700">
                        <Play className="h-4 w-4 mr-2" />
                        بدء المحاكاة
                      </Button>
                    ) : (
                      <Button onClick={handleStop} className="w-full bg-amber-600 hover:bg-amber-700">
                        <Pause className="h-4 w-4 mr-2" />
                        إيقاف مؤقت
                      </Button>
                    )}

                    <Button onClick={handleReset} variant="outline" className="w-full">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      إعادة تعيين
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">إضافة أشخاص</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    <Button onClick={() => handleAddPeople(10)} variant="outline" size="sm">
                      +10
                    </Button>
                    <Button onClick={() => handleAddPeople(50)} variant="outline" size="sm">
                      +50
                    </Button>
                    <Button onClick={() => handleAddPeople(100)} variant="outline" size="sm">
                      +100
                    </Button>
                    <Button onClick={() => handleAddPeople(500)} variant="outline" size="sm">
                      +500
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">تقدم الإخلاء</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Progress value={stats.evacuationProgress} className="h-2 bg-gray-700" />
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>0%</span>
                      <span>{Math.round(stats.evacuationProgress)}%</span>
                      <span>100%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">الحالة</CardTitle>
                </CardHeader>
                <CardContent>
                  {stats.emergencies > 0 ? (
                    <div className="flex items-center text-amber-500">
                      <AlertTriangle className="h-5 w-5 mr-2" />
                      <span>حالة طوارئ نشطة</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-green-500">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      <span>الوضع آمن</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-4">
            <Tabs defaultValue="instructions">
              <TabsList className="bg-gray-800">
                <TabsTrigger value="instructions">تعليمات</TabsTrigger>
                <TabsTrigger value="legend">مفتاح الرموز</TabsTrigger>
                <TabsTrigger value="stats">إحصائيات مفصلة</TabsTrigger>
              </TabsList>

              <TabsContent value="instructions" className="bg-gray-800 p-4 rounded-md mt-2">
                <h3 className="font-bold mb-2">كيفية استخدام المحاكاة:</h3>
                <ul className="list-disc list-inside space-y-1 text-gray-300">
                  <li>استخدم الأزرار في الأسفل لاختيار الأداة المناسبة</li>
                  <li>انقر على الخريطة لإضافة أشخاص أو حالات طوارئ</li>
                  <li>اسحب فرق الأمن والفرق الطبية لتحريكها (باستخدام أداة التحريك)</li>
                  <li>استخدم أزرار التحكم لبدء وإيقاف وإعادة تعيين المحاكاة</li>
                  <li>راقب الإحصائيات لتقييم فعالية استجابة الطوارئ</li>
                </ul>
              </TabsContent>

              <TabsContent value="legend" className="bg-gray-800 p-4 rounded-md mt-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-bold mb-2">الأشخاص:</h3>
                    <ul className="space-y-1 text-gray-300">
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
                        <span>عادي</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-yellow-500 mr-2"></div>
                        <span>مذعور</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-red-500 mr-2"></div>
                        <span>مصاب</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-purple-500 mr-2"></div>
                        <span>يتم إخلاؤه</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-bold mb-2">حالات الطوارئ:</h3>
                    <ul className="space-y-1 text-gray-300">
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-red-500 mr-2"></div>
                        <span>حريق</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-orange-500 mr-2"></div>
                        <span>شغب</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-pink-500 mr-2"></div>
                        <span>حالة طبية</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-blue-500 mr-2"></div>
                        <span>ازدحام</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="stats" className="bg-gray-800 p-4 rounded-md mt-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-bold mb-2">إحصائيات الأشخاص:</h3>
                    <ul className="space-y-1 text-gray-300">
                      <li className="flex justify-between">
                        <span>إجمالي الأشخاص:</span>
                        <span>{stats.people}</span>
                      </li>
                      <li className="flex justify-between">
                        <span>تم إخلاؤهم:</span>
                        <span>{Math.round(stats.evacuationProgress)}%</span>
                      </li>
                      <li className="flex justify-between">
                        <span>الضحايا:</span>
                        <span>{stats.casualties}</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-bold mb-2">إحصائيات الطوارئ:</h3>
                    <ul className="space-y-1 text-gray-300">
                      <li className="flex justify-between">
                        <span>حالات الطوارئ النشطة:</span>
                        <span>{stats.emergencies}</span>
                      </li>
                      <li className="flex justify-between">
                        <span>درجة الأمان:</span>
                        <span>{Math.round(stats.safetyScore)}%</span>
                      </li>
                      <li className="flex justify-between">
                        <span>الوقت المنقضي:</span>
                        <span>{formatTime(elapsedTime)}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default VirtualSimulation
