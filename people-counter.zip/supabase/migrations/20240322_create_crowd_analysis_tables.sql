-- إنشاء جدول جلسات تحليل الحشود
CREATE TABLE IF NOT EXISTS crowd_analysis_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_name TEXT,
  location TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء جدول نتائج تحليل الحشود
CREATE TABLE IF NOT EXISTS crowd_analysis_results (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID REFERENCES crowd_analysis_sessions(id) ON DELETE CASCADE,
  people_count INTEGER NOT NULL,
  confidence_threshold FLOAT NOT NULL,
  processing_time FLOAT,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء جدول تفاصيل الكشف
CREATE TABLE IF NOT EXISTS detection_details (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  result_id UUID REFERENCES crowd_analysis_results(id) ON DELETE CASCADE,
  detection_id INTEGER,
  bbox_x FLOAT NOT NULL,
  bbox_y FLOAT NOT NULL,
  bbox_width FLOAT NOT NULL,
  bbox_height FLOAT NOT NULL,
  score FLOAT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء فهارس للتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_crowd_analysis_results_session_id ON crowd_analysis_results(session_id);
CREATE INDEX IF NOT EXISTS idx_detection_details_result_id ON detection_details(result_id);
