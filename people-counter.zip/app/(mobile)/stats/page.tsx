import AnalysisHistoryMobile from "@/components/crowd-analysis/analysis-history-mobile"
import { CrowdAnalysisProvider } from "@/components/context/crowd-analysis-context"

export default function StatsPage() {
  return (
    <CrowdAnalysisProvider>
      <AnalysisHistoryMobile />
    </CrowdAnalysisProvider>
  )
}
