"use client"

import type React from "react"
import { useRef, useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { AlertCircle, Camera, Upload, Video, Save, Trash, Play, Pause, RotateCcw, Database } from "lucide-react"
import { yoloModel, type Detection } from "./yolo-model"
import { personTracker } from "./person-tracker"
import { yoloTrainer } from "./model-trainer"
import { useCrowdAnalysis } from "../context/crowd-analysis-context"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

// حجم الملف الأقصى بالبايت (50 ميجابايت)
const MAX_FILE_SIZE = 50 * 1024 * 1024

// الأنواع المسموح بها للملفات
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"]
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime"]

interface PeopleCounterProps {
  onCountChange?: (count: number) => void
  embedded?: boolean
}

const PeopleCounter: React.FC<PeopleCounterProps> = ({ onCountChange, embedded = false }) => {
  // استخدام سياق تحليل الحشود
  const {
    setPeopleCount: setGlobalPeopleCount,
    setDetections: setGlobalDetections,
    setProcessingTime: setGlobalProcessingTime,
    setIsProcessing: setGlobalIsProcessing,
    addHistoryEntry,
    saveCurrentResult,
    currentSession,
    sessions,
    createNewSession,
    confidenceThreshold: globalConfidenceThreshold,
    setConfidenceThreshold: setGlobalConfidenceThreshold,
  } = useCrowdAnalysis()

  // المراجع للعناصر
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // حالة التطبيق
  const [activeTab, setActiveTab] = useState<string>("camera")
  const [isModelLoaded, setIsModelLoaded] = useState<boolean>(false)
  const [isProcessing, setIsProcessing] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  const [peopleCount, setPeopleCount] = useState<number>(0)
  const [detections, setDetections] = useState<Detection[]>([])
  const [confidenceThreshold, setConfidenceThreshold] = useState<number>(globalConfidenceThreshold)
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(false)
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [isTraining, setIsTraining] = useState<boolean>(false)
  const [trainingProgress, setTrainingProgress] = useState<number>(0)
  const [trainingLogs, setTrainingLogs] = useState<string[]>([])
  const [annotations, setAnnotations] = useState<Detection[]>([])
  const [isAnnotating, setIsAnnotating] = useState<boolean>(false)
  const [currentAnnotation, setCurrentAnnotation] = useState<{
    startX: number
    startY: number
    endX: number
    endY: number
  } | null>(null)

  // حالة جلسة قاعدة البيانات
  const [newSessionName, setNewSessionName] = useState<string>("")
  const [newSessionLocation, setNewSessionLocation] = useState<string>("")
  const [isSessionDialogOpen, setIsSessionDialogOpen] = useState<boolean>(false)
  const [isSaving, setIsSaving] = useState<boolean>(false)

  // Add a new state for thinking/processing visualization
  const [processingTime, setProcessingTime] = useState<number>(0)
  const processingTimerRef = useRef<NodeJS.Timeout | null>(null)
  const updateIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // تحميل النموذج عند تحميل المكون
  useEffect(() => {
    const loadModel = async () => {
      try {
        setError(null)
        await yoloModel.load()
        setIsModelLoaded(true)
      } catch (err) {
        console.error("Failed to load YOLOv8 model:", err)
        setError("فشل في تحميل نموذج YOLOv8. يرجى التحقق من اتصالك بالإنترنت وتحديث الصفحة.")
      }
    }

    loadModel()

    // إضافة تحديث دوري لسجل الحشود
    updateIntervalRef.current = setInterval(() => {
      if (peopleCount > 0) {
        addHistoryEntry(peopleCount)
      }
    }, 60000) // تحديث كل دقيقة

    // تنظيف الموارد عند إلغاء تحميل المكون
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
      yoloModel.dispose()

      if (updateIntervalRef.current) {
        clearInterval(updateIntervalRef.current)
      }
    }
  }, [addHistoryEntry, peopleCount])

  // تحديث الحالة العالمية عند تغيير الحالة المحلية
  useEffect(() => {
    setGlobalPeopleCount(peopleCount)
    setGlobalDetections(detections)
    setGlobalProcessingTime(processingTime)
    setGlobalIsProcessing(isProcessing)

    // إضافة إدخال جديد إلى سجل الحشود عند تغيير عدد الأشخاص بشكل كبير
    if (peopleCount > 0) {
      addHistoryEntry(peopleCount)
    }
  }, [
    peopleCount,
    detections,
    processingTime,
    isProcessing,
    setGlobalPeopleCount,
    setGlobalDetections,
    setGlobalProcessingTime,
    setGlobalIsProcessing,
    addHistoryEntry,
  ])

  // مزامنة عتبة الثقة مع السياق العالمي
  useEffect(() => {
    setConfidenceThreshold(globalConfidenceThreshold)
  }, [globalConfidenceThreshold])

  // تبديل علامة التبويب النشطة
  const handleTabChange = (value: string) => {
    setActiveTab(value)

    // إيقاف الكاميرا عند تبديل علامة التبويب
    if (value !== "camera" && streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null

      if (videoRef.current) {
        videoRef.current.srcObject = null
      }
    }

    // إيقاف تشغيل الفيديو عند تبديل علامة التبويب
    if (value !== "video" && videoRef.current) {
      videoRef.current.pause()
      setIsVideoPlaying(false)
    }

    // بدء تشغيل الكاميرا إذا تم التبديل إلى علامة تبويب الكاميرا
    if (value === "camera") {
      startCamera()
    }

    // مسح الكشوفات والعدد
    setDetections([])
    setPeopleCount(0)

    // إعادة تعيين الخطأ
    setError(null)
  }

  // بدء تشغيل الكاميرا
  const startCamera = async () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      const constraints = {
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "environment",
        },
      }

      const stream = await navigator.mediaDevices.getUserMedia(constraints)
      streamRef.current = stream

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()

        // بدء معالجة الإطارات
        requestAnimationFrame(processVideoFrame)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("فشل في الوصول إلى الكاميرا. يرجى التأكد من السماح بالوصول إلى الكاميرا.")
    }
  }

  // Modify the processVideoFrame function to include timing
  const processVideoFrame = async () => {
    if (!videoRef.current || !canvasRef.current || !isModelLoaded || activeTab !== "camera") {
      return
    }

    try {
      setIsProcessing(true)
      const startTime = performance.now() // Start timing

      // التأكد من أن الفيديو جاهز
      if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        // ضبط حجم الكانفاس ليتطابق مع الفيديو
        const videoWidth = videoRef.current.videoWidth
        const videoHeight = videoRef.current.videoHeight

        canvasRef.current.width = videoWidth
        canvasRef.current.height = videoHeight

        // اكتشاف الأشخاص في الإطار
        const detectedPeople = await yoloModel.detect(videoRef.current, confidenceThreshold, 0.45)

        // تتبع الأشخاص عبر الإطارات
        const trackedPeople = personTracker.update(detectedPeople)

        // تحديث عدد الأشخاص
        const count = trackedPeople.length
        setPeopleCount(count)
        setDetections(trackedPeople)

        // إبلاغ التغيير في العدد
        if (onCountChange) {
          onCountChange(count)
        }

        // رسم الكشوفات على الكانفاس
        drawDetections(trackedPeople)

        // Calculate processing time
        const endTime = performance.now()
        setProcessingTime(endTime - startTime)
      }
    } catch (err) {
      console.error("Error processing video frame:", err)
    } finally {
      setIsProcessing(false)

      // استمرار معالجة الإطارات
      if (activeTab === "camera") {
        requestAnimationFrame(processVideoFrame)
      }
    }
  }

  // رسم الكشوفات على الكانفاس
  const drawDetections = (detections: Detection[]) => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // مسح الكانفاس
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    // رسم الفيديو أو الصورة على الكانفاس
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      ctx.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height)
    }

    // رسم الكشوفات
    detections.forEach((detection) => {
      const [x, y, width, height] = detection.bbox
      const color = detection.color || "#00FF00"

      // رسم صندوق الحدود
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      ctx.strokeRect(x, y, width, height)

      // رسم معرف الشخص ودرجة الثقة
      ctx.fillStyle = color
      ctx.font = "16px Arial"

      let label = `Person`
      if (detection.id) {
        label += ` #${detection.id}`
      }
      label += ` ${Math.round(detection.score * 100)}%`

      ctx.fillText(label, x, y > 20 ? y - 5 : y + 20)
    })

    // رسم التعليق التوضيحي الحالي إذا كان في وضع التعليق
    if (isAnnotating && currentAnnotation) {
      const { startX, startY, endX, endY } = currentAnnotation
      const width = endX - startX
      const height = endY - startY

      ctx.strokeStyle = "#FF0000"
      ctx.lineWidth = 2
      ctx.strokeRect(startX, startY, width, height)
    }
  }

  // Modify the handleImageUpload function to include timing
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // التحقق من نوع الملف
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      setError("نوع الملف غير مدعوم. يرجى تحميل صورة بتنسيق JPEG أو PNG أو WebP أو GIF.")
      return
    }

    // التحقق من حجم الملف
    if (file.size > MAX_FILE_SIZE) {
      setError("حجم الملف كبير جدًا. الحد الأقصى هو 50 ميجابايت.")
      return
    }

    try {
      setError(null)
      setIsProcessing(true)
      setImageFile(file)
      const startTime = performance.now() // Start timing

      // إنشاء عنصر صورة
      const img = new Image()
      img.src = URL.createObjectURL(file)

      img.onload = async () => {
        if (!canvasRef.current) return

        // ضبط حجم الكانفاس ليتطابق مع الصورة
        canvasRef.current.width = img.width
        canvasRef.current.height = img.height

        // رسم الصورة على الكانفاس
        const ctx = canvasRef.current.getContext("2d")
        if (!ctx) return

        ctx.drawImage(img, 0, 0, img.width, img.height)

        // اكتشاف الأشخاص في الصورة
        const detectedPeople = await yoloModel.detect(canvasRef.current, confidenceThreshold, 0.45)

        // تحديث عدد الأشخاص
        const count = detectedPeople.length
        setPeopleCount(count)
        setDetections(detectedPeople)

        // إبلاغ التغيير في العدد
        if (onCountChange) {
          onCountChange(count)
        }

        // رسم الكشوفات على الكانفاس
        drawDetections(detectedPeople)

        // Calculate processing time
        const endTime = performance.now()
        setProcessingTime(endTime - startTime)

        setIsProcessing(false)
      }

      img.onerror = () => {
        setError("فشل في تحميل الصورة. يرجى التحقق من الملف وإعادة المحاولة.")
        setIsProcessing(false)
      }
    } catch (err) {
      console.error("Error processing image:", err)
      setError("حدث خطأ أثناء معالجة الصورة. يرجى إعادة المحاولة.")
      setIsProcessing(false)
    }
  }

  // معالجة تحميل الفيديو
  const handleVideoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // التحقق من نوع الملف
    if (!ALLOWED_VIDEO_TYPES.includes(file.type)) {
      setError("نوع الملف غير مدعوم. يرجى تحميل فيديو بتنسيق MP4 أو WebM أو QuickTime.")
      return
    }

    // التحقق من حجم الملف
    if (file.size > MAX_FILE_SIZE) {
      setError("حجم الملف كبير جدًا. الحد الأقصى هو 50 ميجابايت.")
      return
    }

    try {
      setError(null)
      setVideoFile(file)

      // إعداد الفيديو
      if (videoRef.current) {
        videoRef.current.src = URL.createObjectURL(file)
        videoRef.current.onloadedmetadata = () => {
          if (canvasRef.current && videoRef.current) {
            canvasRef.current.width = videoRef.current.videoWidth
            canvasRef.current.height = videoRef.current.videoHeight
          }
        }
      }
    } catch (err) {
      console.error("Error loading video:", err)
      setError("حدث خطأ أثناء تحميل الفيديو. يرجى إعادة المحاولة.")
    }
  }

  // تشغيل/إيقاف الفيديو
  const toggleVideoPlayback = () => {
    if (!videoRef.current) return

    if (isVideoPlaying) {
      videoRef.current.pause()
      setIsVideoPlaying(false)
    } else {
      videoRef.current.play()
      setIsVideoPlaying(true)
      processVideoFrames()
    }
  }

  // Similarly, modify the processVideoFrames function
  const processVideoFrames = async () => {
    if (!videoRef.current || !canvasRef.current || !isModelLoaded || activeTab !== "video" || !isVideoPlaying) {
      return
    }

    try {
      setIsProcessing(true)
      const startTime = performance.now() // Start timing

      // التأكد من أن الفيديو جاهز
      if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        // ضبط حجم الكانفاس ليتطابق مع الفيديو
        const videoWidth = videoRef.current.videoWidth
        const videoHeight = videoRef.current.videoHeight

        canvasRef.current.width = videoWidth
        canvasRef.current.height = videoHeight

        // اكتشاف الأشخاص في الإطار
        const detectedPeople = await yoloModel.detect(videoRef.current, confidenceThreshold, 0.45)

        // تتبع الأشخاص عبر الإطارات
        const trackedPeople = personTracker.update(detectedPeople)

        // تحديث عدد الأشخاص
        const count = trackedPeople.length
        setPeopleCount(count)
        setDetections(trackedPeople)

        // إبلاغ التغيير في العدد
        if (onCountChange) {
          onCountChange(count)
        }

        // رسم الكشوفات على الكانفاس
        drawDetections(trackedPeople)

        // Calculate processing time
        const endTime = performance.now()
        setProcessingTime(endTime - startTime)
      }
    } catch (err) {
      console.error("Error processing video frame:", err)
    } finally {
      setIsProcessing(false)

      // استمرار معالجة الإطارات إذا كان الفيديو قيد التشغيل
      if (activeTab === "video" && isVideoPlaying) {
        requestAnimationFrame(processVideoFrames)
      }
    }
  }

  // إعادة تعيين الفيديو
  const resetVideo = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0

      if (isVideoPlaying) {
        videoRef.current.play()
      }
    }
  }

  // تغيير عتبة الثقة
  const handleConfidenceChange = (value: number[]) => {
    setConfidenceThreshold(value[0])
    setGlobalConfidenceThreshold(value[0])
  }

  // بدء التعليق التوضيحي
  const startAnnotation = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !isAnnotating) return

    const rect = canvasRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setCurrentAnnotation({
      startX: x,
      startY: y,
      endX: x,
      endY: y,
    })
  }

  // تحديث التعليق التوضيحي
  const updateAnnotation = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !isAnnotating || !currentAnnotation) return

    const rect = canvasRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setCurrentAnnotation({
      ...currentAnnotation,
      endX: x,
      endY: y,
    })

    // إعادة رسم الكشوفات والتعليق التوضيحي الحالي
    drawDetections([...detections])
  }

  // إنهاء التعليق التوضيحي
  const finishAnnotation = () => {
    if (!currentAnnotation) return

    const { startX, startY, endX, endY } = currentAnnotation

    // التأكد من أن الصندوق له أبعاد إيجابية
    const x = Math.min(startX, endX)
    const y = Math.min(startY, endY)
    const width = Math.abs(endX - startX)
    const height = Math.abs(endY - startY)

    // إضافة التعليق التوضيحي إلى القائمة
    if (width > 10 && height > 10) {
      const newAnnotation: Detection = {
        bbox: [x, y, width, height],
        class: "person",
        score: 1.0,
        color: "#FF0000",
      }

      setAnnotations([...annotations, newAnnotation])

      // إعادة رسم الكشوفات والتعليقات التوضيحية
      drawDetections([...detections, newAnnotation])
    }

    setCurrentAnnotation(null)
  }

  // تبديل وضع التعليق التوضيحي
  const toggleAnnotationMode = () => {
    setIsAnnotating(!isAnnotating)

    if (isAnnotating) {
      setCurrentAnnotation(null)
    }
  }

  // مسح التعليقات التوضيحية
  const clearAnnotations = () => {
    setAnnotations([])
    drawDetections(detections)
  }

  // تدريب النموذج
  const trainModel = async () => {
    if (annotations.length === 0) {
      setError("لا توجد تعليقات توضيحية للتدريب. يرجى إضافة بعض التعليقات التوضيحية أولاً.")
      return
    }

    try {
      setIsTraining(true)
      setTrainingProgress(0)
      setTrainingLogs(["بدء تدريب النموذج..."])

      // تهيئة المدرب
      await yoloTrainer.initialize("/models/yolov8n-web/model.json", {
        epochs: 10,
        batchSize: 4,
        learningRate: 0.0001,
        validationSplit: 0.2,
      })

      setTrainingLogs((logs) => [...logs, "تم تهيئة النموذج للتدريب"])

      // إعداد بيانات التدريب
      if (!canvasRef.current) {
        throw new Error("Canvas not available")
      }

      // استخدام الكانفاس الحالي كمصدر للصورة
      await yoloTrainer.prepareTrainingData([canvasRef.current], annotations)

      setTrainingLogs((logs) => [...logs, "تم إعداد بيانات التدريب"])
      setTrainingProgress(10)

      // تدريب النموذج
      await yoloTrainer.train((epoch, logs) => {
        const progress = Math.round(((epoch + 1) / 10) * 90) + 10
        setTrainingProgress(progress)

        const logMessage = `الحقبة ${epoch + 1}/10 - الخسارة: ${logs.loss.toFixed(4)} - الدقة: ${logs.acc.toFixed(4)}`
        setTrainingLogs((prevLogs) => [...prevLogs, logMessage])
      })

      setTrainingLogs((logs) => [...logs, "اكتمل تدريب النموذج"])
      setTrainingProgress(100)

      // حفظ النموذج
      await yoloTrainer.saveModel()

      setTrainingLogs((logs) => [...logs, "تم حفظ النموذج المدرب"])

      // تحديث النموذج المستخدم
      setTrainingLogs((logs) => [...logs, "تم تحديث النموذج بنجاح!"])
    } catch (err) {
      console.error("Error training model:", err)
      setError("حدث خطأ أثناء تدريب النموذج. يرجى إعادة المحاولة.")
      setTrainingLogs((logs) => [...logs, `خطأ: ${err}`])
    } finally {
      setIsTraining(false)
    }
  }

  // حفظ النتيجة الحالية في قاعدة البيانات
  const handleSaveToDatabase = async () => {
    if (!currentSession) {
      setIsSessionDialogOpen(true)
      return
    }

    if (peopleCount === 0) {
      setError("لا توجد نتائج للحفظ. يرجى تحليل صورة أو فيديو أولاً.")
      return
    }

    try {
      setIsSaving(true)

      // تحويل الكانفاس إلى URL للصورة (يمكن تخزينها في خدمة تخزين مثل Supabase Storage)
      const imageUrl = canvasRef.current?.toDataURL("image/jpeg") || undefined

      await saveCurrentResult(imageUrl)

      setError(null)
      // إظهار رسالة نجاح
      alert("تم حفظ النتيجة بنجاح في قاعدة البيانات!")
    } catch (err) {
      console.error("Error saving to database:", err)
      setError("حدث خطأ أثناء حفظ النتيجة في قاعدة البيانات.")
    } finally {
      setIsSaving(false)
    }
  }

  // إنشاء جلسة جديدة
  const handleCreateSession = async () => {
    if (!newSessionName) {
      setError("يرجى إدخال اسم للجلسة.")
      return
    }

    try {
      await createNewSession(newSessionName, newSessionLocation || undefined)
      setNewSessionName("")
      setNewSessionLocation("")
      setIsSessionDialogOpen(false)
      setError(null)
    } catch (err) {
      console.error("Error creating session:", err)
      setError("حدث خطأ أثناء إنشاء الجلسة.")
    }
  }

  // Add a cleanup function for the timer
  useEffect(() => {
    return () => {
      if (processingTimerRef.current) {
        clearTimeout(processingTimerRef.current)
      }
    }
  }, [])

  // تعديل العرض بناءً على ما إذا كان المكون مضمنًا في صفحة أخرى
  if (embedded) {
    return (
      <div className="w-full">
        <div className="relative">
          <video ref={videoRef} className="w-full h-auto hidden" autoPlay playsInline muted />
          <canvas ref={canvasRef} className="w-full h-auto border border-gray-300 rounded-md" />
          {isProcessing && (
            <div className="absolute top-2 right-2 bg-blue-500 text-white px-2 py-1 rounded-md text-xs flex items-center">
              <div className="h-2 w-2 bg-white rounded-full mr-2 animate-pulse"></div>
              جاري التحليل...
            </div>
          )}
        </div>
        <div className="mt-2 flex justify-between items-center">
          <div className="text-sm font-medium">عدد الأشخاص: {peopleCount}</div>
          <div className="text-xs text-gray-500">
            {processingTime > 0 && `وقت المعالجة: ${processingTime.toFixed(1)} مللي ثانية`}
          </div>
        </div>
      </div>
    )
  }

  return (
    <Card className="w-full max-w-3xl mx-auto overflow-hidden">
      <div className="p-4">
        <Tabs value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="camera">
              <Camera className="mr-2 h-4 w-4" />
              الكاميرا
            </TabsTrigger>
            <TabsTrigger value="image">
              <Upload className="mr-2 h-4 w-4" />
              صورة
            </TabsTrigger>
            <TabsTrigger value="video">
              <Video className="mr-2 h-4 w-4" />
              فيديو
            </TabsTrigger>
          </TabsList>

          <TabsContent value="camera" className="space-y-4">
            <div className="relative">
              <video ref={videoRef} className="w-full h-auto hidden" autoPlay playsInline muted />
              <canvas ref={canvasRef} className="w-full h-auto border border-gray-300 rounded-md" />
            </div>
          </TabsContent>

          <TabsContent value="image" className="space-y-4">
            <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-md p-6">
              <Input
                ref={fileInputRef}
                type="file"
                accept={ALLOWED_IMAGE_TYPES.join(",")}
                onChange={handleImageUpload}
                className="hidden"
              />
              <Button onClick={() => fileInputRef.current?.click()} disabled={isProcessing}>
                <Upload className="mr-2 h-4 w-4" />
                تحميل صورة
              </Button>
            </div>

            <div className="relative">
              <canvas
                ref={canvasRef}
                className="w-full h-auto border border-gray-300 rounded-md"
                onMouseDown={startAnnotation}
                onMouseMove={updateAnnotation}
                onMouseUp={finishAnnotation}
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <Button variant={isAnnotating ? "default" : "outline"} onClick={toggleAnnotationMode}>
                {isAnnotating ? "إيقاف التعليق" : "بدء التعليق"}
              </Button>

              <Button variant="outline" onClick={clearAnnotations} disabled={annotations.length === 0}>
                <Trash className="mr-2 h-4 w-4" />
                مسح التعليقات
              </Button>

              <Button onClick={trainModel} disabled={isTraining || annotations.length === 0}>
                <Save className="mr-2 h-4 w-4" />
                تدريب النموذج
              </Button>
            </div>

            {isTraining && (
              <div className="space-y-2">
                <Progress value={trainingProgress} />
                <div className="max-h-40 overflow-y-auto border border-gray-200 rounded-md p-2 bg-gray-50">
                  {trainingLogs.map((log, index) => (
                    <div key={index} className="text-sm">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="video" className="space-y-4">
            <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-md p-6">
              <Input
                ref={videoInputRef}
                type="file"
                accept={ALLOWED_VIDEO_TYPES.join(",")}
                onChange={handleVideoUpload}
                className="hidden"
              />
              <Button onClick={() => videoInputRef.current?.click()} disabled={isProcessing}>
                <Upload className="mr-2 h-4 w-4" />
                تحميل فيديو
              </Button>
            </div>

            <div className="relative">
              <video ref={videoRef} className="w-full h-auto hidden" playsInline muted />
              <canvas ref={canvasRef} className="w-full h-auto border border-gray-300 rounded-md" />
            </div>

            {videoFile && (
              <div className="flex flex-wrap gap-2">
                <Button onClick={toggleVideoPlayback}>
                  {isVideoPlaying ? (
                    <>
                      <Pause className="mr-2 h-4 w-4" />
                      إيقاف
                    </>
                  ) : (
                    <>
                      <Play className="mr-2 h-4 w-4" />
                      تشغيل
                    </>
                  )}
                </Button>

                <Button variant="outline" onClick={resetVideo}>
                  <RotateCcw className="mr-2 h-4 w-4" />
                  إعادة
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="confidence-threshold">عتبة الثقة: {confidenceThreshold.toFixed(2)}</Label>
            <Slider
              id="confidence-threshold"
              min={0.1}
              max={0.9}
              step={0.05}
              value={[confidenceThreshold]}
              onValueChange={handleConfidenceChange}
              className="w-64"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="text-lg font-semibold">عدد الأشخاص: {peopleCount}</div>
            <div className="flex flex-col items-end">
              <div className="text-sm text-gray-500">
                {isProcessing ? (
                  <div className="flex items-center">
                    <div className="h-2 w-2 bg-blue-500 rounded-full mr-2 animate-pulse"></div>
                    جاري التفكير...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <div className="h-2 w-2 bg-green-500 rounded-full mr-2"></div>
                    جاهز
                  </div>
                )}
              </div>
              {processingTime > 0 && (
                <div className="text-xs text-gray-400">وقت المعالجة: {processingTime.toFixed(1)} مللي ثانية</div>
              )}
            </div>
          </div>

          {/* إضافة زر حفظ في قاعدة البيانات */}
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <span className="text-sm mr-2">الجلسة الحالية:</span>
              {currentSession ? (
                <span className="text-sm font-medium">{currentSession.session_name}</span>
              ) : (
                <span className="text-sm text-gray-500">لا توجد جلسة</span>
              )}
            </div>

            <Button
              onClick={handleSaveToDatabase}
              disabled={isProcessing || isSaving || peopleCount === 0}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Database className="mr-2 h-4 w-4" />
              {isSaving ? "جاري الحفظ..." : "حفظ في قاعدة البيانات"}
            </Button>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start">
              <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>

      {/* مربع حوار إنشاء جلسة جديدة */}
      <Dialog open={isSessionDialogOpen} onOpenChange={setIsSessionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إنشاء جلسة تحليل جديدة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="session-name">اسم الجلسة</Label>
              <Input
                id="session-name"
                placeholder="أدخل اسم الجلسة"
                value={newSessionName}
                onChange={(e) => setNewSessionName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="session-location">الموقع (اختياري)</Label>
              <Input
                id="session-location"
                placeholder="أدخل موقع الجلسة"
                value={newSessionLocation}
                onChange={(e) => setNewSessionLocation(e.target.value)}
              />
            </div>
            <Button onClick={handleCreateSession} className="w-full">
              إنشاء جلسة
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

export default PeopleCounter
