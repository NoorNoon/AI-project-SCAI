import * as tf from "@tensorflow/tfjs"

// واجهة لنتائج الكشف
export interface Detection {
  id?: number
  bbox: [number, number, number, number] // [x, y, width, height]
  class: string
  score: number
  color?: string
}

// فئة نموذج YOLOv8
export class YOLOv8Model {
  private model: tf.GraphModel | null = null
  private modelLoaded = false
  private modelLoading = false
  private modelPath: string
  private classNames: string[]
  private inputShape: [number, number]

  constructor(
    modelPath = "/models/yolov8n-web/model.json",
    classNames: string[] = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat"],
    inputShape: [number, number] = [640, 640],
  ) {
    this.modelPath = modelPath
    this.classNames = classNames
    this.inputShape = inputShape
  }

  // تحميل النموذج
  async load(): Promise<boolean> {
    if (this.modelLoaded) return true
    if (this.modelLoading) {
      // انتظار حتى يتم تحميل النموذج
      return new Promise((resolve) => {
        const checkLoaded = setInterval(() => {
          if (this.modelLoaded) {
            clearInterval(checkLoaded)
            resolve(true)
          }
        }, 100)
      })
    }

    this.modelLoading = true

    try {
      console.log("Loading YOLOv8 model from:", this.modelPath)
      this.model = await tf.loadGraphModel(this.modelPath)

      // التحقق من النموذج بتنفيذ تنبؤ اختباري
      const dummyInput = tf.zeros([1, ...this.inputShape, 3])
      const warmupResult = (await this.model.predict(dummyInput)) as tf.Tensor

      if (Array.isArray(warmupResult)) {
        warmupResult.forEach((tensor) => tensor.dispose())
      } else {
        warmupResult.dispose()
      }

      dummyInput.dispose()

      this.modelLoaded = true
      this.modelLoading = false
      console.log("YOLOv8 model loaded successfully")
      return true
    } catch (error) {
      console.error("Failed to load YOLOv8 model:", error)
      this.modelLoading = false
      throw error
    }
  }

  // تحويل الصورة إلى تنسور
  private imageToTensor(image: HTMLImageElement | HTMLVideoElement | HTMLCanvasElement): tf.Tensor {
    return tf.tidy(() => {
      // تحويل الصورة إلى تنسور
      let tensor = tf.browser.fromPixels(image)

      // تغيير حجم الصورة إلى الحجم المطلوب للنموذج
      tensor = tf.image.resizeBilinear(tensor, this.inputShape)

      // تطبيع القيم (0-255) إلى (0-1)
      tensor = tensor.div(255.0)

      // إضافة بُعد الدفعة (batch dimension)
      return tensor.expandDims(0)
    })
  }

  // معالجة نتائج النموذج
  private processOutput(
    output: tf.Tensor,
    imageWidth: number,
    imageHeight: number,
    confidenceThreshold = 0.25,
  ): Detection[] {
    return tf.tidy(() => {
      // الحصول على البيانات من التنسور
      const [batchDetections] = Array.isArray(output) ? [output[0]] : [output]

      // تحويل التنسور إلى مصفوفة
      const detections = batchDetections.arraySync() as number[][]

      // معالجة النتائج
      const results: Detection[] = []

      for (const detection of detections) {
        // في YOLOv8، الإخراج هو [x_center, y_center, width, height, conf, class1_conf, class2_conf, ...]
        const [x_center, y_center, width, height, confidence, ...classProbs] = detection

        // الحصول على فئة الكائن بأعلى احتمالية
        const classIndex = classProbs.indexOf(Math.max(...classProbs))
        const classConfidence = classProbs[classIndex]
        const combinedConfidence = confidence * classConfidence

        // تجاهل الكشوفات ذات الثقة المنخفضة
        if (combinedConfidence < confidenceThreshold) continue

        // تحويل الإحداثيات النسبية إلى إحداثيات الصورة الأصلية
        const x = (x_center - width / 2) * imageWidth
        const y = (y_center - height / 2) * imageHeight
        const w = width * imageWidth
        const h = height * imageHeight

        // إضافة الكشف إلى النتائج
        results.push({
          bbox: [x, y, w, h],
          class: this.classNames[classIndex],
          score: combinedConfidence,
        })
      }

      return results
    })
  }

  // تطبيق Non-Maximum Suppression لإزالة الكشوفات المتداخلة
  private applyNMS(detections: Detection[], iouThreshold = 0.45): Detection[] {
    // ترتيب الكشوفات حسب درجة الثقة (من الأعلى إلى الأدنى)
    const sortedDetections = [...detections].sort((a, b) => b.score - a.score)
    const selectedDetections: Detection[] = []

    while (sortedDetections.length > 0) {
      // اختيار الكشف ذو الثقة الأعلى
      const currentDetection = sortedDetections.shift()!
      selectedDetections.push(currentDetection)

      // تصفية الكشوفات المتبقية
      const remainingDetections = sortedDetections.filter((detection) => {
        // حساب IoU (Intersection over Union)
        const iou = this.calculateIoU(currentDetection.bbox, detection.bbox)
        // الاحتفاظ بالكشوفات التي لها تداخل أقل من العتبة
        return iou <= iouThreshold
      })

      // تحديث القائمة
      sortedDetections.length = 0
      sortedDetections.push(...remainingDetections)
    }

    return selectedDetections
  }

  // حساب IoU (Intersection over Union) بين صندوقين
  private calculateIoU(boxA: [number, number, number, number], boxB: [number, number, number, number]): number {
    // تحويل [x, y, width, height] إلى [x1, y1, x2, y2]
    const boxACoords = [boxA[0], boxA[1], boxA[0] + boxA[2], boxA[1] + boxA[3]]

    const boxBCoords = [boxB[0], boxB[1], boxB[0] + boxB[2], boxB[1] + boxB[3]]

    // حساب منطقة التقاطع
    const xA = Math.max(boxACoords[0], boxBCoords[0])
    const yA = Math.max(boxACoords[1], boxBCoords[1])
    const xB = Math.min(boxACoords[2], boxBCoords[2])
    const yB = Math.min(boxACoords[3], boxBCoords[3])

    // التحقق من وجود تقاطع
    if (xB < xA || yB < yA) return 0

    const intersectionArea = (xB - xA) * (yB - yA)

    // حساب مساحة كل صندوق
    const boxAArea = (boxACoords[2] - boxACoords[0]) * (boxACoords[3] - boxACoords[1])
    const boxBArea = (boxBCoords[2] - boxBCoords[0]) * (boxBCoords[3] - boxBCoords[1])

    // حساب IoU
    return intersectionArea / (boxAArea + boxBArea - intersectionArea)
  }

  // اكتشاف الكائنات في الصورة
  async detect(
    image: HTMLImageElement | HTMLVideoElement | HTMLCanvasElement,
    confidenceThreshold = 0.25,
    iouThreshold = 0.45,
  ): Promise<Detection[]> {
    if (!this.modelLoaded) {
      await this.load()
    }

    if (!this.model) {
      throw new Error("Model not loaded")
    }

    // Add a small artificial delay to simulate "thinking" (only in development)
    if (process.env.NODE_ENV === "development") {
      await new Promise((resolve) => setTimeout(resolve, 100))
    }

    return tf.tidy(() => {
      // تحويل الصورة إلى تنسور
      const imageTensor = this.imageToTensor(image)

      // تنفيذ التنبؤ
      const output = this.model!.predict(imageTensor) as tf.Tensor

      // معالجة النتائج
      const detections = this.processOutput(output, image.width, image.height, confidenceThreshold)

      // تطبيق Non-Maximum Suppression
      const filteredDetections = this.applyNMS(detections, iouThreshold)

      // تصفية النتائج للحصول على الأشخاص فقط
      const personDetections = filteredDetections.filter((detection) => detection.class === "person")

      // إضافة ألوان عشوائية للكشوفات
      return personDetections.map((detection) => ({
        ...detection,
        color: `hsl(${Math.random() * 360}, 100%, 50%)`,
      }))
    })
  }

  // تفريغ الموارد
  dispose(): void {
    if (this.model) {
      this.model.dispose()
      this.model = null
      this.modelLoaded = false
    }
  }
}

// إنشاء نسخة واحدة من النموذج للاستخدام في جميع أنحاء التطبيق
export const yoloModel = new YOLOv8Model()
