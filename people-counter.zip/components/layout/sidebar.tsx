"use client"

import type React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { LayoutDashboard, Thermometer, Car, MessageSquare, Ticket, Map, Bell, Settings, LogOut } from "lucide-react"

interface SidebarProps {
  collapsed?: boolean
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed = false }) => {
  const pathname = usePathname()

  const routes = [
    {
      title: "لوحة التحكم",
      href: "/dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: "تحليل المشاعر",
      href: "/sentiment-analysis",
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      title: "التحكم بالمناخ",
      href: "/climate-control",
      icon: <Thermometer className="h-5 w-5" />,
    },
    {
      title: "إرشاد المواقف",
      href: "/parking-guidance",
      icon: <Car className="h-5 w-5" />,
    },
    {
      title: "حجز التذاكر",
      href: "/tickets",
      icon: <Ticket className="h-5 w-5" />,
    },
    {
      title: "خريطة الملعب",
      href: "/stadium-map",
      icon: <Map className="h-5 w-5" />,
    },
    {
      title: "الإشعارات",
      href: "/notifications",
      icon: <Bell className="h-5 w-5" />,
    },
    {
      title: "الإعدادات",
      href: "/settings",
      icon: <Settings className="h-5 w-5" />,
    },
  ]

  return (
    <div
      className={cn(
        "flex flex-col h-screen bg-white border-l border-gray-200 transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="p-4 flex justify-center items-center border-b border-gray-200">
        {collapsed ? (
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
            S
          </div>
        ) : (
          <div className="flex items-center">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mr-2">
              S
            </div>
            <span className="font-bold text-xl">نظام الملعب</span>
          </div>
        )}
      </div>

      <div className="flex-1 py-4 overflow-y-auto">
        <nav className="px-2 space-y-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center px-3 py-2 rounded-md transition-colors",
                pathname === route.href ? "bg-blue-50 text-blue-700" : "text-gray-700 hover:bg-gray-100",
                collapsed ? "justify-center" : "justify-start",
              )}
            >
              {route.icon}
              {!collapsed && <span className="mr-2">{route.title}</span>}
            </Link>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-gray-200">
        <Button variant="ghost" className={cn("w-full", collapsed ? "justify-center px-2" : "justify-start")}>
          <LogOut className="h-5 w-5" />
          {!collapsed && <span className="mr-2">تسجيل الخروج</span>}
        </Button>
      </div>
    </div>
  )
}

export default Sidebar
