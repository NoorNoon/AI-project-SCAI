"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Bell, Home, Map, Ticket, User, Calendar, LogOut, Users, Thermometer, FileImage, Video } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import StadiumChatbot from "@/components/stadium-assistant/stadium-chatbot"

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [teamTheme, setTeamTheme] = useState<"hilal" | "nassr">("nassr")
  const [crowdStats, setCrowdStats] = useState({
    totalAttendance: 35420,
    stadiumCapacity: 45000,
    occupancyRate: 78,
    sections: {
      "المدرجات الشمالية": 85,
      "المدرجات الجنوبية": 65,
      "المدرجات الشرقية": 90,
      "المدرجات الغربية": 70,
    },
  })

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))
    setLoading(false)

    // Apply team theme
    document.documentElement.classList.toggle("hilal-theme", teamTheme === "hilal")
    document.documentElement.classList.toggle("nassr-theme", teamTheme === "nassr")

    // Simulate crowd stats updates
    const interval = setInterval(() => {
      setCrowdStats((prev) => {
        const newSections = { ...prev.sections }
        const keys = Object.keys(newSections)
        const randomKey = keys[Math.floor(Math.random() * keys.length)]
        const change = Math.floor(Math.random() * 6) - 3 // -3 to +3
        newSections[randomKey as keyof typeof newSections] = Math.max(
          50,
          Math.min(95, newSections[randomKey as keyof typeof newSections] + change),
        )

        const totalAttendance = Math.floor(prev.totalAttendance + (Math.random() * 100 - 50))

        return {
          ...prev,
          totalAttendance: Math.max(20000, Math.min(prev.stadiumCapacity, totalAttendance)),
          occupancyRate: Math.round((totalAttendance / prev.stadiumCapacity) * 100),
          sections: newSections,
        }
      })
    }, 10000)

    return () => {
      clearInterval(interval)
      // Clean up theme classes
      document.documentElement.classList.remove("hilal-theme", "nassr-theme")
    }
  }, [router, teamTheme])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const toggleTeamTheme = () => {
    setTeamTheme((prev) => (prev === "hilal" ? "nassr" : "hilal"))
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="text-center text-white">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-yellow-500 border-t-transparent"></div>
          <p>جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-2xl font-bold">مرحباً، {user?.name}</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={toggleTeamTheme}>
              {teamTheme === "hilal" ? "تغيير إلى النصر" : "تغيير إلى الهلال"}
            </Button>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5 text-gray-400" />
            </Button>
          </div>
        </div>

        {/* User Profile Card */}
        <Card className="mb-8 border-gray-800 bg-gray-900">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={user?.avatar} alt={user?.name} />
                <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-xl font-semibold">{user?.name}</h2>
                <p className="text-gray-400">{user?.email}</p>
                <Badge className="mt-1 bg-primary text-primary-foreground">
                  {user?.type === "fan" ? "مشجع" : "منظم"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Crowd Management Overview (for organizers) */}
        {user?.type === "organizer" && (
          <Card className="mb-8 border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-semibold">نظرة عامة على الجماهير</h2>
                <Link href="/dashboard/crowd-management">
                  <Button size="sm" className="bg-primary text-primary-foreground">
                    <Users className="mr-2 h-4 w-4" />
                    إدارة الجماهير
                  </Button>
                </Link>
              </div>

              <div className="mb-4 grid grid-cols-3 gap-4">
                <div className="rounded-lg bg-gray-800 p-3 text-center">
                  <div className="text-2xl font-bold">{crowdStats.totalAttendance.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">إجمالي الحضور</div>
                </div>

                <div className="rounded-lg bg-gray-800 p-3 text-center">
                  <div className="text-2xl font-bold">{crowdStats.occupancyRate}%</div>
                  <div className="text-sm text-gray-400">نسبة الإشغال</div>
                </div>

                <div className="rounded-lg bg-gray-800 p-3 text-center">
                  <div className="text-2xl font-bold">{crowdStats.stadiumCapacity - crowdStats.totalAttendance}</div>
                  <div className="text-sm text-gray-400">المقاعد المتبقية</div>
                </div>
              </div>

              <h3 className="mb-2 font-medium">كثافة الجماهير حسب المنطقة</h3>
              <div className="space-y-2">
                {Object.entries(crowdStats.sections).map(([section, density]) => (
                  <div key={section} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span>{section}</span>
                      <Badge
                        className={
                          density > 85 ? "bg-red-500" : density > 70 ? "bg-yellow-500 text-black" : "bg-green-500"
                        }
                      >
                        {density}%
                      </Badge>
                    </div>
                    <Progress value={density} className="h-1 bg-gray-700">
                      <div
                        className={`h-full ${
                          density > 85 ? "bg-red-500" : density > 70 ? "bg-yellow-500" : "bg-green-500"
                        }`}
                        style={{ width: `${density}%` }}
                      />
                    </Progress>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
          <Link href="/dashboard/tickets/book">
            <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
              <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                <Ticket className="mb-2 h-8 w-8 text-primary" />
                <h3 className="font-medium">حجز تذكرة</h3>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/tickets/virtual-booking">
            <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
              <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                <Video className="mb-2 h-8 w-8 text-primary" />
                <h3 className="font-medium">حضور افتراضي</h3>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/tickets">
            <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
              <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                <Calendar className="mb-2 h-8 w-8 text-primary" />
                <h3 className="font-medium">تذاكري</h3>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/map">
            <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
              <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                <Map className="mb-2 h-8 w-8 text-primary" />
                <h3 className="font-medium">خريطة الملعب</h3>
              </CardContent>
            </Card>
          </Link>

          {user?.type === "organizer" && (
            <Link href="/dashboard/people-counter">
              <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
                <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                  <FileImage className="mb-2 h-8 w-8 text-primary" />
                  <h3 className="font-medium">عد الأشخاص</h3>
                </CardContent>
              </Card>
            </Link>
          )}

          {user?.type === "organizer" ? (
            <Link href="/dashboard/crowd-management">
              <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
                <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                  <Users className="mb-2 h-8 w-8 text-primary" />
                  <h3 className="font-medium">إدارة الجماهير</h3>
                </CardContent>
              </Card>
            </Link>
          ) : (
            <Link href="/dashboard/profile">
              <Card className="border-gray-800 bg-gray-900 transition-colors hover:bg-gray-800">
                <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                  <User className="mb-2 h-8 w-8 text-primary" />
                  <h3 className="font-medium">الملف الشخصي</h3>
                </CardContent>
              </Card>
            </Link>
          )}
        </div>

        {/* Stadium Climate */}
        <Card className="mb-8 border-gray-800 bg-gray-900">
          <CardContent className="p-6">
            <h2 className="mb-4 text-xl font-semibold">مناخ الملعب</h2>
            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-lg bg-gray-800 p-3 text-center">
                <Thermometer className="mx-auto mb-2 h-6 w-6 text-red-500" />
                <div className="text-xl font-bold">24°C</div>
                <div className="text-sm text-gray-400">درجة الحرارة</div>
              </div>

              <div className="rounded-lg bg-gray-800 p-3 text-center">
                <div className="mx-auto mb-2 flex h-6 w-6 items-center justify-center">
                  <span className="text-blue-500">💧</span>
                </div>
                <div className="text-xl font-bold">45%</div>
                <div className="text-sm text-gray-400">الرطوبة</div>
              </div>

              <div className="rounded-lg bg-gray-800 p-3 text-center">
                <div className="mx-auto mb-2 flex h-6 w-6 items-center justify-center">
                  <span className="text-green-500">🌬️</span>
                </div>
                <div className="text-xl font-bold">مناسبة</div>
                <div className="text-sm text-gray-400">جودة الهواء</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* People Counter Preview */}
        {user?.type === "organizer" && (
          <Card className="mb-8 border-gray-800 bg-gray-900">
            <CardContent className="p-6">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-semibold">نظام عد الأشخاص بالذكاء الاصطناعي</h2>
                <Link href="/dashboard/people-counter">
                  <Button size="sm" className="bg-primary text-primary-foreground">
                    <FileImage className="mr-2 h-4 w-4" />
                    فتح النظام
                  </Button>
                </Link>
              </div>
              <div className="rounded-lg bg-gray-800 p-4">
                <div className="flex flex-col items-center justify-center gap-4 md:flex-row">
                  <div className="text-center md:w-1/3">
                    <FileImage className="mx-auto mb-2 h-12 w-12 text-primary" />
                    <h3 className="mb-1 font-medium">تحليل الصور</h3>
                    <p className="text-sm text-gray-400">قم بتحميل صور لتحليلها وعد الأشخاص فيها</p>
                  </div>
                  <div className="text-center md:w-1/3">
                    <Users className="mx-auto mb-2 h-12 w-12 text-primary" />
                    <h3 className="mb-1 font-medium">دقة عالية</h3>
                    <p className="text-sm text-gray-400">تعرف على الأشخاص في مختلف الظروف والإضاءة</p>
                  </div>
                  <div className="text-center md:w-1/3">
                    <FileImage className="mx-auto mb-2 h-12 w-12 text-primary" />
                    <h3 className="mb-1 font-medium">تحليل الفيديو</h3>
                    <p className="text-sm text-gray-400">قم بتحليل مقاطع الفيديو وعد الأشخاص فيها</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upcoming Matches */}
        <h2 className="mb-4 text-xl font-bold">المباريات القادمة</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <MatchCard
            homeTeam="الهلال"
            awayTeam="النصر"
            league="دوري روشن السعودي"
            date="الجمعة، 15 نوفمبر"
            time="9:00 م"
            stadium="استاد الملك فهد الدولي"
            homeTeamLogo="/placeholder.svg?height=40&width=40"
            awayTeamLogo="/placeholder.svg?height=40&width=40"
            crowdDensity={85}
          />
          <MatchCard
            homeTeam="الاتحاد"
            awayTeam="الأهلي"
            league="دوري روشن السعودي"
            date="السبت، 16 نوفمبر"
            time="8:30 م"
            stadium="استاد الجوهرة"
            homeTeamLogo="/placeholder.svg?height=40&width=40"
            awayTeamLogo="/placeholder.svg?height=40&width=40"
            crowdDensity={65}
          />
          <MatchCard
            homeTeam="الاتفاق"
            awayTeam="التعاون"
            league="دوري روشن السعودي"
            date="الأحد، 17 نوفمبر"
            time="7:00 م"
            stadium="استاد الأمير محمد بن فهد"
            homeTeamLogo="/placeholder.svg?height=40&width=40"
            awayTeamLogo="/placeholder.svg?height=40&width=40"
            crowdDensity={45}
          />
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 border-t border-gray-800 bg-black py-4">
        <div className="container mx-auto flex items-center justify-around">
          <NavButton icon={<Home className="h-6 w-6" />} label="الرئيسية" active href="/dashboard" />
          <NavButton icon={<Ticket className="h-6 w-6" />} label="التذاكر" href="/dashboard/tickets" />
          <NavButton icon={<Map className="h-6 w-6" />} label="الخريطة" href="/dashboard/map" />
          <NavButton icon={<Bell className="h-6 w-6" />} label="التنبيهات" href="/dashboard/notifications" />
          {user?.type === "organizer" ? (
            <NavButton icon={<Users className="h-6 w-6" />} label="الجماهير" href="/dashboard/crowd-management" />
          ) : (
            <NavButton icon={<User className="h-6 w-6" />} label="حسابي" href="/dashboard/profile" />
          )}
        </div>
      </nav>

      {/* Stadium Chatbot */}
      <StadiumChatbot />
    </div>
  )
}

function MatchCard({
  homeTeam,
  awayTeam,
  league,
  date,
  time,
  stadium,
  homeTeamLogo,
  awayTeamLogo,
  crowdDensity,
}: {
  homeTeam: string
  awayTeam: string
  league: string
  date: string
  time: string
  stadium: string
  homeTeamLogo: string
  awayTeamLogo: string
  crowdDensity: number
}) {
  return (
    <Card className="overflow-hidden border-gray-800 bg-gray-900">
      <div className="p-4">
        <div className="mb-2 text-sm text-gray-400">{league}</div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={homeTeamLogo || "/placeholder.svg"} alt={homeTeam} className="h-10 w-10 rounded-full" />
            <span className="font-semibold">{homeTeam}</span>
          </div>
          <span className="text-primary">VS</span>
          <div className="flex items-center gap-3">
            <span className="font-semibold">{awayTeam}</span>
            <img src={awayTeamLogo || "/placeholder.svg"} alt={awayTeam} className="h-10 w-10 rounded-full" />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between text-sm text-gray-400">
          <div>{date}</div>
          <div>{time}</div>
        </div>
        <div className="mt-2 text-sm text-gray-400">{stadium}</div>

        <div className="mt-3 space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span>كثافة الحضور المتوقعة</span>
            <Badge
              className={
                crowdDensity > 80 ? "bg-red-500" : crowdDensity > 60 ? "bg-yellow-500 text-black" : "bg-green-500"
              }
            >
              {crowdDensity > 80 ? "مرتفعة" : crowdDensity > 60 ? "متوسطة" : "منخفضة"}
            </Badge>
          </div>
          <div className="h-1 overflow-hidden rounded-full bg-gray-800">
            <div
              className={`h-full ${
                crowdDensity > 80 ? "bg-red-500" : crowdDensity > 60 ? "bg-yellow-500" : "bg-green-500"
              }`}
              style={{ width: `${crowdDensity}%` }}
            />
          </div>
        </div>
      </div>
      <Link href="/dashboard/tickets/book">
        <Button className="w-full rounded-none bg-primary text-primary-foreground hover:bg-primary/90">
          حجز التذاكر
        </Button>
      </Link>
    </Card>
  )
}

function NavButton({
  icon,
  label,
  active = false,
  href,
}: {
  icon: React.ReactNode
  label: string
  active?: boolean
  href: string
}) {
  return (
    <Link
      href={href}
      className={`flex flex-col items-center gap-1 ${active ? "text-primary" : "text-gray-400 hover:text-primary"}`}
    >
      {icon}
      <span className="text-xs">{label}</span>
    </Link>
  )
}
