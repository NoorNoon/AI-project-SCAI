"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Users, Thermometer, Car, MessageSquare, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { CrowdAnalysisProvider } from "../context/crowd-analysis-context"

const DashboardMobile = () => {
  const [activeTab, setActiveTab] = useState<string>("overview")

  // بيانات تمثيلية للرسم البياني
  const chartData = [
    { time: "14:00", count: 12500 },
    { time: "15:00", count: 18700 },
    { time: "16:00", count: 22300 },
    { time: "17:00", count: 24853 },
  ]

  return (
    <CrowdAnalysisProvider>
      <div className="p-4 space-y-4">
        <Alert className="border-amber-500 bg-amber-50">
          <AlertTriangle className="h-4 w-4 text-amber-500" />
          <AlertTitle className="text-amber-700 text-sm">تنبيه: ازدحام متوسط</AlertTitle>
          <AlertDescription className="text-amber-700 text-xs">
            تم رصد ازدحام متوسط في المنطقة الشرقية.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-2 gap-3">
          <Card className="stat-card">
            <div className="stat-card-label">إجمالي الحضور</div>
            <div className="stat-card-value">24,853</div>
            <div className="text-xs text-green-500 font-medium">↑ 12%</div>
          </Card>

          <Card className="stat-card">
            <div className="stat-card-label">متوسط الكثافة</div>
            <div className="stat-card-value text-xl">متوسطة</div>
            <div className="text-xs text-amber-500 font-medium">↑ 5%</div>
          </Card>

          <Card className="stat-card">
            <div className="stat-card-label">درجة الحرارة</div>
            <div className="stat-card-value">24°C</div>
            <div className="text-xs text-green-500 font-medium">مثالية</div>
          </Card>

          <Card className="stat-card">
            <div className="stat-card-label">مواقف السيارات</div>
            <div className="stat-card-value">68%</div>
            <div className="text-xs text-amber-500 font-medium">↑ 15%</div>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 pt-4 fade-in">
            <Card className="chart-container">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="count"
                    name="عدد الحضور"
                    stroke="#3b82f6"
                    activeDot={{ r: 8 }}
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              {[
                { title: "تحليل الحشود", icon: Users, color: "text-blue-500", path: "/crowd-analysis" },
                { title: "تحليل المشاعر", icon: MessageSquare, color: "text-purple-500", path: "/sentiment-analysis" },
                { title: "التحكم بالمناخ", icon: Thermometer, color: "text-red-500", path: "/climate-control" },
                { title: "إرشاد المواقف", icon: Car, color: "text-green-500", path: "/parking-guidance" },
              ].map((item, index) => (
                <Link href={item.path} key={index}>
                  <Card className="p-3 hover:bg-gray-50 transition-colors flex flex-col items-center justify-center text-center h-24">
                    <item.icon className={`h-8 w-8 mb-2 ${item.color}`} />
                    <div className="text-sm font-medium">{item.title}</div>
                  </Card>
                </Link>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </CrowdAnalysisProvider>
  )
}

export default DashboardMobile
