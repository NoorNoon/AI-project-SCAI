"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CrowdAnalysisProvider } from "../context/crowd-analysis-context"
import PeopleCounterMobile from "./people-counter-mobile"
import AnalysisHistoryMobile from "../crowd-analysis/analysis-history-mobile"
import SessionManagerMobile from "../crowd-analysis/session-manager-mobile"
import { Camera, History, Settings } from "lucide-react"

const PeopleCounterPageMobile = () => {
  const [activeTab, setActiveTab] = useState<string>("counter")

  return (
    <CrowdAnalysisProvider>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-0 sticky top-0 z-10 bg-background/80 backdrop-blur-md">
          <TabsTrigger value="counter" className="text-xs">
            <Camera className="h-4 w-4 mr-1" />
            عداد الأشخاص
          </TabsTrigger>
          <TabsTrigger value="history" className="text-xs">
            <History className="h-4 w-4 mr-1" />
            السجل
          </TabsTrigger>
          <TabsTrigger value="sessions" className="text-xs">
            <Settings className="h-4 w-4 mr-1" />
            الجلسات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="counter" className="mt-0 fade-in">
          <PeopleCounterMobile />
        </TabsContent>

        <TabsContent value="history" className="mt-0 fade-in">
          <AnalysisHistoryMobile />
        </TabsContent>

        <TabsContent value="sessions" className="mt-0 fade-in">
          <SessionManagerMobile />
        </TabsContent>
      </Tabs>
    </CrowdAnalysisProvider>
  )
}

export default PeopleCounterPageMobile
